"use client";

import { useState } from "react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What type of AUM growth can I expect?",
      answer:
        "Our clients typically see 2-4x growth in assets under management within the first 18 months. Results vary based on firm size and market, but we focus on sustainable, compliant strategies that compound over time.",
    },
    {
      question: "How do you ensure marketing compliance?",
      answer:
        "Every campaign, piece of content, and advertisement goes through our compliance review process aligned with SEC, FINRA, and state regulations before launch. We maintain a 100% approval rate.",
    },
    {
      question: "How do you measure financial marketing ROI?",
      answer:
        "We track key metrics including cost per lead, cost per client acquisition, client lifetime value, AUM growth, and marketing-influenced assets with detailed attribution across all channels.",
    },
    {
      question: "What types of firms do you work with?",
      answer:
        "We work with RIAs, wealth management firms, fintech platforms, broker-dealers, and institutional asset managers across all stages of growth.",
    },
    {
      question: "How much does compliant marketing cost?",
      answer:
        "Investment varies based on your firm size and goals. We offer packages starting at $15,000/month. Schedule a strategy session to get a tailored proposal.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our financial services marketing.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
