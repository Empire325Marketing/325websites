import Button from "@/components/ui/Button";

export default function ServicesShowcase() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Financial Services Marketing
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that drive compliant growth for RIAs, wealth
            managers, and fintech companies.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Compliance-First Strategy
            </h3>
            <p className="text-gray-600 leading-relaxed">
              SEC and FINRA-compliant marketing strategies built from the ground
              up. Every campaign, piece of content, and advertisement goes through
              our regulatory review process before launch. We ensure 100% compliance
              while maximizing your growth potential.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              High-Value Client Acquisition
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Targeted campaigns across LinkedIn, Google, and strategic content
              channels to attract HNW individuals and institutional clients. Our
              multi-channel nurturing approach delivers 40-60% lower customer
              acquisition costs on average.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Trust & Authority Building
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Thought leadership content, educational webinars, and strategic PR
              that positions your firm as the trusted authority. We build the
              credibility infrastructure that converts prospects into long-term
              clients with higher lifetime value.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
