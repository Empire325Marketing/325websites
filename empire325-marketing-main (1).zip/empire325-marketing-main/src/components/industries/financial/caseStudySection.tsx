import Image from "next/image";

export default function CaseStudySection() {
  const results = [
    { value: "400%", label: "HNW Prospect Increase" },
    { value: "$50M", label: "New AUM" },
    { value: "80%", label: "Lower CAC" },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <div className="relative h-[400px] lg:h-[500px]">
            <Image
              src="https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1200&q=80"
              alt="Wealth Management Success"
              fill
              className="object-cover"
            />
          </div>

          {/* Right - Content */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Case Study
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Wealth management firm transformation
            </h2>
            <p className="text-base text-gray-600 leading-relaxed mb-10">
              How we helped a mid-market wealth management firm achieve explosive
              growth through compliant digital marketing strategies. 100%
              compliant marketing achieved across all channels.
            </p>

            {/* Stats Row */}
            <div className="grid grid-cols-3 gap-px bg-gray-200">
              {results.map((result, index) => (
                <div key={index} className="bg-white p-6 text-center">
                  <div
                    className="text-3xl md:text-4xl text-black mb-2"
                    style={{ fontWeight: 1000 }}
                  >
                    {result.value}
                  </div>
                  <p className="text-sm text-gray-600">{result.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
