'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import Image from 'next/image';

export default function CTASection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const benefits = [
    'Free compliance assessment',
    'Custom growth strategy',
    'AUM projections',
    'No obligation consultation',
  ];

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="relative rounded-3xl overflow-hidden"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <Image
              src="https://images.unsplash.com/photo-1560472355-536de3962603?w=1200&q=80"
              alt="Financial Services"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-slate-900/90" />
          </div>

          {/* Content */}
          <div className="relative px-8 md:px-16 py-16 md:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">

              {/* Left Content */}
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/20 rounded-full mb-6">
                  <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
                  <span className="text-sm font-medium text-[#0bc7cd]">
                    Get Started
                  </span>
                </div>

                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
                  Ready to grow your AUM?
                </h2>

                <p className="text-lg text-slate-300 leading-relaxed mb-8">
                  Get your free compliance assessment and discover how we can help
                  you increase assets under management while maintaining regulatory compliance.
                </p>

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => window.location.href = '/company/contact'}
                    className="group inline-flex items-center gap-3 px-8 py-4 bg-[#0bc7cd] text-white font-semibold rounded-lg hover:bg-[#0ab4ba] transition-colors"
                  >
                    Get Free Assessment
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Right - Benefits */}
              <div className="lg:pl-12">
                <div className="p-8 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10">
                  <h3 className="text-xl font-bold text-white mb-6">
                    What you'll get
                  </h3>
                  <div className="space-y-4">
                    {benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-[#0bc7cd] flex-shrink-0" />
                        <span className="text-slate-300">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
}
