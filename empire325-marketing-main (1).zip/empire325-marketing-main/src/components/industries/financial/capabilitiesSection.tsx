'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import {
  Building2,
  Briefcase,
  PiggyBank,
  LineChart,
  Landmark,
  BadgeCheck
} from 'lucide-react';

const capabilities = [
  {
    icon: Building2,
    title: 'Wealth Management',
    description: 'Growth strategies for RIAs and wealth advisors targeting HNW clients.',
  },
  {
    icon: Briefcase,
    title: 'Investment Advisory',
    description: 'Marketing for broker-dealers and investment advisory firms.',
  },
  {
    icon: PiggyBank,
    title: 'Retirement Planning',
    description: 'Lead generation for 401(k), IRA, and retirement planning services.',
  },
  {
    icon: LineChart,
    title: 'Fintech Platforms',
    description: 'User acquisition for robo-advisors and financial technology companies.',
  },
  {
    icon: Landmark,
    title: 'Commercial Banking',
    description: 'B2B marketing for commercial banking and lending services.',
  },
  {
    icon: BadgeCheck,
    title: 'Insurance Products',
    description: 'Compliant marketing for life insurance and annuity products.',
  },
];

export default function CapabilitiesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Specializations
            </span>
          </div>
          <div className="grid lg:grid-cols-2 gap-8">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white leading-tight">
              Industries we serve
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 lg:pt-4">
              Deep expertise across the financial services landscape, from boutique RIAs to enterprise fintech platforms.
            </p>
          </div>
        </motion.div>

        {/* Capabilities Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((capability, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="group p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl hover:bg-[#0bc7cd] transition-colors duration-300"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#0bc7cd] group-hover:bg-white flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                  <capability.icon className="w-6 h-6 text-white group-hover:text-[#0bc7cd] transition-colors duration-300" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-white mb-2 transition-colors duration-300">
                    {capability.title}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400 group-hover:text-white/80 text-sm leading-relaxed transition-colors duration-300">
                    {capability.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
