'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const metrics = [
  { value: '$100M+', label: 'AUM Influenced' },
  { value: '250%', label: 'Qualified Lead Increase' },
  { value: '65%', label: 'Conversion Rate Lift' },
  { value: '40%', label: 'Lower CAC' },
];

export default function TrustBar() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-20 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <p className="text-slate-600 dark:text-slate-400">
            Trusted by financial leaders
          </p>
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {metrics.map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-2">
                {metric.value}
              </div>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                {metric.label}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
