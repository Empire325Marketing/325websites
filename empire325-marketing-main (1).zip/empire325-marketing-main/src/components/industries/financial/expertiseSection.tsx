export default function ExpertiseSection() {
  const capabilities = [
    {
      title: "SEC & FINRA Compliance",
      description:
        "Every campaign meets regulatory standards with proper disclosures and documentation.",
    },
    {
      title: "CRM Integration",
      description:
        "Salesforce, Redtail, Wealthbox, and portfolio management system integrations.",
    },
    {
      title: "AUM Growth Focus",
      description:
        "Strategies designed to maximize assets under management and client lifetime value.",
    },
    {
      title: "Multi-State Compliance",
      description:
        "Navigate complex state-level financial marketing requirements across all 50 states.",
    },
    {
      title: "Thought Leadership",
      description:
        "Position your firm as an industry authority and trusted advisor through strategic content.",
    },
    {
      title: "Marketing Automation",
      description:
        "Lead nurturing, client communication, and referral programs that scale efficiently.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Why Choose Us
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Full-stack financial expertise
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Comprehensive capabilities across the entire financial services
            marketing lifecycle.
          </p>
        </div>

        {/* 3x2 Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-gray-200">
          {capabilities.map((capability, index) => (
            <div key={index} className="bg-white p-8">
              <h3 className="text-lg font-bold text-black mb-3">
                {capability.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {capability.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
