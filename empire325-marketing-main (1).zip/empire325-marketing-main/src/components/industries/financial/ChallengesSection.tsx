export default function ChallengesSection() {
  const challenges = [
    {
      challenge: "Regulatory Compliance Complexity",
      solution:
        "Our compliance-first methodology ensures every campaign meets SEC, FINRA, and state-level requirements with 100% approval rate.",
    },
    {
      challenge: "High-Value Client Acquisition",
      solution:
        "Multi-channel nurturing campaigns combining educational content, thought leadership, and personalized outreach for 40-60% lower CAC.",
    },
    {
      challenge: "Trust & Credibility Building",
      solution:
        "Strategic content marketing, case studies, research publishing, and social proof systems that establish digital-first authority.",
    },
    {
      challenge: "Digital Transformation",
      solution:
        "Phased digital transformation that respects existing relationships while building modern acquisition channels.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Challenges & Solutions
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Navigating financial marketing complexity
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            The regulatory landscape has evolved dramatically. We help you
            overcome common obstacles while driving sustainable growth.
          </p>
        </div>

        {/* Two Column Challenge/Solution Grid */}
        <div className="grid md:grid-cols-2 gap-px bg-gray-800">
          {challenges.map((item, index) => (
            <div key={index} className="bg-black p-8">
              <div className="flex items-start gap-4 mb-4">
                <span className="text-[#0dc2cc] font-bold text-sm">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white">{item.challenge}</h3>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed pl-8">
                {item.solution}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
