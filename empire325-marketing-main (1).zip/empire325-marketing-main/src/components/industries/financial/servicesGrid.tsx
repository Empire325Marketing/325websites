'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import {
  Shield,
  FileText,
  Users,
  Code2,
  BarChart3,
  HeartHandshake
} from 'lucide-react';

const services = [
  {
    icon: Shield,
    title: 'Compliance-First Strategy',
    description: 'SEC and FINRA-compliant marketing strategies that combine proven acquisition methodologies with regulatory-safe growth engines.',
  },
  {
    icon: FileText,
    title: 'Trust-Building Content',
    description: 'Educational webinars, thought leadership articles, and compliant content that builds credibility with high-net-worth prospects.',
  },
  {
    icon: Users,
    title: 'High-Value Client Acquisition',
    description: 'Targeted LinkedIn campaigns, Google Ads, and ABM programs designed for financial services lead generation.',
  },
  {
    icon: Code2,
    title: 'Fintech Platform Development',
    description: 'Custom financial platforms, client portals, and automated onboarding systems with compliance integration.',
  },
  {
    icon: BarChart3,
    title: 'B2B Financial Marketing',
    description: 'Integrated SEO, LinkedIn advertising, content marketing, and account-based marketing for comprehensive growth.',
  },
  {
    icon: HeartHandshake,
    title: 'Client Retention Programs',
    description: 'Advanced client success automation, portfolio performance communication, and referral program systems.',
  },
];

export default function ServicesGrid() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Our Services
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white leading-tight mb-6">
            Financial marketing solutions
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            AUM-focused compliant growth solutions for RIAs, wealth managers, and fintech companies.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="p-8 bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-[#0bc7cd]/30 dark:hover:border-[#0bc7cd]/30 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0bc7cd]/10 flex items-center justify-center mb-6">
                <service.icon className="w-6 h-6 text-[#0bc7cd]" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
                {service.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
