'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Shield, FileText, Users, Code2, BarChart3, HeartHandshake } from 'lucide-react';

export default function ServicesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const services = [
    {
      icon: Shield,
      title: 'Compliance-First Strategy',
      description: 'SEC and FINRA-compliant marketing strategies with regulatory-safe growth engines.',
    },
    {
      icon: FileText,
      title: 'Trust-Building Content',
      description: 'Educational webinars, thought leadership, and compliant content that builds credibility.',
    },
    {
      icon: Users,
      title: 'High-Value Acquisition',
      description: 'Targeted LinkedIn campaigns, Google Ads, and ABM programs for financial leads.',
    },
    {
      icon: Code2,
      title: 'Fintech Development',
      description: 'Custom financial platforms, client portals, and compliance-integrated systems.',
    },
    {
      icon: BarChart3,
      title: 'Performance Marketing',
      description: 'Integrated SEO, LinkedIn advertising, and account-based marketing campaigns.',
    },
    {
      icon: HeartHandshake,
      title: 'Client Retention',
      description: 'Success automation, portfolio communication, and referral program systems.',
    },
  ];

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              What We Do
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-[2.75rem] font-bold text-slate-900 dark:text-white leading-tight mb-4">
            Financial services marketing
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
            End-to-end solutions designed for RIAs, wealth managers, and fintech companies.
          </p>
        </motion.div>

        {/* Services Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {services.map((service, index) => (
            <div
              key={index}
              className="group p-8 bg-white dark:bg-slate-900/50 rounded-2xl hover:bg-[#0bc7cd]/5 dark:hover:bg-[#0bc7cd]/10 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0bc7cd]/10 flex items-center justify-center mb-6 group-hover:bg-[#0bc7cd]/20 transition-colors">
                <service.icon className="w-6 h-6 text-[#0bc7cd]" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
                {service.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </motion.div>

      </div>
    </section>
  );
}
