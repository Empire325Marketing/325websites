export default function SpecializationsSection() {
  const capabilities = [
    {
      title: "Wealth Management",
      description:
        "Growth strategies for RIAs and wealth advisors targeting HNW clients with compliant digital acquisition and nurturing programs.",
    },
    {
      title: "Investment Advisory",
      description:
        "Marketing for broker-dealers and investment advisory firms with proper disclosures and regulatory compliance built in.",
    },
    {
      title: "Retirement Planning",
      description:
        "Lead generation for 401(k), IRA, and retirement planning services with educational content that builds trust.",
    },
    {
      title: "Fintech Platforms",
      description:
        "User acquisition for robo-advisors and financial technology companies scaling in a regulated environment.",
    },
    {
      title: "Commercial Banking",
      description:
        "B2B marketing for commercial banking and lending services targeting business owners and CFOs.",
    },
    {
      title: "Insurance Products",
      description:
        "Compliant marketing for life insurance, annuity products, and comprehensive financial planning services.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Industries We Serve
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Deep expertise across the entire financial services landscape.
          </p>
        </div>

        {/* Capabilities - Horizontal Rows */}
        <div className="space-y-0">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {capability.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">
                  {capability.title}
                </h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
