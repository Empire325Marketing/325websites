export default function ApproachSection() {
  const steps = [
    {
      num: "01",
      title: "Analyze",
      description:
        "Deep dive into your store data, customer behavior, and competitive landscape to identify opportunities.",
    },
    {
      num: "02",
      title: "Strategize",
      description:
        "Build a custom roadmap focused on high-impact conversion opportunities with clear KPIs.",
    },
    {
      num: "03",
      title: "Execute",
      description:
        "Implement changes systematically while tracking every metric that matters to your bottom line.",
    },
    {
      num: "04",
      title: "Optimize",
      description:
        "Continuous testing and refinement through A/B testing and performance monitoring.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Our Approach
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Data-driven commerce that actually converts
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Every decision is backed by analytics, conversion data, and years of
            e-commerce expertise.
          </p>
        </div>

        {/* 4 Column Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200">
          {steps.map((step) => (
            <div key={step.num} className="bg-white p-8">
              <span className="text-5xl font-black text-black block mb-4">
                {step.num}
              </span>
              <h3 className="text-xl font-bold text-black mb-3">{step.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
