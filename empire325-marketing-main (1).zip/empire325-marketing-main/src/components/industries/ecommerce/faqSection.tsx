"use client";

import { useState } from "react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What type of revenue growth can I expect?",
      answer: "Our clients typically see 100-300% revenue growth within the first 12 months. Results vary based on your current baseline, but we focus on sustainable, data-driven strategies that compound over time.",
    },
    {
      question: "How do you approach conversion optimization?",
      answer: "We use a scientific approach combining analytics, user behavior research, A/B testing, and proven conversion principles. We analyze every touchpoint in your customer journey to identify and eliminate friction points.",
    },
    {
      question: "How do you measure e-commerce ROI?",
      answer: "We track comprehensive metrics including revenue, conversion rates, customer lifetime value, acquisition costs, and attribution across all channels. You'll receive detailed reports showing exactly how our work impacts your bottom line.",
    },
    {
      question: "What platforms do you work with?",
      answer: "We specialize in Shopify Plus, WooCommerce, Magento, and BigCommerce. We also build custom e-commerce solutions for unique requirements.",
    },
    {
      question: "How much does e-commerce optimization cost?",
      answer: "Investment varies based on your goals and current state. We offer custom packages starting from $5,000/month. Schedule a strategy session to get a tailored proposal.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our e-commerce services.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
