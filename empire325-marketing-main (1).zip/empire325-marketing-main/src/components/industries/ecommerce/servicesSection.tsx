import Button from "@/components/ui/Button";

export default function ServicesSection() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            E-commerce Growth Services
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that drive measurable revenue growth for
            e-commerce brands ready to scale beyond plateaus.
          </p>
        </div>

        {/* Three Columns - Like Marketing Forces */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Revenue Strategy & CRO
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Data-backed e-commerce strategies combining proven conversion
              methodologies with measurable outcomes. We analyze every touchpoint
              in your customer journey to identify friction points and maximize
              revenue per visitor. Average conversion lift: 65%.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Multi-Channel Acquisition
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Integrated campaigns across Google Shopping, Meta Commerce, Amazon,
              and email marketing. We build acquisition systems that scale
              profitably while reducing customer acquisition costs. Our clients
              see 45% lower CAC on average.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Retention & Lifetime Value
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Email automation, loyalty programs, and subscription models that
              turn one-time buyers into repeat customers. We focus on maximizing
              customer lifetime value through systematic retention infrastructure.
              Average LTV increase: 2.1x.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
