export default function OfferingsSection() {
  const capabilities = [
    {
      title: "Store Development",
      description: "Conversion-focused e-commerce stores built on Shopify Plus, WooCommerce, or custom platforms with optimized checkout flows and mobile-first design.",
    },
    {
      title: "E-commerce SEO",
      description: "Organic traffic growth through product page optimization, technical SEO, and content strategies that capture high-intent commercial search traffic.",
    },
    {
      title: "Performance Advertising",
      description: "ROI-driven campaigns across Google Shopping, Meta Commerce, and Amazon Ads with sophisticated attribution and bid optimization.",
    },
    {
      title: "Email & Automation",
      description: "Smart email flows including cart recovery, post-purchase sequences, and personalization engines that maximize customer lifetime value.",
    },
    {
      title: "Analytics Infrastructure",
      description: "Comprehensive tracking dashboards with server-side analytics, attribution modeling, and real-time revenue reporting.",
    },
    {
      title: "Platform Management",
      description: "Ongoing support, A/B testing, and continuous optimization to maintain peak performance as you scale.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Everything You Need to Scale
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Comprehensive e-commerce solutions built for sustainable growth.
          </p>
        </div>

        {/* Capabilities - Horizontal Rows Like Intelligence Section */}
        <div className="space-y-0">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {capability.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">
                  {capability.title}
                </h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
