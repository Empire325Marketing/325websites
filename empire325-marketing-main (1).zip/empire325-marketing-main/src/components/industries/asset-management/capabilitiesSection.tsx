export default function CapabilitiesSection() {
  const capabilities = [
    {
      title: "Hedge Funds",
      description:
        "3(c)(1) and 3(c)(7) fund marketing for hedge funds. We support emerging managers through Form D filing and established funds with GIPS-compliant track record verification and DDQ preparation.",
    },
    {
      title: "Private Equity & Venture",
      description:
        "LP relationship building for GP fundraising across all vintages. Capital call marketing, IRR/MOIC reporting frameworks, and carried interest communications that resonate with institutional allocators.",
    },
    {
      title: "Real Estate Investment",
      description:
        "Marketing for Reg D real estate funds, DSTs, QOZs, and 1031 exchange vehicles. We target accredited investors and qualified purchasers with compliant syndication marketing.",
    },
    {
      title: "Fixed Income & Credit",
      description:
        "Investor acquisition for CLOs, BDCs, interval funds, and private credit vehicles. NAV-based reporting and yield-focused communications for income-oriented allocators.",
    },
    {
      title: "Registered Products",
      description:
        "40 Act fund distribution support, RIA channel marketing, and FINRA-reviewed materials for mutual funds, ETFs, and interval funds targeting retail and institutional channels.",
    },
    {
      title: "Family Offices & RIAs",
      description:
        "Bespoke strategies for single/multi-family offices and RIAs with $100M+ AUM. ADV Part 2 aligned messaging and fiduciary-focused positioning.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Investment Strategies We Serve
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Deep expertise across the entire asset management landscape.
          </p>
        </div>

        {/* Capabilities - Horizontal Rows */}
        <div className="space-y-0">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {capability.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">
                  {capability.title}
                </h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
