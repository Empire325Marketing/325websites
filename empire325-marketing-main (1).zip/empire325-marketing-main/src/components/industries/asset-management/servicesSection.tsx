import Button from "@/components/ui/Button";

export default function ServicesSection() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Asset Management Marketing
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that drive compliant AUM growth for asset
            managers and investment firms.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Accredited Investor Acquisition
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Targeted campaigns reaching qualified purchasers, accredited investors,
              pension funds, endowments, and institutional allocators. We leverage
              506(c) general solicitation strategies and 506(b) relationship-based
              approaches to build verified investor pipelines that meet SEC
              accreditation verification requirements.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Fund Marketing & Capital Introduction
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Regulation D compliant marketing materials, PPMs, pitch decks, and
              DDQ support that articulate your investment thesis. We prepare
              GIPS-compliant track record presentations and Form ADV-aligned
              communications that withstand institutional due diligence and
              operational reviews.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              LP Relations & Thought Leadership
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Strategic content positioning your GP team as industry authorities.
              Quarterly investor letters, capital call communications, and NAV
              reporting frameworks that build LP confidence. We support your
              investor relations through every stage from Form D filing to
              fund lifecycle management.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
