"use client";

import { useState } from "react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Do you support both 506(b) and 506(c) offerings?",
      answer:
        "Yes. For 506(b) offerings, we focus on relationship-based marketing without general solicitation. For 506(c) offerings, we implement full general solicitation campaigns with SEC-compliant accreditation verification workflows to ensure all investors meet the accredited investor or qualified purchaser thresholds.",
    },
    {
      question: "How do you verify accredited investor status?",
      answer:
        "We integrate with third-party verification services that meet SEC standards for 506(c) offerings. This includes income verification, net worth documentation, and professional certification reviews (Series 7, Series 65, CFA). For qualified purchasers, we support the enhanced $5M investment threshold verification.",
    },
    {
      question: "What compliance frameworks do you follow?",
      answer:
        "All materials align with SEC Regulation D, Investment Advisers Act of 1940, FINRA advertising rules, and state blue sky laws. We prepare DDQ-ready content, Form ADV Part 2 compliant messaging, and GIPS-aligned performance presentations.",
    },
    {
      question: "Can you help with Form D filings and ongoing compliance?",
      answer:
        "We support the marketing aspects around Form D filings and provide materials that align with your offering memorandum and PPM. We coordinate with your legal counsel on Rule 506 compliance and amendment filings as your raise progresses.",
    },
    {
      question: "What is your experience with institutional due diligence?",
      answer:
        "Our materials are built to withstand institutional LP due diligence including operational due diligence (ODD) reviews. We prepare DDQ responses, GIPS-compliant track records, and institutional-grade pitch materials that meet pension fund and endowment standards.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our asset management marketing
              services.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
