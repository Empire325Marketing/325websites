import Button from "@/components/ui/Button";
import Image from "next/image";

export default function HeroSection() {
  return (
    <section className="relative bg-white">
      <div className="flex flex-col lg:flex-row min-h-[70vh]">
        {/* Left Content Panel */}
        <div className="flex-1 flex items-center px-6 md:px-12 lg:px-16 xl:px-24 py-12 lg:py-0">
          <div className="max-w-xl">
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Asset Management Solutions
            </p>

            <h1
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Marketing that attracts institutional capital
            </h1>

            <p className="text-base text-gray-600 leading-relaxed mb-8">
              We help asset managers, hedge funds, and private equity firms scale
              AUM through Regulation D 506(c) compliant investor acquisition. Our
              strategies target accredited investors and qualified purchasers with
              institutional-grade marketing that passes LP due diligence.
            </p>

            <Button href="/company/contact">Schedule Consultation</Button>
          </div>
        </div>

        {/* Right Image Panel */}
        <div className="flex-1 relative min-h-[300px] lg:min-h-0">
          <Image
            src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=1600&q=80"
            alt="Asset Management"
            fill
            className="object-cover"
          />
        </div>
      </div>
    </section>
  );
}
