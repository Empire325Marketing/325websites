import Button from "@/components/ui/Button";

export default function ServicesGrid() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            SaaS Growth Services
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that drive sustainable recurring revenue
            growth for SaaS companies at every stage.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Product-Led Growth
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Optimize user activation and product stickiness by analyzing every
              step of your user journey. We build frictionless signup flows,
              guided onboarding experiences, and viral growth loops that drive
              organic adoption. Average trial conversion lift: 55%.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Multi-Channel Acquisition
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Integrated campaigns across Google Ads, LinkedIn, content marketing,
              and email for consistent pipeline growth. We build acquisition
              systems that scale profitably while reducing customer acquisition
              costs. Our clients see 50% lower CAC on average.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Retention & Expansion
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Customer success automation, feature adoption tracking, and upselling
              campaigns to reduce churn and increase lifetime value. We focus on
              net revenue retention through systematic expansion infrastructure.
              Average churn reduction: 75%.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
