// components/saas/StatsSection.tsx
'use client';

import { motion } from 'framer-motion';

export default function StatsSection() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0bc7cd]/5 to-transparent"></div>
      
      <div className="container mx-auto px-6 lg:px-8 max-w-7xl relative">
        {/* Stats with varied sizes for visual interest */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
          {/* Stat 1 - Featured */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="col-span-2 lg:col-span-1 text-center lg:text-left"
          >
            <div className="inline-block mb-3">
              <div className="text-5xl lg:text-6xl font-bold mb-1">
                $3.5M+
              </div>
              <div className="h-1 w-16 bg-[#0bc7cd] rounded-full"></div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              ARR generated for SaaS clients
            </p>
          </motion.div>

          {/* Stat 2 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold mb-2">
              320%
            </div>
            <p className=" text-sm leading-relaxed">
              Average increase in qualified leads
            </p>
          </motion.div>

          {/* Stat 3 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold mb-2">
              55%
            </div>
            <p className=" text-sm leading-relaxed">
              Improvement in trial-to-paid conversion
            </p>
          </motion.div>

          {/* Stat 4 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold mb-2">
              180%
            </div>
            <p className=" text-sm leading-relaxed">
              Growth in organic traffic
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}