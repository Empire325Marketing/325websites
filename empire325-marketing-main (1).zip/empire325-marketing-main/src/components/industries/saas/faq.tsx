"use client";

import { useState } from "react";

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What type of ARR growth can I expect?",
      answer:
        "Our clients typically see 2-5x ARR growth in the first year. Results vary by company size and market, but we focus on sustainable, data-driven strategies that compound over time.",
    },
    {
      question: "How do you approach product-led growth?",
      answer:
        "We optimize every touchpoint from signup to activation, ensuring frictionless experiences that drive organic adoption and viral growth loops.",
    },
    {
      question: "How do you measure SaaS marketing ROI?",
      answer:
        "We track CAC, LTV, MRR/ARR growth, churn rate, trial conversion, and customer acquisition efficiency across all channels with detailed attribution.",
    },
    {
      question: "What platforms and tools do you work with?",
      answer:
        "We work with all major SaaS platforms including HubSpot, Salesforce, Mixpanel, Amplitude, Segment, and can integrate with your existing tech stack.",
    },
    {
      question: "How much does SaaS growth marketing cost?",
      answer:
        "Investment varies based on your stage and goals. We offer packages starting at $10K/month for early-stage to comprehensive programs for enterprise.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our SaaS growth services.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
