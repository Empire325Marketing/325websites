export default function WhyChooseSection() {
  const capabilities = [
    {
      title: "Product-Led Growth",
      description:
        "Frictionless signup flows, guided onboarding experiences, and viral growth loops that drive organic adoption.",
    },
    {
      title: "Marketing Automation",
      description:
        "Lead scoring, behavioral email sequences, and customer success automation that scales efficiently.",
    },
    {
      title: "Analytics & Data",
      description:
        "Cohort analysis, churn prediction, and revenue attribution across all touchpoints.",
    },
    {
      title: "Content & SEO",
      description:
        "Technical content marketing and thought leadership development that drives organic growth.",
    },
    {
      title: "Paid Acquisition",
      description:
        "LinkedIn advertising, Google Ads, and account-based marketing programs that scale profitably.",
    },
    {
      title: "Sales Enablement",
      description:
        "CRM optimization, sales automation, and pipeline management infrastructure.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Full-Stack SaaS Expertise
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Comprehensive capabilities across the entire SaaS growth lifecycle.
          </p>
        </div>

        {/* Capabilities - Horizontal Rows */}
        <div className="space-y-0">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {capability.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">
                  {capability.title}
                </h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
