"use client";

import { useState } from "react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Can you guarantee trending on Twitter/X?",
      answer:
        "While no one can guarantee organic trends (and you should run from anyone who does), we engineer campaigns with the highest probability of trending through coordinated timing, influencer activation, fan army mobilization, and algorithm-optimized content. Our campaigns have achieved 40+ trending hashtags in the past year.",
    },
    {
      question: "What kind of press coverage can you secure?",
      answer:
        "We have relationships with editors at Billboard, Rolling Stone, Variety, Complex, Pitchfork, The Hollywood Reporter, Hypebeast, and 200+ entertainment publications. Coverage depends on your story angle and newsworthiness, but we consistently secure tier-1 placements for our clients.",
    },
    {
      question: "How do you create viral moments?",
      answer:
        "Viral is engineered, not accidental. We identify cultural conversations to insert into, create highly shareable content formats, coordinate influencer seeding, activate fan communities, and optimize posting times. Then we amplify what catches fire with paid support and real-time content.",
    },
    {
      question: "Do you work with independent artists or only major labels?",
      answer:
        "We work across the spectrum—from independent artists building their first fanbase to major label releases and studio film campaigns. Our strategies scale based on your budget, goals, and current audience size.",
    },
    {
      question: "How much does entertainment PR and hype creation cost?",
      answer:
        "Campaign investment varies based on scope and timeline. Single releases start at $15K, album/film campaigns range from $50K-250K, and ongoing artist development retainers start at $10K/month. Schedule a call to discuss your specific project.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our entertainment marketing
              services.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
