import Button from "@/components/ui/Button";
import Image from "next/image";

export default function HeroSection() {
  return (
    <section className="relative bg-white">
      <div className="flex flex-col lg:flex-row min-h-[70vh]">
        {/* Left Content Panel */}
        <div className="flex-1 flex items-center px-6 md:px-12 lg:px-16 xl:px-24 py-12 lg:py-0">
          <div className="max-w-xl">
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Media & Entertainment Solutions
            </p>

            <h1
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Build the hype. Own the conversation.
            </h1>

            <p className="text-base text-gray-600 leading-relaxed mb-8">
              We help entertainment brands, artists, studios, and content creators
              dominate social feeds, trend on X/Twitter, and generate the viral
              buzz that turns releases into cultural moments. Our campaigns average
              500M+ earned impressions per launch.
            </p>

            <Button href="/company/contact">Start Your Campaign</Button>
          </div>
        </div>

        {/* Right Image Panel */}
        <div className="flex-1 relative min-h-[300px] lg:min-h-0">
          <Image
            src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=1600&q=80"
            alt="Media Entertainment"
            fill
            className="object-cover"
          />
        </div>
      </div>
    </section>
  );
}
