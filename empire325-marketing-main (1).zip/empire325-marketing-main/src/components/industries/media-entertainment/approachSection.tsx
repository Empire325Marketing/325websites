export default function ApproachSection() {
  const steps = [
    {
      num: "01",
      title: "Research",
      description:
        "Deep dive into your audience, competitive landscape, trending conversations, and cultural moments to hijack.",
    },
    {
      num: "02",
      title: "Strategize",
      description:
        "Build a multi-phase rollout calendar with teaser campaigns, coordinated drops, and press embargo timelines.",
    },
    {
      num: "03",
      title: "Ignite",
      description:
        "Launch coordinated campaigns across social, press, influencers, and fan communities to spark viral momentum.",
    },
    {
      num: "04",
      title: "Amplify",
      description:
        "Pour fuel on what works—real-time optimization, trend jacking, and sustained content to extend the conversation.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Our Approach
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            From zero to trending
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            A battle-tested playbook for manufacturing cultural moments.
          </p>
        </div>

        {/* 4 Column Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200">
          {steps.map((step) => (
            <div key={step.num} className="bg-white p-8">
              <span className="text-5xl font-black text-black block mb-4">
                {step.num}
              </span>
              <h3 className="text-xl font-bold text-black mb-3">{step.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
