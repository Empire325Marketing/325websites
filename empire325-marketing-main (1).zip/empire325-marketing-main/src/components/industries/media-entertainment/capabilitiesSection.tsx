export default function CapabilitiesSection() {
  const capabilities = [
    {
      title: "Twitter/X Trend Campaigns",
      description:
        "Coordinated hashtag launches, stan army activation, and real-time trend jacking to dominate the trending tab. We engineer organic-looking viral moments that spark conversation and earned media.",
    },
    {
      title: "Entertainment PR & Press",
      description:
        "Tier-1 placements in Billboard, Variety, Rolling Stone, Complex, Pitchfork, and The Hollywood Reporter. Exclusive premieres, album reviews, artist profiles, and red carpet coverage.",
    },
    {
      title: "Blog & Editorial Networks",
      description:
        "Coordinated coverage across music blogs, entertainment sites, fan forums, and niche publications. We seed stories that get picked up and amplified across the media ecosystem.",
    },
    {
      title: "Influencer & Creator Seeding",
      description:
        "Strategic partnerships with TikTok creators, YouTube reactors, podcast hosts, and Instagram tastemakers. Authentic integration that drives discovery and fan conversion.",
    },
    {
      title: "Fan Community Building",
      description:
        "Discord server strategy, Reddit AMAs, fan site partnerships, and stan account coordination. We build the grassroots infrastructure that sustains long-term artist-fan relationships.",
    },
    {
      title: "Meme & Viral Content",
      description:
        "Custom meme creation, reaction content, shareable moments, and algorithm-optimized clips designed to spread. We create the assets that fans want to share.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Full-Stack Hype Machine
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Every channel. Every platform. Complete cultural domination.
          </p>
        </div>

        {/* Capabilities - Horizontal Rows */}
        <div className="space-y-0">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {capability.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">
                  {capability.title}
                </h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
