import Button from "@/components/ui/Button";

export default function ServicesSection() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Entertainment Marketing & Hype Creation
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that turn releases into trending topics and
            artists into household names.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Viral Hype Engineering
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Strategic campaign architecture designed to break through the noise.
              We orchestrate coordinated drops across X/Twitter, Instagram, TikTok,
              and Reddit to manufacture trending moments. Hashtag takeovers, fan
              army mobilization, and algorithm-optimized content that puts you on
              the Explore page and trending tab.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Industry PR & Press Coverage
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Placement in Billboard, Variety, Rolling Stone, Pitchfork, The
              Hollywood Reporter, and top-tier entertainment media. We secure
              exclusive premieres, interviews, and feature stories that establish
              credibility and amplify reach. Our media relationships turn press
              cycles into sustained buzz.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Content & Community Strategy
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Blog networks, fan site partnerships, Discord community building,
              and influencer seeding that creates authentic grassroots momentum.
              We build the content ecosystem—memes, reaction videos, stan Twitter
              threads—that makes audiences feel invested in your success.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
