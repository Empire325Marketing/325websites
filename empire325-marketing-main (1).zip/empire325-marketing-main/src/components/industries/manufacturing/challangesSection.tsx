'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

const challenges = [
  {
    challenge: 'Complex B2B Sales Cycles',
    description: 'Navigating extended procurement processes with multiple stakeholders, technical specifications, and approval workflows.',
    solution: 'Multi-stage nurturing campaigns designed for long B2B sales cycles with automated touchpoints at each decision stage.',
  },
  {
    challenge: 'Technical Product Communication',
    description: 'Translating complex manufacturing capabilities and technical specifications into compelling business value propositions.',
    solution: 'Technical marketing expertise that bridges engineering language and business benefits for procurement decision-makers.',
  },
  {
    challenge: 'Global Market Expansion',
    description: 'Scaling beyond local and regional markets while managing international compliance, cultural differences, and distribution.',
    solution: 'Multi-market expansion strategies with localized content, compliance frameworks, and distributor recruitment programs.',
  },
  {
    challenge: 'Digital Transformation',
    description: 'Modernizing traditional industrial marketing approaches while maintaining technical credibility and relationship-based sales.',
    solution: 'Phased digital integration that respects traditional B2B relationships while building modern acquisition channels.',
  },
];

export default function ChallengesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Challenges & Solutions
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-[2.75rem] font-bold text-slate-900 dark:text-white leading-tight mb-4 max-w-3xl">
            Navigating industrial marketing complexity
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
            We help you overcome common B2B obstacles while driving sustainable pipeline growth.
          </p>
        </motion.div>

        {/* Challenges List */}
        <div className="space-y-6">
          {challenges.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="grid lg:grid-cols-2 gap-6"
            >
              {/* Challenge */}
              <div className="p-6 bg-white dark:bg-slate-900/50 rounded-2xl">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                      {item.challenge}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Solution */}
              <div className="p-6 bg-[#0bc7cd]/5 dark:bg-[#0bc7cd]/10 rounded-2xl">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[#0bc7cd]/20 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-[#0bc7cd]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                      Our Solution
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                      {item.solution}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
