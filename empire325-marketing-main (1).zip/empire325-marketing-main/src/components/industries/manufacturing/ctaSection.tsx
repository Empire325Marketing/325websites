// components/manufacturing/CTASection.tsx
'use client';

import { motion } from 'framer-motion';
import { ArrowRight, FileText } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-6 lg:px-8 max-w-[90vw]">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-8 leading-tight">
              Ready to Scale Your Manufacturing Business?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 mb-10 leading-relaxed">
              Get your free manufacturing marketing assessment and discover strategies to generate more B2B inquiries, shorten sales cycles, and expand into new industrial markets.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-[#0bc7cd] hover:bg-[#0aafb5] text-white font-semibold transition-colors duration-200"
                onClick={() => window.location.href="/company/contact"}
              >
                Get Your Assessment
                <ArrowRight className="w-5 h-5" />
              </button>
              {/* <button className="inline-flex items-center justify-center gap-3 px-8 py-4 border-2 border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-900 dark:text-white font-semibold transition-colors duration-200">
                <FileText className="w-5 h-5" />
                Download Guide
              </button> */}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-white dark:bg-gray-900 p-10 border-l-4 border-[#0bc7cd]"
          >
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
              What's Included
            </h3>
            <ul className="space-y-6">
              {[
                'Comprehensive industrial market analysis',
                'Competitor positioning assessment',
                'B2B lead generation strategy',
                'Technical marketing recommendations',
                'Sales cycle optimization plan',
                'Global expansion opportunities'
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-4">
                  <div className="w-6 h-6 bg-[#0bc7cd] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="w-2 h-2 bg-white"></div>
                  </div>
                  <span className="text-gray-700 dark:text-gray-300 text-lg">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}