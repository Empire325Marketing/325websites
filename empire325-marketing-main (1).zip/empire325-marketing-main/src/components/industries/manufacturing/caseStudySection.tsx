'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import Image from 'next/image';

export default function CaseStudySection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const stats = [
    { value: '600%', label: 'International Inquiries' },
    { value: '$2.2M', label: 'New Equipment Sales' },
    { value: '40%', label: 'Shorter Sales Cycle' },
    { value: '2', label: 'New Countries' },
  ];

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Case Study Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="relative rounded-3xl overflow-hidden"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <Image
              src="https://images.unsplash.com/photo-1565043666747-69f6646db940?w=1200&q=80"
              alt="Industrial Equipment"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-slate-900/85" />
          </div>

          {/* Content */}
          <div className="relative px-8 md:px-16 py-16 md:py-20">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/20 rounded-full mb-6">
              <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
              <span className="text-sm font-medium text-[#0bc7cd]">
                Case Study
              </span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4 max-w-3xl">
              Industrial Equipment Manufacturer Success
            </h2>

            <p className="text-lg text-slate-300 mb-12 max-w-2xl">
              How we helped an industrial equipment manufacturer achieve global expansion and substantial revenue growth.
            </p>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl text-center"
                >
                  <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                    {stat.value}
                  </div>
                  <p className="text-slate-400 text-sm">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
}
