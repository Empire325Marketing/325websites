// components/manufacturing/StatsIntegration.tsx
'use client';

import { motion } from 'framer-motion';

export default function StatsIntegration() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-6 lg:px-8 max-w-[90vw]">
        <div className="grid lg:grid-cols-5 gap-8 items-center">
          {/* Left Description */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2"
          >
            <p className="text-lg leading-relaxed">
              Trusted by leading manufacturing companies to drive measurable B2B growth and industrial market penetration.
            </p>
          </motion.div>

          {/* Right Stats */}
          <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: '$3M+', label: 'Worth Deals Influenced' },
              { value: '400%', label: 'B2B Inquiries' },
              { value: '55%', label: 'Shorter Sales Cycle' },
              { value: '85%', label: 'Lead Quality Improvement' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="text-center md:text-left"
              >
                <p className="text-3xl font-bold mb-1">{stat.value}</p>
                <p className="text-xs">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}