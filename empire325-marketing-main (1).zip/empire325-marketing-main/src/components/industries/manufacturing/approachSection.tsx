'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import Image from 'next/image';

export default function ApproachSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Split Layout - Image Left, Content Right */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">

          {/* Left - Large Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative h-[500px] lg:h-[600px] rounded-3xl overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80"
                alt="Manufacturing Process"
                fill
                className="object-cover"
              />
              {/* Floating Stats Card */}
              <div className="absolute bottom-6 left-6 right-6 p-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm rounded-2xl">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#0bc7cd]">400%</div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">B2B Growth</p>
                  </div>
                  <div className="text-center border-x border-slate-200 dark:border-slate-700">
                    <div className="text-2xl font-bold text-[#0bc7cd]">55%</div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Faster Cycle</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#0bc7cd]">$75M+</div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Influenced</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right - Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
              <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
              <span className="text-sm font-medium text-[#0bc7cd]">
                Our Approach
              </span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white leading-tight mb-6">
              Data-driven industrial marketing that delivers
            </h2>

            <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed mb-10">
              We combine advanced industrial analytics with proven B2B methodologies to maximize
              market penetration and accelerate sales velocity. Every strategy is backed by data
              and optimized for measurable pipeline growth.
            </p>

            {/* Numbered List */}
            <div className="space-y-6">
              {[
                { num: '01', title: 'Analyze', desc: 'Deep market analysis, buyer behavior patterns, and competitive positioning.' },
                { num: '02', title: 'Strategize', desc: 'Custom B2B roadmap focused on high-value industrial opportunities.' },
                { num: '03', title: 'Execute', desc: 'Multi-channel campaigns across LinkedIn, trade shows, and industry publications.' },
                { num: '04', title: 'Optimize', desc: 'Continuous performance tracking and strategy refinement for maximum ROI.' },
              ].map((item, index) => (
                <div key={index} className="flex gap-4">
                  <span className="text-4xl font-bold text-slate-200 dark:text-slate-800">{item.num}</span>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{item.title}</h3>
                    <p className="text-slate-600 dark:text-slate-400 text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
}
