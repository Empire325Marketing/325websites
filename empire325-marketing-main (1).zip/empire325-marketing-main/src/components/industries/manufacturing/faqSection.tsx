'use client';

import { useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { ChevronDown, ArrowRight, CheckCircle2 } from 'lucide-react';
import Image from 'next/image';

export default function FAQSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'What type of sales pipeline growth can I expect?',
      answer: 'Manufacturing clients typically see 3-5x increase in qualified B2B inquiries and 40-60% reduction in sales cycle length within the first year through our systematic industrial marketing approach.',
    },
    {
      question: 'How does Empire 325 approach technical marketing optimization?',
      answer: 'We combine technical expertise with marketing best practices, translating complex manufacturing capabilities into compelling business value propositions that resonate with procurement decision-makers.',
    },
    {
      question: 'How does Empire 325 measure manufacturing marketing ROI?',
      answer: 'We track industrial-specific metrics including RFQ volume, qualified lead quality, sales cycle length, average order value, and marketing-influenced revenue to provide clear ROI visibility.',
    },
    {
      question: 'What is Industry 4.0 Marketing Integration?',
      answer: 'Industry 4.0 marketing promotes smart manufacturing solutions, IoT integration, and connected factory technologies through strategic content, demonstrations, and technical proof points.',
    },
    {
      question: 'How much does comprehensive manufacturing marketing cost?',
      answer: 'Investment varies by company size and market scope. Programs start at $15K/month for single-facility manufacturers to comprehensive enterprise packages. All include technical marketing, lead generation, and analytics.',
    },
  ];

  const benefits = [
    'Free industrial assessment',
    'Custom B2B strategy',
    'Pipeline projections',
    'No obligation consultation',
  ];

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20 mb-20">

          {/* Left - Sticky Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="lg:col-span-4 lg:sticky lg:top-32 lg:self-start"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
              <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
              <span className="text-sm font-medium text-[#0bc7cd]">
                FAQ
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white leading-tight mb-4">
              Common questions
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400">
              Everything you need to know about our manufacturing marketing services.
            </p>
          </motion.div>

          {/* Right - FAQ Accordion */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-8 space-y-3"
          >
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white dark:bg-slate-900/50 rounded-2xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-semibold text-slate-900 dark:text-white pr-4">
                    {faq.question}
                  </span>
                  <motion.div
                    animate={{ rotate: openIndex === index ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                    className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0"
                  >
                    <ChevronDown className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  </motion.div>
                </button>
                <AnimatePresence>
                  {openIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="px-5 pb-5 text-slate-600 dark:text-slate-400 leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </motion.div>

        </div>

        {/* CTA Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="relative rounded-3xl overflow-hidden"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <Image
              src="https://images.unsplash.com/photo-1565043666747-69f6646db940?w=1200&q=80"
              alt="Manufacturing"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-slate-900/90" />
          </div>

          {/* Content */}
          <div className="relative px-8 md:px-16 py-16 md:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">

              {/* Left Content */}
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/20 rounded-full mb-6">
                  <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
                  <span className="text-sm font-medium text-[#0bc7cd]">
                    Get Started
                  </span>
                </div>

                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
                  Ready to scale your B2B pipeline?
                </h2>

                <p className="text-lg text-slate-300 leading-relaxed mb-8">
                  Get your free industrial marketing assessment and discover how we can help
                  you accelerate B2B sales and grow your manufacturing business.
                </p>

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => window.location.href = '/company/contact'}
                    className="group inline-flex items-center gap-3 px-8 py-4 bg-[#0bc7cd] text-white font-semibold rounded-lg hover:bg-[#0ab4ba] transition-colors"
                  >
                    Schedule Strategy Session
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Right - Benefits */}
              <div className="lg:pl-12">
                <div className="p-8 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10">
                  <h3 className="text-xl font-bold text-white mb-6">
                    What you'll get
                  </h3>
                  <div className="space-y-4">
                    {benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-[#0bc7cd] flex-shrink-0" />
                        <span className="text-slate-300">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
}
