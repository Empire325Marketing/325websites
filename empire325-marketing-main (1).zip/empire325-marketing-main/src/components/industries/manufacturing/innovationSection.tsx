'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Cpu, Eye, FileText, Network } from 'lucide-react';

const innovations = [
  {
    icon: Cpu,
    title: 'Industry 4.0 Marketing',
    description: 'Promoting smart manufacturing solutions, IoT integration, and connected factory technologies.',
  },
  {
    icon: Eye,
    title: 'Virtual Factory Tours',
    description: 'Interactive digital experiences that showcase manufacturing capabilities and quality processes.',
  },
  {
    icon: FileText,
    title: 'Technical Content Automation',
    description: 'AI-powered generation of technical documentation, specification sheets, and capability presentations.',
  },
  {
    icon: Network,
    title: 'Supply Chain Transparency',
    description: 'Real-time visibility platforms that demonstrate manufacturing capacity and delivery capabilities.',
  },
];

export default function InnovationsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Innovation
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-[2.75rem] font-bold text-slate-900 dark:text-white leading-tight mb-4">
            Manufacturing marketing innovations
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
            Cutting-edge strategies driving the future of industrial B2B marketing.
          </p>
        </motion.div>

        {/* Innovations Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {innovations.map((innovation, index) => (
            <div
              key={index}
              className="group p-8 bg-slate-50 dark:bg-slate-900/50 rounded-2xl hover:bg-[#0bc7cd]/5 dark:hover:bg-[#0bc7cd]/10 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0bc7cd]/10 flex items-center justify-center mb-6 group-hover:bg-[#0bc7cd]/20 transition-colors">
                <innovation.icon className="w-6 h-6 text-[#0bc7cd]" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
                {innovation.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-sm">
                {innovation.description}
              </p>
            </div>
          ))}
        </motion.div>

      </div>
    </section>
  );
}
