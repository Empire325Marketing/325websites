'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Cog, FileText, Globe, Database, BarChart3, Settings } from 'lucide-react';

const capabilities = [
  {
    icon: Cog,
    title: 'ERP Integration',
    description: 'SAP, Oracle, and Microsoft Dynamics manufacturing system integration.',
  },
  {
    icon: Database,
    title: 'CRM Platforms',
    description: 'Salesforce Manufacturing Cloud and HubSpot Industrial optimization.',
  },
  {
    icon: Settings,
    title: 'CAD Integration',
    description: 'AutoCAD, SolidWorks, and technical documentation systems.',
  },
  {
    icon: BarChart3,
    title: 'Supply Chain Analytics',
    description: 'Real-time supply chain visibility and performance tracking.',
  },
  {
    icon: FileText,
    title: 'Technical Documentation',
    description: 'Complex specification presentation and capability marketing.',
  },
  {
    icon: Globe,
    title: 'Global Market Entry',
    description: 'Multi-language, multi-currency international expansion support.',
  },
];

export default function ExpertiseSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="py-28 bg-white dark:bg-[#0a0a0a]">
      <div className="max-w-[90vw] mx-auto">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/10 rounded-full mb-6">
            <span className="w-2 h-2 bg-[#0bc7cd] rounded-full" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Why Choose Us
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-[2.75rem] font-bold text-slate-900 dark:text-white leading-tight mb-4">
            Industry-leading technology
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
            Comprehensive capabilities across the entire manufacturing marketing technology stack.
          </p>
        </motion.div>

        {/* Capabilities Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12"
        >
          {capabilities.map((capability, index) => (
            <div key={index} className="group">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#0bc7cd] flex items-center justify-center flex-shrink-0">
                  <capability.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                    {capability.title}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {capability.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </motion.div>

      </div>
    </section>
  );
}
