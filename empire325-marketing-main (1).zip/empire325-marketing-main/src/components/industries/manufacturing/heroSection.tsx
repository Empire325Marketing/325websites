'use client';

import { motion } from 'framer-motion';
import { Factory, ArrowRight, TrendingUp, Users, Zap } from 'lucide-react';
import Image from 'next/image';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen bg-slate-900 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1565043666747-69f6646db940?w=1600&q=80"
          alt="Manufacturing"
          fill
          className="object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/50 via-slate-900/80 to-slate-900" />
      </div>

      <div className="relative max-w-[90vw] mx-auto pt-32 lg:pt-40 pb-20">

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0bc7cd]/20 rounded-full mb-8">
            <Factory className="w-4 h-4 text-[#0bc7cd]" />
            <span className="text-sm font-medium text-[#0bc7cd]">
              Manufacturing Solutions
            </span>
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.05] tracking-tight mb-8">
            Industrial marketing that{' '}
            <span className="text-[#0bc7cd]">drives B2B growth</span>
          </h1>

          <p className="text-xl md:text-2xl text-slate-300 leading-relaxed mb-10 max-w-3xl">
            We help manufacturing companies and industrial leaders scale B2B sales
            with data-driven marketing strategies and technical expertise.
          </p>

          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => window.location.href = '/company/contact'}
              className="group inline-flex items-center gap-3 px-8 py-4 bg-[#0bc7cd] text-white font-semibold rounded-lg hover:bg-[#0ab4ba] transition-colors"
            >
              Get Industrial Assessment
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => window.location.href = '/services'}
              className="inline-flex items-center gap-3 px-8 py-4 text-white font-semibold border-2 border-white/20 rounded-lg hover:bg-white/10 transition-colors"
            >
              View Services
            </button>
          </div>
        </motion.div>

        {/* Bento Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {/* Large Featured Stat */}
          <div className="col-span-2 p-8 bg-[#0bc7cd] rounded-2xl">
            <TrendingUp className="w-8 h-8 text-white/80 mb-4" />
            <div className="text-5xl lg:text-6xl font-bold text-white mb-2">400%</div>
            <p className="text-white/80 text-lg">Average increase in B2B inquiries</p>
          </div>

          {/* Stat 2 */}
          <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
            <div className="text-3xl lg:text-4xl font-bold text-white mb-2">$75M+</div>
            <p className="text-slate-400">Deals Influenced</p>
          </div>

          {/* Stat 3 */}
          <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl">
            <div className="text-3xl lg:text-4xl font-bold text-white mb-2">55%</div>
            <p className="text-slate-400">Shorter Sales Cycle</p>
          </div>

          {/* Bottom row */}
          <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#0bc7cd]/20 flex items-center justify-center">
              <Users className="w-6 h-6 text-[#0bc7cd]" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">100+</div>
              <p className="text-slate-400 text-sm">Industrial Clients</p>
            </div>
          </div>

          <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#0bc7cd]/20 flex items-center justify-center">
              <Zap className="w-6 h-6 text-[#0bc7cd]" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">85%</div>
              <p className="text-slate-400 text-sm">Lead Quality Lift</p>
            </div>
          </div>

          {/* Wide stat */}
          <div className="col-span-2 p-6 bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm border border-white/10 rounded-2xl">
            <p className="text-slate-400 mb-2">Trusted by</p>
            <div className="text-3xl font-bold text-white">Equipment, Component & Process Manufacturers</div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
