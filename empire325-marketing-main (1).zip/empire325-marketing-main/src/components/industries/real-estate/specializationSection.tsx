export default function SpecializationsSection() {
  const specializations = [
    {
      title: "Residential Real Estate",
      description:
        "Luxury home marketing, first-time buyer campaigns, move-up buyer strategies, and senior living transitions.",
    },
    {
      title: "Commercial Real Estate",
      description:
        "Office space marketing, retail property promotion, industrial real estate, and investment property campaigns.",
    },
    {
      title: "PropTech & Innovation",
      description:
        "Real estate app development, property management platforms, analytics tools, and blockchain integration.",
    },
    {
      title: "New Construction",
      description:
        "Pre-sale marketing campaigns, builder partnerships, community launches, and model home strategies.",
    },
    {
      title: "Investment Properties",
      description:
        "ROI-focused marketing for investors, portfolio marketing, and institutional buyer acquisition.",
    },
    {
      title: "Luxury Properties",
      description:
        "High-net-worth buyer targeting, exclusive listing strategies, and premium property positioning.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Real Estate Specializations
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Expert marketing solutions across residential, commercial, and
            PropTech sectors.
          </p>
        </div>

        {/* Specializations - Horizontal Rows */}
        <div className="space-y-0">
          {specializations.map((spec, index) => (
            <div
              key={index}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 py-8 border-t border-gray-800"
            >
              <div className="md:col-span-1 flex items-center gap-4 md:block">
                <span className="text-[#0dc2cc] font-bold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white md:hidden">
                  {spec.title}
                </h3>
              </div>
              <div className="hidden md:block md:col-span-3">
                <h3 className="text-lg font-bold text-white">{spec.title}</h3>
              </div>
              <div className="md:col-span-8">
                <p className="text-gray-400 leading-relaxed">
                  {spec.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
