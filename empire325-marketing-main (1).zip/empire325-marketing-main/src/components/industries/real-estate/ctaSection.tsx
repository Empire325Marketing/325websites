// components/real-estate/CTASection.tsx
'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Calendar } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-32 bg-gradient-to-br from-[#0bc7cd] to-[#0aafb5] dark:from-[#0bc7cd] dark:to-[#0aafb5] text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      <div className="container mx-auto px-6 lg:px-8 max-w-[90vw] relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 leading-tight">
            Ready to Accelerate Your Property Sales?
          </h2>
          <p className="text-xl text-white mb-12 leading-relaxed">
            Get your free real estate marketing assessment and discover strategies to sell properties faster, generate more qualified leads, and dominate your local market.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-white text-[#0bc7cd] font-semibold rounded-lg hover:bg-[#0bc7cd]/10 transition-colors duration-200 shadow-xl"
              onClick={() => window.location.href="/company/contact"}
            >
              Get Your Free Assessment
              <ArrowRight className="w-5 h-5" />
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 border-2 border-white/30 hover:border-white/50 text-white font-semibold rounded-lg transition-colors duration-200"
              onClick={() => window.location.href="/company/contact"}
            >
              <Calendar className="w-5 h-5" />
              Schedule Consultation
            </motion.button>
          </div>

          {/* Trust Indicators */}
          {/* <div className="flex items-center justify-center gap-12 mt-16 pt-12 border-t border-white/20">
            <div className="text-center">
              <p className="text-3xl font-bold mb-1">$500M+</p>
              <p className="text-sm text-white">Properties Marketed</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold mb-1">75%</p>
              <p className="text-sm text-white">Faster Sales</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold mb-1">300%</p>
              <p className="text-sm text-white">More Leads</p>
            </div>
          </div> */}
        </motion.div>
      </div>
    </section>
  );
}