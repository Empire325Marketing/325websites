// components/real-estate/MetricsBar.tsx
'use client';

import { motion } from 'framer-motion';

export default function MetricsBar() {
  return (
    <section className="py-20 border-y border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-6 lg:px-8 max-w-[90vw]">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-2">
              $500M+
            </div>
            <div className="h-px w-16 bg-[#0bc7cd] mx-auto lg:mx-0 mb-3"></div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Property value marketed
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-2">
              300%
            </div>
            <div className="h-px w-16 bg-[#0bc7cd] mx-auto lg:mx-0 mb-3"></div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Increase in qualified buyer leads
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-2">
              75%
            </div>
            <div className="h-px w-16 bg-[#0bc7cd] mx-auto lg:mx-0 mb-3"></div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Faster average time to sale
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center lg:text-left"
          >
            <div className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-2">
              90%
            </div>
            <div className="h-px w-16 bg-[#0bc7cd] mx-auto lg:mx-0 mb-3"></div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Improvement in listing visibility
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}