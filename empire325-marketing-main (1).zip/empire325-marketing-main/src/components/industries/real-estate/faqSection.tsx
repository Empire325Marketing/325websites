"use client";

import { useState } from "react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What type of sales velocity improvement can I expect?",
      answer:
        "Most clients see properties selling 50-75% faster than market average, with improved pricing due to better positioning and increased buyer interest through multi-channel marketing.",
    },
    {
      question: "How do you approach property marketing optimization?",
      answer:
        "We start with comprehensive market analysis, optimize property presentation through professional media, implement targeted digital campaigns, and track performance metrics to continuously improve results.",
    },
    {
      question: "How do you measure real estate marketing ROI?",
      answer:
        "We track lead quality, cost per acquisition, days on market, sale price vs. list price ratio, and overall marketing spend efficiency to provide clear ROI metrics.",
    },
    {
      question: "What is PropTech Integration Marketing?",
      answer:
        "PropTech integration combines real estate technology platforms (virtual tours, CRM systems, automation) with strategic marketing to create seamless experiences for buyers, sellers, and agents.",
    },
    {
      question: "How much does comprehensive real estate marketing cost?",
      answer:
        "Investment varies by market and property type. Packages start at $5K/month for individual agents to comprehensive programs for brokerages and developers.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* FAQ Section - Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Header */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              FAQ
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Common questions
            </h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Everything you need to know about our real estate marketing
              services.
            </p>
          </div>

          {/* Right - FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200">
                <button
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="w-full flex items-center justify-between py-6 text-left"
                >
                  <span className="font-bold text-black pr-4">
                    {faq.question}
                  </span>
                  <span className="text-[#0dc2cc] text-2xl flex-shrink-0">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>
                {openIndex === index && (
                  <div className="pb-6 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
