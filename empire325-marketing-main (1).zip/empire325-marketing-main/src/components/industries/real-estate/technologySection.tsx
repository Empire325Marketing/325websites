export default function TechnologySection() {
  const capabilities = [
    {
      title: "MLS Integration",
      description:
        "Complete IDX setup and property syndication systems for maximum listing exposure.",
    },
    {
      title: "CRM Optimization",
      description:
        "Chime, Follow Up Boss, Top Producer, and KVCore platform optimization and integration.",
    },
    {
      title: "Virtual Technology",
      description:
        "Matterport 3D tours, virtual staging, and drone photography integration.",
    },
    {
      title: "Analytics Platforms",
      description:
        "Real estate market analytics and comprehensive performance tracking dashboards.",
    },
    {
      title: "Drone & Aerial Video",
      description:
        "Cinematic property footage and neighborhood showcase content production.",
    },
    {
      title: "Market Intelligence",
      description:
        "Real-time comparative market analysis and pricing recommendation systems.",
    },
  ];

  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Why Choose Us
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Industry-leading technology
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Comprehensive capabilities across the entire real estate marketing
            technology stack.
          </p>
        </div>

        {/* 3x2 Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-gray-200">
          {capabilities.map((capability, index) => (
            <div key={index} className="bg-white p-8">
              <h3 className="text-lg font-bold text-black mb-3">
                {capability.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {capability.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
