import Button from "@/components/ui/Button";

export default function ServicesSection() {
  return (
    <section className="py-24 bg-white px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Do
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Real Estate Marketing Services
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three core capabilities that drive faster property sales and
            maximize market value for real estate professionals.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Property Marketing Excellence
            </h3>
            <p className="text-gray-600 leading-relaxed">
              We understand what attracts qualified buyers and creates seller
              confidence. Professional photography, virtual tours, drone footage,
              and strategic positioning maximize property appeal. Our listings
              generate 300% more qualified leads on average.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Multi-Channel Lead Generation
            </h3>
            <p className="text-gray-600 leading-relaxed">
              84% of home buyers start their search online. We create integrated
              campaigns across Google Ads, Facebook, Instagram, and email that
              attract qualified prospects. Our clients see 40% lower cost per
              lead compared to industry averages.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              PropTech Integration
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Custom real estate platforms, IDX/MLS integration, virtual tour
              systems, and client portal development. We modernize the property
              experience with technology that gives you a competitive edge in
              today&apos;s digital-first market.
            </p>
          </div>
        </div>

        <Button href="/services">Explore our services</Button>
      </div>
    </section>
  );
}
