// components/real-estate/CaseStudySection.tsx
'use client';

import { motion } from 'framer-motion';
import { ArrowRight, TrendingUp } from 'lucide-react';

export default function CaseStudySection() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-6 lg:px-8 max-w-[90vw]">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-block px-6 py-2 bg-[#0bc7cd] text-white text-sm font-semibold rounded-full mb-6">
            Success Story
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Luxury Real Estate Agency Success
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            How we helped a luxury real estate agency achieve market dominance through strategic digital marketing
          </p>
        </motion.div>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative">
              {/* Placeholder for luxury property image */}
              <div className="aspect-[4/3] bg-gradient-to-br from-[#0bc7cd] to-purple-600 rounded-2xl overflow-hidden shadow-2xl">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white">
                    <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-semibold opacity-75">Luxury Property Portfolio</p>
                  </div>
                </div>
              </div>
              
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -right-6 bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 border border-gray-200 dark:border-gray-700">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Total Sales Value</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">$100M</p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">18 months</p>
              </div>
            </div>
          </motion.div>

          {/* Right - Metrics */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            <div className="border-l-4 border-[#0bc7cd] pl-8">
              <p className="text-6xl font-bold text-gray-900 dark:text-white mb-2">500%</p>
              <p className="text-gray-600 dark:text-gray-400">increase in high-end property inquiries</p>
            </div>

            <div className="border-l-4 border-purple-600 pl-8">
              <p className="text-6xl font-bold text-gray-900 dark:text-white mb-2">$100M</p>
              <p className="text-gray-600 dark:text-gray-400">in luxury property sales within 18 months</p>
            </div>

            <div className="border-l-4 border-green-600 pl-8">
              <p className="text-6xl font-bold text-gray-900 dark:text-white mb-2">60%</p>
              <p className="text-gray-600 dark:text-gray-400">improvement in cost per qualified lead</p>
            </div>

            <div className="border-l-4 border-orange-600 pl-8">
              <p className="text-6xl font-bold text-gray-900 dark:text-white mb-2">2</p>
              <p className="text-gray-600 dark:text-gray-400">successful expansion to new luxury markets</p>
            </div>

            {/* <button className="group inline-flex items-center gap-3 px-8 py-4 bg-[#0bc7cd] hover:bg-[#0aafb5] text-white font-semibold rounded-lg transition-colors duration-200 mt-8">
              Read Full Case Study
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-200" />
            </button> */}
          </motion.div>
        </div>
      </div>
    </section>
  );
}