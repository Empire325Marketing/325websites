export default function InnovationsSection() {
  const innovations = [
    {
      title: "Virtual Reality Property Tours",
      description:
        "Immersive VR experiences that allow remote property viewing and international buyer engagement.",
    },
    {
      title: "AI-Powered Property Matching",
      description:
        "Machine learning algorithms that match buyers with properties based on preferences and behavior patterns.",
    },
    {
      title: "Social Media Property Promotion",
      description:
        "Strategic social media campaigns that showcase properties and generate qualified buyer interest.",
    },
    {
      title: "Automated Market Analysis",
      description:
        "Real-time comparative market analysis and pricing recommendations based on current market conditions.",
    },
  ];

  return (
    <section className="py-24 bg-black px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Innovation
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Real Estate Marketing Innovations
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Cutting-edge technology driving the future of property marketing.
          </p>
        </div>

        {/* 2x2 Grid */}
        <div className="grid md:grid-cols-2 gap-px bg-gray-800">
          {innovations.map((innovation, index) => (
            <div key={index} className="bg-black p-8">
              <div className="flex items-start gap-4 mb-4">
                <span className="text-[#0dc2cc] font-bold text-sm">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-bold text-white">
                  {innovation.title}
                </h3>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed pl-8">
                {innovation.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
