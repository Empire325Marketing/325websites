type JsonLdProps = {
  data: Record<string, unknown>;
};

export default function JsonLd({ data }: JsonLdProps) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

// Organization Schema
export const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Empire325 Marketing",
  url: "https://empire325marketing.com",
  logo: "https://empire325marketing.com/logo.png",
  description:
    "Empire325 Marketing delivers enterprise-grade digital marketing solutions. From AI-powered tools to full-funnel advertising, we help businesses scale with data-driven strategies.",
  contactPoint: {
    "@type": "ContactPoint",
    telephone: "+1-310-985-3782",
    contactType: "customer service",
    email: "support@empire325marketing.com",
    availableLanguage: "English",
  },
  sameAs: [
    "https://twitter.com/empire325",
    "https://linkedin.com/company/empire325",
  ],
  address: {
    "@type": "PostalAddress",
    addressCountry: "US",
  },
};

// Website Schema
export const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "Empire325 Marketing",
  url: "https://empire325marketing.com",
  potentialAction: {
    "@type": "SearchAction",
    target: "https://empire325marketing.com/search?q={search_term_string}",
    "query-input": "required name=search_term_string",
  },
};

// Service Schema Generator
export const createServiceSchema = (
  name: string,
  description: string,
  url: string
) => ({
  "@context": "https://schema.org",
  "@type": "Service",
  serviceType: name,
  name: name,
  description: description,
  provider: {
    "@type": "Organization",
    name: "Empire325 Marketing",
    url: "https://empire325marketing.com",
  },
  url: url,
  areaServed: {
    "@type": "Country",
    name: "United States",
  },
});

// FAQ Schema Generator
export const createFaqSchema = (faqs: { question: string; answer: string }[]) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
});

// BreadcrumbList Schema Generator
export const createBreadcrumbSchema = (
  items: { name: string; url: string }[]
) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: items.map((item, index) => ({
    "@type": "ListItem",
    position: index + 1,
    name: item.name,
    item: item.url,
  })),
});

// Professional Service Schema (for specific services)
export const createProfessionalServiceSchema = (
  name: string,
  description: string,
  url: string,
  services: string[]
) => ({
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: name,
  description: description,
  url: url,
  provider: {
    "@type": "Organization",
    name: "Empire325 Marketing",
  },
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Marketing Services",
    itemListElement: services.map((service) => ({
      "@type": "Offer",
      itemOffered: {
        "@type": "Service",
        name: service,
      },
    })),
  },
});
