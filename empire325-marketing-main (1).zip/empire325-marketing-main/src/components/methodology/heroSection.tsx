export default function HeroSection() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column - Main Content */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Methodology
            </p>
            <h1
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-8"
              style={{ fontWeight: 1000 }}
            >
              How Empire325 Delivers Integrated Marketing Infrastructure
            </h1>
            <p className="text-base text-gray-600 leading-relaxed mb-6">
              Marketing effectiveness is measured through business outcomes—customer acquisition cost, return on investment, pipeline contribution, and revenue attribution. These outcomes require integrated infrastructure connecting strategy, technical execution, and comprehensive measurement as unified operating system.
            </p>
          </div>

          {/* Right Column */}
          <div className="flex flex-col justify-center">
            <div className="border-l-2 border-[#0dc2cc] pl-8">
              <p className="text-base text-gray-600 leading-relaxed mb-6">
                Empire325&apos;s methodology delivers this integration. Strategy, execution, and measurement operate simultaneously rather than sequentially. Optimization begins from first campaign launch. Technical capability enables sophisticated analytics and AI-powered systems. Business outcomes determine success.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
