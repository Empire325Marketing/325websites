import Button from "@/components/ui/Button";

export default function PartnershipSection() {
  const empire325Commitments = [
    "Integrated execution delivering strategy, technical infrastructure, and measurement as unified operating system",
    "Singular accountability for business outcomes including customer acquisition cost, return on investment, pipeline contribution, revenue attribution",
    "Transparent performance communication providing clear visibility into results, challenges, and optimization opportunities",
    "Proactive problem resolution diagnosing root causes and implementing corrections when performance misses targets",
    "Systematic optimization pursuing 15-25% annual improvements through disciplined testing frameworks",
    "Long-term partnership perspective investing in sustained client success rather than transactional project delivery",
    "Continuous innovation bringing new capabilities, platform features, and optimization techniques maintaining competitive advantages",
  ];

  const clientRequirements = [
    "Executive engagement in strategic reviews, objective setting, resource allocation decisions, and performance governance",
    "Timely decision-making on approvals, strategic direction, and resource commitments preventing execution delays",
    "Internal coordination connecting Empire325 teams with sales, product, technical, and financial resources as required",
    "Data access to CRM systems, analytics platforms, conversion data enabling comprehensive attribution and measurement",
    "Realistic timeline expectations understanding optimization requires sustained effort—meaningful improvements manifest over quarters, not weeks",
    "Investment commitment maintaining sufficient budget for systematic testing, learning, and scaling proven approaches",
    "Long-term orientation recognizing compound advantages require sustained partnerships enabling accumulated learning and continuous optimization",
  ];

  const metrics = [
    {
      category: "Acquisition Economics",
      indicators: ["Customer acquisition cost", "Return on advertising spend", "Payback period efficiency"],
      standards: "Target CAC achieved within 6-9 months, sustained improvement trajectory established",
    },
    {
      category: "Pipeline Contribution",
      indicators: ["Marketing-sourced pipeline volume", "Lead quality and conversion rates", "Sales cycle velocity"],
      standards: "60-75% increase in qualified lead generation maintaining or improving quality metrics",
    },
    {
      category: "Revenue Attribution",
      indicators: ["Marketing-attributed revenue", "Channel contribution clarity", "Forecast accuracy"],
      standards: "95%+ customer journey tracking enabling confident executive ROI communication",
    },
    {
      category: "Continuous Improvement",
      indicators: ["Annual performance improvement rate", "Testing velocity and win rate", "Optimization cycle speed"],
      standards: "15-25% compound annual improvements through systematic testing discipline",
    },
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Partnership Requirements
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Mutual Commitment to Business Outcomes
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Successful Empire325 partnerships require mutual commitment, transparent communication, and alignment on measuring success through business outcomes rather than activity volume.
          </p>
        </div>

        {/* Commitments Grid */}
        <div className="grid lg:grid-cols-2 gap-20 mb-20">
          {/* Empire325 Commitments */}
          <div>
            <h3 className="text-xl font-bold text-white mb-8">Empire325 Commitments</h3>
            <div className="space-y-4">
              {empire325Commitments.map((item, index) => (
                <div key={index} className="flex gap-4">
                  <span className="text-[#0dc2cc] shrink-0">→</span>
                  <p className="text-gray-400">{item}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Client Requirements */}
          <div>
            <h3 className="text-xl font-bold text-white mb-8">Client Organization Requirements</h3>
            <div className="space-y-4">
              {clientRequirements.map((item, index) => (
                <div key={index} className="flex gap-4">
                  <span className="text-[#0dc2cc] shrink-0">→</span>
                  <p className="text-gray-400">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Performance Measurement */}
        <div className="border-t border-gray-800 pt-16">
          <div className="max-w-3xl mb-12">
            <h3 className="text-xl font-bold text-white mb-4">Performance Measurement</h3>
            <p className="text-gray-400 leading-relaxed">
              Empire325 partnerships succeed when marketing demonstrably contributes to business outcomes through measurable improvements in customer acquisition economics, pipeline generation, and revenue attribution.
            </p>
          </div>

          <p className="text-white font-bold mb-8">Success Metrics Framework:</p>

          {/* Metrics Table */}
          <div className="space-y-0">
            {/* Header */}
            <div className="hidden md:grid md:grid-cols-3 gap-8 border-t border-gray-800 py-4">
              <p className="text-[#0dc2cc] text-sm font-bold uppercase tracking-wider">Metric Category</p>
              <p className="text-[#0dc2cc] text-sm font-bold uppercase tracking-wider">Key Performance Indicators</p>
              <p className="text-[#0dc2cc] text-sm font-bold uppercase tracking-wider">Performance Standards</p>
            </div>

            {metrics.map((metric, index) => (
              <div key={index} className="border-t border-gray-800 py-6">
                <div className="grid md:grid-cols-3 gap-6 md:gap-8">
                  <div>
                    <p className="text-white font-bold">{metric.category}</p>
                  </div>
                  <div>
                    <div className="space-y-2">
                      {metric.indicators.map((indicator, idx) => (
                        <div key={idx} className="flex gap-2">
                          <span className="text-[#0dc2cc]">•</span>
                          <p className="text-gray-400 text-sm">{indicator}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">{metric.standards}</p>
                  </div>
                </div>
              </div>
            ))}
            <div className="border-t border-gray-800" />
          </div>

          {/* Bottom Statement */}
          <div className="mt-12 grid lg:grid-cols-2 gap-12">
            <p className="text-gray-400 leading-relaxed">
              Success manifests through business outcomes demonstrating marketing&apos;s contribution to revenue. Organizations achieving these standards secure sustained executive confidence and continued investment regardless of economic conditions.
            </p>
            <div>
              <p className="text-white leading-relaxed mb-8">
                Empire325&apos;s methodology delivers integrated marketing infrastructure proving business value through comprehensive measurement. Organizations deploying this approach operate with systematic advantages enabling sustained competitive performance.
              </p>
              <div className="border-l-2 border-[#0dc2cc] pl-6 mb-8">
                <p className="text-[#0dc2cc] text-sm font-bold uppercase tracking-wider mb-2">
                  Empire325 Marketing
                </p>
                <p className="text-white text-xl font-bold">
                  Integrated Marketing Infrastructure That Proves Results
                </p>
              </div>
              <Button href="/company/contact">Start a Conversation</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
