export default function ProcessSection() {
  const phases = [
    {
      number: "1",
      title: "Strategic Foundation & Infrastructure Design",
      duration: "3-4 Weeks",
      description: "Comprehensive evaluation establishing business context, performance baselines, technical requirements, and integrated strategy framework.",
      subsections: [
        {
          title: "Business & Performance Assessment",
          items: [
            "Executive stakeholder engagement understanding business objectives, growth targets, competitive positioning",
            "Current marketing performance audit across channels, platforms, and customer journey stages",
            "Customer acquisition economics analysis—CAC, LTV, payback period, unit economics",
            "Market opportunity assessment and competitive landscape evaluation",
          ],
        },
        {
          title: "Technical Infrastructure Evaluation",
          items: [
            "Marketing technology stack assessment including CRM, automation, analytics, advertising platforms",
            "Data infrastructure review evaluating quality, accessibility, integration, governance",
            "Attribution capability audit identifying measurement gaps and blind spots",
            "Reporting process evaluation assessing speed, accuracy, decision-making utility",
          ],
        },
        {
          title: "Strategic Framework Development",
          items: [
            "Integrated marketing strategy connecting awareness investment, nurturing systems, conversion optimization",
            "Channel prioritization based on audience behavior patterns and conversion economics",
            "Measurement architecture design enabling comprehensive attribution and optimization",
            "Budget allocation framework optimizing investment across funnel stages",
            "Implementation roadmap with prioritized initiatives, resource requirements, success criteria",
          ],
        },
      ],
      deliverable: "Strategic blueprint documenting current state, capability requirements, integrated strategy, measurement framework, and 12-18 month implementation roadmap with quarterly performance milestones.",
    },
    {
      number: "2",
      title: "Infrastructure Deployment & Initial Launch",
      duration: "2-3 Months",
      description: "Core measurement infrastructure deployment, initial campaign launches, baseline establishment enabling optimization from operational start.",
      subsections: [
        {
          title: "Measurement Infrastructure Deployment",
          items: [
            "Attribution tracking implementation across marketing touchpoints and platforms",
            "CRM integration enabling closed-loop revenue attribution and pipeline tracking",
            "Real-time dashboard development for executive and operational performance visibility",
            "Conversion tracking and goal configuration across platforms and properties",
            "Baseline metrics establishment documenting pre-optimization performance for comparison",
          ],
        },
        {
          title: "Campaign Launch & Execution",
          items: [
            "Initial campaign deployment across prioritized channels and audience segments",
            "Creative production delivering multiple formats meeting platform requirements",
            "Audience targeting infrastructure leveraging first-party data and behavioral signals",
            "Landing page optimization ensuring post-click conversion excellence",
            "A/B testing framework implementation enabling systematic creative and messaging optimization",
          ],
        },
        {
          title: "Operational Framework",
          items: [
            "Weekly performance review cadence identifying optimization opportunities",
            "Automated reporting systems replacing manual analysis cycles",
            "Stakeholder communication protocols—weekly updates, monthly strategic reviews",
            "Issue escalation procedures ensuring rapid problem identification and resolution",
          ],
        },
      ],
      deliverable: "Operational marketing infrastructure with comprehensive measurement systems, active campaigns generating performance data, and optimization framework enabling data-driven decision-making from day one.",
    },
    {
      number: "3",
      title: "Optimization & Strategic Scaling",
      duration: "3-6 Months",
      description: "Systematic optimization based on performance data, capability expansion into additional channels, budget scaling toward target customer acquisition economics.",
      subsections: [
        {
          title: "Data-Driven Optimization",
          items: [
            "Attribution analysis identifying highest-ROI channels, audiences, messaging approaches",
            "Budget reallocation flowing investment toward proven performance drivers",
            "Creative refresh implementing learnings from systematic A/B testing results",
            "Audience refinement improving targeting precision and conversion rate efficiency",
            "Conversion funnel optimization reducing drop-off at critical customer journey stages",
          ],
        },
        {
          title: "Capability Expansion",
          items: [
            "Additional channel deployment as budget scales and economics prove viability",
            "Advanced attribution model implementation including algorithmic and position-based approaches",
            "Predictive analytics deployment enabling forecast-driven strategic planning",
            "AI-powered optimization automating bid management and budget allocation decisions",
            "Content production scaling through AI-augmented generation systems",
          ],
        },
        {
          title: "Strategic Evolution",
          items: [
            "Quarterly strategy reviews incorporating accumulated performance learnings",
            "Competitive response strategies addressing market dynamics and positioning shifts",
            "Opportunity identification for new channels, audience segments, messaging angles",
            "Annual planning frameworks leveraging data insights and optimization learnings",
          ],
        },
      ],
      deliverable: "Optimized marketing infrastructure achieving target customer acquisition economics with proven channel mix, refined messaging frameworks, and systematic testing delivering measurable improvement trajectory.",
    },
    {
      number: "4",
      title: "Sustained Excellence & Competitive Advantage",
      duration: "6-12+ Months",
      description: "Continuous optimization generating compound performance improvements, advanced capability deployment, and sustained competitive advantages through accumulated learning and innovation adoption.",
      subsections: [
        {
          title: "Compound Improvement",
          items: [
            "15-25% annual performance improvements through systematic testing discipline",
            "Learning accumulation enabling increasingly precise targeting and messaging effectiveness",
            "Optimization velocity acceleration as performance baseline deepens",
            "Competitive advantage expansion through sustained partnership benefits",
          ],
        },
        {
          title: "Advanced Capabilities",
          items: [
            "Machine learning model deployment for behavioral prediction, churn prevention, expansion opportunity identification",
            "Autonomous optimization systems managing campaign performance with minimal human intervention",
            "Sophisticated attribution including incrementality testing and media mix modeling",
            "Custom audience development leveraging proprietary first-party data and behavioral signals",
            "Strategic expansion into new markets, customer segments, or product lines",
          ],
        },
        {
          title: "Innovation & Platform Evolution",
          items: [
            "Platform evolution monitoring and early-access beta feature adoption",
            "Competitive intelligence integration informing strategic positioning adjustments",
            "Industry trend analysis guiding capability development priorities",
            "Continuous innovation adoption maintaining performance leadership",
          ],
        },
      ],
      deliverable: "Marketing infrastructure operating as sustained competitive advantage through continuous optimization, accumulated learning, and systematic innovation adoption delivering compound performance improvements over extended time horizons.",
    },
  ];

  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            The Engagement Process
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Systematic Process for Comprehensive Results
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Empire325 engagements follow systematic process ensuring comprehensive understanding, strategic alignment, technical excellence, and continuous optimization. The process operates with parallel workstreams enabling faster value delivery and immediate measurement capability.
          </p>
        </div>

        {/* Phases */}
        <div className="space-y-16">
          {phases.map((phase, index) => (
            <div key={index} className="border-t border-gray-200 pt-10">
              {/* Phase Header */}
              <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6 mb-8">
                <span className="text-[#0dc2cc] text-sm font-bold">Phase {phase.number}</span>
                <h3 className="text-2xl font-bold text-black">{phase.title}</h3>
                <span className="text-gray-400 text-sm">Duration: {phase.duration}</span>
                <div className="hidden md:block flex-1 h-px bg-gray-200" />
              </div>

              <p className="text-gray-600 leading-relaxed mb-10 max-w-3xl">
                {phase.description}
              </p>

              {/* Subsections Grid */}
              <div className="grid md:grid-cols-3 gap-10 mb-10">
                {phase.subsections.map((subsection, idx) => (
                  <div key={idx}>
                    <h4 className="text-black font-bold mb-4">{subsection.title}</h4>
                    <div className="space-y-3">
                      {subsection.items.map((item, itemIdx) => (
                        <div key={itemIdx} className="flex gap-3">
                          <span className="text-[#0dc2cc] shrink-0">→</span>
                          <p className="text-gray-500 text-sm">{item}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Deliverable */}
              <div className="border-l-2 border-[#0dc2cc] pl-6 bg-gray-50 py-4 pr-4">
                <p className="text-sm text-gray-500 uppercase tracking-wider mb-2">
                  Phase {index === 0 ? "Deliverable" : "Outcome"}
                </p>
                <p className="text-gray-700">{phase.deliverable}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
