export default function PrinciplesSection() {
  const principles = [
    {
      number: "1",
      title: "Measurement Precedes Investment Scale",
      paragraphs: [
        "Comprehensive attribution infrastructure deploys before significant budget allocation. First campaign dollars operate within full measurement systems—tracking implemented, dashboards live, baseline metrics established. This sequence enables immediate optimization rather than prolonged learning periods without data certainty.",
        "Attribution connects every customer touchpoint to revenue outcomes. Multi-touch models credit awareness, nurturing, and conversion activities appropriately. CRM integration enables closed-loop tracking from first website visit through invoice payment. CFOs receive confident answers about marketing ROI backed by comprehensive data.",
      ],
      highlight: "Organizations achieve target customer acquisition economics 40-60% faster through measurement-first deployment eliminating wasteful testing periods.",
    },
    {
      number: "2",
      title: "Unified Teams Drive Integrated Execution",
      paragraphs: [
        "Empire325 structures teams around business outcomes rather than functional disciplines. Strategists, media specialists, data engineers, creative producers, and analytics experts work as integrated units accountable for results. This organization enables continuous collaboration replacing coordination overhead.",
        "Performance data informs creative development daily. Analytics teams work directly with media buyers optimizing campaigns real-time. Strategy evolves based on execution learning rather than annual planning cycles. Technical infrastructure connects all functions enabling shared visibility and rapid decision-making.",
      ],
      highlight: "Optimization velocity increases 3-5X through unified team structure. Learning compounds faster when functions collaborate continuously rather than periodically.",
    },
    {
      number: "3",
      title: "Engineering Capability Enables Marketing Excellence",
      paragraphs: [
        "Modern marketing requires technical capability—data pipeline engineering, attribution system development, AI/ML model deployment, API integration, real-time dashboard construction. Empire325 combines marketing expertise with engineering resources eliminating dependencies on external technical vendors.",
        "Data engineers build attribution infrastructure connecting disparate platforms into unified measurement systems. Machine learning specialists develop behavioral prediction models and autonomous optimization algorithms. Platform engineers create automation systems operating marketing activities at scale. Marketing strategy leverages technical capability directly.",
      ],
      highlight: "Sophisticated capabilities—predictive analytics, algorithmic optimization, real-time attribution—become operational reality rather than strategic recommendations awaiting implementation.",
    },
    {
      number: "4",
      title: "Systematic Testing Enables Compound Improvement",
      paragraphs: [
        "Performance improvement requires disciplined testing frameworks rather than intuitive optimization. Empire325 implements systematic experimentation—8-12 creative variations monthly, A/B testing across channels, algorithmic budget allocation experiments, conversion funnel optimization testing. Statistical rigor ensures valid conclusions.",
        "Testing velocity and learning accumulation generate compound advantages. Organizations achieving 15-25% annual improvements through systematic testing operate with performance trajectories competitors relying on periodic strategic pivots cannot match. Advantages compound over time as optimization insights accumulate.",
      ],
      highlight: "Year-three performance dramatically exceeds year-one through accumulated testing insights. Results compound rather than resetting with each campaign.",
    },
    {
      number: "5",
      title: "Business Outcomes Define Success",
      paragraphs: [
        "Empire325 maintains singular accountability for business results—customer acquisition cost, return on ad spend, pipeline contribution, revenue attribution. Activity metrics—clicks, impressions, engagement—serve as diagnostic indicators but never success criteria. Business outcome metrics determine performance.",
        "Integrated teams own complete customer journey from awareness through conversion and retention. When performance misses targets, analysis identifies root causes and corrections implement rapidly. Clear accountability accelerates problem identification and resolution. Energy flows to optimization rather than explaining responsibility distribution.",
      ],
      highlight: "Marketing proves contribution to revenue through comprehensive measurement, enabling sustained executive confidence and continued investment even during economic uncertainty.",
    },
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Foundational Principles
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Five Principles Governing Every Engagement
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Five principles govern every Empire325 engagement, ensuring marketing infrastructure delivers measurable business value:
          </p>
        </div>

        {/* Principles List */}
        <div className="space-y-0">
          {principles.map((principle, index) => (
            <div
              key={index}
              className="border-t border-gray-800 py-10"
            >
              <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
                {/* Number and Title */}
                <div className="lg:col-span-4">
                  <div className="flex items-start gap-4 mb-4">
                    <span className="text-[#0dc2cc] text-sm font-bold">0{principle.number}</span>
                    <h3 className="text-xl font-bold text-white">{principle.title}</h3>
                  </div>
                </div>

                {/* Content */}
                <div className="lg:col-span-8">
                  {principle.paragraphs.map((para, idx) => (
                    <p key={idx} className="text-gray-400 leading-relaxed mb-4">
                      {para}
                    </p>
                  ))}
                  <div className="border-l-2 border-[#0dc2cc] pl-6 mt-6">
                    <p className="text-white font-medium">{principle.highlight}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="border-t border-gray-800" />
        </div>
      </div>
    </section>
  );
}
