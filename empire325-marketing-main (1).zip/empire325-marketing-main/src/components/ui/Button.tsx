interface ButtonProps {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "secondary";
}

export default function Button({ href, children, variant = "primary" }: ButtonProps) {
  const baseStyles = "inline-flex items-center gap-2 text-sm font-medium px-6 py-3";

  const variants = {
    primary: "bg-black text-white",
    secondary: "bg-white text-black",
  };

  return (
    <a href={href} className={`${baseStyles} ${variants[variant]}`}>
      <svg
        className="w-4 h-4"
        fill="none"
        viewBox="0 0 24 24"
        stroke="#0dc2cc"
        strokeWidth={4}
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M8.25 4.5l7.5 7.5-7.5 7.5"
        />
      </svg>
      <span>{children}</span>
    </a>
  );
}
