"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Disable body scroll when dropdown is open
  useEffect(() => {
    if (openDropdown || mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [openDropdown, mobileMenuOpen]);

  const empire325Services = [
    { name: "Full-Funnel Advertising", href: "/services/full-funnel-advertising" },
    { name: "Performance & Analytics", href: "/services/performance-analytics" },
    { name: "Data Transformation", href: "/services/data-transformation" },
    { name: "Web Development", href: "/services/web-development" },
    { name: "AI SaaS Tools", href: "/services/ai-saas-tools" },
  ];

  const algoVisionServices = [
    { name: "Content Creatives", href: "https://algovision.co/solutions" },
    { name: "AI Solutions", href: "https://algovision.co/solutions/ai-solutions" },
    { name: "PR Marketing", href: "https://algovision.co/solutions/pr-communications" },
    { name: "Social Media Advertising", href: "https://algovision.co/solutions/advertising" },
    { name: "Social Media Management & SEO", href: "https://algovision.co/solutions" },
  ];

  const industries = [
    { name: "SaaS", href: "/industries/saas" },
    { name: "E-Commerce", href: "/industries/ecommerce" },
    { name: "Financial Services", href: "/industries/financial-services" },
    { name: "Asset Management", href: "/industries/asset-management" },
    { name: "Real Estate", href: "/industries/real-estate" },
    { name: "Media & Entertainment", href: "/industries/media-entertainment" },
  ];

  const company = [
    { name: "About Us", href: "/company/about" },
    { name: "Methodology", href: "/company/methodology" },
    { name: "Contact", href: "/company/contact" },
  ];

  return (
    <header className="bg-white border-b border-gray-100 relative z-50">
      <div className="max-w-[1400px] px-6 md:px-12 lg:px-16">
        <nav className="flex items-center h-20 gap-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <Image
              src="/logo.png"
              alt="Empire325 Logo"
              width={64}
              height={64}
              className="w-16 h-16"
            />
            <div className="flex flex-col">
              <span className="text-xl font-bold text-black tracking-tight leading-tight">
                Empire 325
              </span>
              <span className="text-xs font-medium text-gray-500 tracking-wide">
                Marketing
              </span>
            </div>
          </Link>

          {/* Navigation Links - Desktop */}
          <div className="hidden xl:flex items-end gap-10 h-20 flex-1">
            {/* Home Link */}
            <div className="relative pb-4 group">
              <Link
                href="/"
                className="relative text-base text-gray-700 hover:text-black transition-colors"
              >
                Home
                <span className="absolute -bottom-4 left-0 w-full h-1 bg-[#0dc2cc] transition-transform origin-left scale-x-0 group-hover:scale-x-100" />
              </Link>
            </div>

            {/* Services Dropdown */}
            <div
              className="relative pb-4"
              onMouseEnter={() => setOpenDropdown("services")}
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <button
                type="button"
                className="relative text-base text-gray-700 hover:text-black transition-colors"
              >
                Services
                <span className={`absolute -bottom-4 left-0 w-full h-1 bg-[#0dc2cc] transition-transform origin-left ${openDropdown === "services" ? "scale-x-100" : "scale-x-0"}`} />
              </button>
              {openDropdown === "services" && (
                <div className="fixed left-0 right-0 top-20 bg-white border-b border-gray-100 shadow-lg">
                  <div className="max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16 py-8">
                    <div className="grid grid-cols-2 gap-16">
                      {/* Empire325 Marketing */}
                      <div>
                        <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
                          Empire325 Marketing
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          {empire325Services.map((item) => (
                            <Link
                              key={item.href}
                              href={item.href}
                              className="text-base text-gray-700 hover:text-[#0dc2cc] transition-colors"
                            >
                              {item.name}
                            </Link>
                          ))}
                        </div>
                      </div>

                      {/* Divider + AlgoVision Solutions */}
                      <div className="border-l border-gray-200 pl-16">
                        <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
                          AlgoVision Solutions
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          {algoVisionServices.map((item, index) => (
                            <Link
                              key={index}
                              href={item.href}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-base text-gray-700 hover:text-[#0dc2cc] transition-colors"
                            >
                              {item.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Industries Dropdown */}
            <div
              className="relative pb-4"
              onMouseEnter={() => setOpenDropdown("industries")}
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <button
                type="button"
                className="relative text-base text-gray-700 hover:text-black transition-colors"
              >
                Industries
                <span className={`absolute -bottom-4 left-0 w-full h-1 bg-[#0dc2cc] transition-transform origin-left ${openDropdown === "industries" ? "scale-x-100" : "scale-x-0"}`} />
              </button>
              {openDropdown === "industries" && (
                <div className="fixed left-0 right-0 top-20 bg-white border-b border-gray-100 shadow-lg">
                  <div className="max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16 py-8">
                    <div className="grid grid-cols-3 gap-6">
                      {industries.map((item) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="text-base text-gray-700 hover:text-[#0dc2cc] transition-colors"
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Company Dropdown */}
            <div
              className="relative pb-4"
              onMouseEnter={() => setOpenDropdown("company")}
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <button
                type="button"
                className="relative text-base text-gray-700 hover:text-black transition-colors"
              >
                Company
                <span className={`absolute -bottom-4 left-0 w-full h-1 bg-[#0dc2cc] transition-transform origin-left ${openDropdown === "company" ? "scale-x-100" : "scale-x-0"}`} />
              </button>
              {openDropdown === "company" && (
                <div className="fixed left-0 right-0 top-20 bg-white border-b border-gray-100 shadow-lg">
                  <div className="max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16 py-8">
                    <div className="grid grid-cols-3 gap-8">
                      {company.map((item) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="text-base text-gray-700 hover:text-[#0dc2cc] transition-colors"
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Contact Link */}
            <div className="relative pb-4 group">
              <Link
                href="/company/contact"
                className="relative text-base text-gray-700 hover:text-black transition-colors"
              >
                Contact
                <span className="absolute -bottom-4 left-0 w-full h-1 bg-[#0dc2cc] transition-transform origin-left scale-x-0 group-hover:scale-x-100" />
              </Link>
            </div>
          </div>

          {/* Right side icons */}
          <div className="flex items-center gap-4 ml-auto xl:ml-0">
            {/* Mobile menu button */}
            <button
              type="button"
              className="xl:hidden p-2 text-gray-600 hover:text-black transition-colors"
              aria-label="Menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <svg
                className="w-6 h-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={1.5}
              >
                {mobileMenuOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
                  />
                )}
              </svg>
            </button>
          </div>
        </nav>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="xl:hidden border-t border-gray-100 py-4">
            {/* Home */}
            <Link
              href="/"
              className="block px-2 py-2 text-base text-gray-700 hover:text-black font-medium"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>

            {/* Empire325 Services */}
            <div className="mb-4 border-t border-gray-100 pt-4 mt-4">
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wider px-2 mb-2">
                Empire325 Marketing
              </p>
              {empire325Services.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block px-2 py-2 text-sm text-gray-700 hover:text-black"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* AlgoVision Solutions */}
            <div className="mb-4 border-t border-gray-100 pt-4">
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wider px-2 mb-2">
                AlgoVision Solutions
              </p>
              {algoVisionServices.map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block px-2 py-2 text-sm text-gray-700 hover:text-black"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* Industries */}
            <div className="mb-4 border-t border-gray-100 pt-4">
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wider px-2 mb-2">
                Industries
              </p>
              {industries.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block px-2 py-2 text-sm text-gray-700 hover:text-black"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* Company */}
            <div className="border-t border-gray-100 pt-4">
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wider px-2 mb-2">
                Company
              </p>
              {company.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block px-2 py-2 text-sm text-gray-700 hover:text-black"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
