import Image from "next/image";
import Link from "next/link";

export default function Footer() {
  const empire325Services = [
    { name: "Full-Funnel Advertising", href: "/services/full-funnel-advertising" },
    { name: "Performance & Analytics", href: "/services/performance-analytics" },
    { name: "Data Transformation", href: "/services/data-transformation" },
    { name: "Web Development", href: "/services/web-development" },
    { name: "AI SaaS Tools", href: "/services/ai-saas-tools" },
  ];

  const algoVisionServices = [
    { name: "Content Creatives", href: "https://algovision.co/solutions" },
    { name: "AI Solutions", href: "https://algovision.co/solutions/ai-solutions" },
    { name: "PR Marketing", href: "https://algovision.co/solutions/pr-communications" },
    { name: "Social Media Advertising", href: "https://algovision.co/solutions/advertising" },
    { name: "Social Media Management & SEO", href: "https://algovision.co/solutions" },
  ];

  const industries = [
    { name: "SaaS", href: "/industries/saas" },
    { name: "E-Commerce", href: "/industries/ecommerce" },
    { name: "Financial Services", href: "/industries/financial-services" },
    { name: "Asset Management", href: "/industries/asset-management" },
    { name: "Real Estate", href: "/industries/real-estate" },
    { name: "Media & Entertainment", href: "/industries/media-entertainment" },
  ];

  const company = [
    { name: "About Us", href: "/company/about" },
    { name: "Methodology", href: "/company/methodology" },
    { name: "Contact", href: "/company/contact" },
  ];

  return (
    <footer className="bg-white text-black border-t border-gray-200">
      <div className="max-w-[90vw] mx-auto px-6 md:px-12 lg:px-16 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Logo and Description */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-3 mb-6">
              <Image
                src="/logo.png"
                alt="Empire 325 Logo"
                width={50}
                height={50}
                className="w-12 h-12"
              />
              <div className="flex flex-col">
                <span className="text-lg font-bold text-black tracking-tight leading-tight">
                  Empire 325
                </span>
                <span className="text-xs font-medium text-gray-500 tracking-wide">
                  Marketing
                </span>
              </div>
            </Link>
            <p className="text-sm text-gray-600 leading-relaxed">
              Integrated marketing infrastructure that proves results through comprehensive measurement.
            </p>
          </div>

          {/* Empire325 Services */}
          <div>
            <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
              Empire325 Marketing
            </p>
            <ul className="space-y-3">
              {empire325Services.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-gray-600 hover:text-black transition-colors"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* AlgoVision Services */}
          <div>
            <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
              AlgoVision Solutions
            </p>
            <ul className="space-y-3">
              {algoVisionServices.map((item, index) => (
                <li key={index}>
                  <Link
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-gray-600 hover:text-black transition-colors"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Industries */}
          <div>
            <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
              Industries
            </p>
            <ul className="space-y-3">
              {industries.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-gray-600 hover:text-black transition-colors"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-4">
              Company
            </p>
            <ul className="space-y-3">
              {company.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-gray-600 hover:text-black transition-colors"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} Empire 325 Marketing. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link
              href="/privacy"
              className="text-sm text-gray-500 hover:text-black transition-colors"
            >
              Privacy Policy
            </Link>
            <Link
              href="/terms"
              className="text-sm text-gray-500 hover:text-black transition-colors"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
