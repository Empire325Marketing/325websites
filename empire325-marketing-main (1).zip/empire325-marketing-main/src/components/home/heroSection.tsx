import Button from "@/components/ui/Button";

export default function HeroSection() {
  return (
    <section className="relative bg-white">
      <div className="flex flex-col lg:flex-row min-h-[60vh]">
        {/* Left Content Panel */}
        <div className="flex-1 flex items-center px-6 md:px-16 lg:px-16 xl:px-24 py-8 lg:py-16">
          <div className="max-w-xl">
            {/* Eyebrow */}
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              2026 Enterprise Marketing Outlook
            </p>

            {/* Headline */}
            <h1 className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6" style={{ fontWeight: 1000 }}>
              2026 Marketing Transformation: The Data and AI Foundation Shift
            </h1>

            {/* Body */}
            <p className="text-base text-gray-600 leading-relaxed mb-8">
              Enterprise marketing is being reshaped by two converging mega forces:
              artificial intelligence and first-party data infrastructure. We think
              it&apos;s impossible to avoid making a decisive call on their deployment
              so maintaining legacy systems is not a neutral stance. Organizations
              building integrated data and AI infrastructure are achieving 340% higher
              growth rates while competitors struggle to move beyond pilot projects.
            </p>

            {/* CTA Button */}
            <Button href="/resources/2026-marketing-outlook">
              Read our 2026 Marketing Infrastructure Outlook
            </Button>
          </div>
        </div>

        {/* Right Image Panel */}
        <div className="flex-1 relative min-h-[200px] lg:min-h-0">
          {/* Mountain climber photo placeholder - SVG illustration */}
          <div className="absolute inset-0 bg-gradient-to-b from-amber-100 to-amber-200">
            <svg
              viewBox="0 0 800 900"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="w-full h-full object-cover"
              preserveAspectRatio="xMidYMid slice"
            >
              {/* Warm sky gradient */}
              <defs>
                <linearGradient id="warmSky" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#FEF3C7" />
                  <stop offset="50%" stopColor="#FDE68A" />
                  <stop offset="100%" stopColor="#D4A574" />
                </linearGradient>
                <linearGradient id="rockFace" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#78716C" />
                  <stop offset="50%" stopColor="#A8A29E" />
                  <stop offset="100%" stopColor="#D6D3D1" />
                </linearGradient>
                <linearGradient id="rockShadow" x1="100%" y1="0%" x2="0%" y2="0%">
                  <stop offset="0%" stopColor="#57534E" />
                  <stop offset="100%" stopColor="#44403C" />
                </linearGradient>
              </defs>

              {/* Sky background */}
              <rect width="800" height="900" fill="url(#warmSky)" />

              {/* Main rock face - large diagonal cliff */}
              <path
                d="M200 0 L800 0 L800 900 L400 900 L200 600 Z"
                fill="url(#rockFace)"
              />

              {/* Rock texture/shadows */}
              <path
                d="M300 100 L350 200 L280 350 L320 500 L250 650 L300 800 L400 900 L350 900 L200 700 L250 500 L200 300 L250 150 Z"
                fill="url(#rockShadow)"
                opacity="0.4"
              />

              {/* Rock crevices */}
              <path d="M400 50 L420 150 L380 200" stroke="#57534E" strokeWidth="3" fill="none" opacity="0.5" />
              <path d="M500 200 L480 350 L520 400" stroke="#57534E" strokeWidth="2" fill="none" opacity="0.4" />
              <path d="M350 400 L380 500 L340 600" stroke="#57534E" strokeWidth="3" fill="none" opacity="0.5" />
              <path d="M600 100 L580 250 L620 350" stroke="#57534E" strokeWidth="2" fill="none" opacity="0.3" />
              <path d="M450 550 L480 650 L440 750" stroke="#57534E" strokeWidth="2" fill="none" opacity="0.4" />

              {/* Climber - person scaling the rock face */}
              <g transform="translate(380, 380)">
                {/* Shadow on rock */}
                <ellipse cx="25" cy="50" rx="20" ry="8" fill="#44403C" opacity="0.3" />

                {/* Legs */}
                <path d="M20 35 L5 60" stroke="#1C1917" strokeWidth="6" strokeLinecap="round" />
                <path d="M25 35 L40 55" stroke="#1C1917" strokeWidth="6" strokeLinecap="round" />

                {/* Body/torso - leaning into rock */}
                <ellipse cx="22" cy="20" rx="12" ry="18" fill="#292524" />

                {/* Backpack */}
                <ellipse cx="30" cy="22" rx="8" ry="12" fill="#78716C" />

                {/* Arms */}
                {/* Right arm reaching up */}
                <path d="M28 8 L55 -25" stroke="#1C1917" strokeWidth="6" strokeLinecap="round" />
                {/* Left arm gripping rock */}
                <path d="M15 15 L-5 5" stroke="#1C1917" strokeWidth="6" strokeLinecap="round" />

                {/* Head with helmet */}
                <circle cx="20" cy="-5" r="10" fill="#1C1917" />
                <ellipse cx="20" cy="-8" rx="11" ry="8" fill="#DC2626" /> {/* Red helmet */}

                {/* Hand gripping hold */}
                <circle cx="57" cy="-27" r="5" fill="#1C1917" />
                <circle cx="-7" cy="4" r="4" fill="#1C1917" />
              </g>

              {/* Distant landscape hint at bottom left */}
              <path
                d="M0 750 L150 700 L100 900 L0 900 Z"
                fill="#78716C"
                opacity="0.3"
              />

              {/* Light flare from top */}
              <circle cx="100" cy="100" r="150" fill="#FEF3C7" opacity="0.4" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
