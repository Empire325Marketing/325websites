export default function IndustryDynamics() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-20">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Industry Dynamics
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Vertical-Specific Transformation
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Marketing evolution manifests differently across industries. Regulatory
            environments, buyer sophistication, and competitive dynamics create
            distinct challenges and opportunities in each vertical we track.
          </p>
        </div>

        {/* Industries - Full width stacked */}
        <div className="space-y-16">
          {/* Row 1 */}
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Technology (SaaS)</h3>
              <p className="text-gray-600 leading-relaxed">
                Series A-C companies with $10M+ ARR face product-led growth scaling and
                enterprise sales enablement requirements. Multi-touch attribution frameworks
                combined with systematic content production enable 340% average growth rates.
                The challenge: building measurement infrastructure that tracks complex buying
                committees across 6-12 month sales cycles while maintaining product-led growth efficiency.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Healthcare</h3>
              <p className="text-gray-600 leading-relaxed">
                Medical device manufacturers and healthcare technology companies navigate
                HIPAA compliance restrictions while targeting hospital systems and physician
                networks. Success requires establishing organic search dominance in regulated
                categories competitors cannot access. Organizations achieving 280% average
                growth combine E-E-A-T optimization with compliance-aware content strategies
                and 64% lead quality improvement through behavioral scoring adapted to
                healthcare buying patterns.
              </p>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-gray-200" />

          {/* Row 2 */}
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Asset Management</h3>
              <p className="text-gray-600 leading-relaxed">
                Alternative investment funds deploying 506(c) marketing reach accredited
                investors through compliant digital channels following March 2025 regulatory
                amendments. Fund sponsors building direct LP acquisition infrastructure
                achieve $19,209 cost per $1M raised—63% lower than traditional placement
                agent economics—while maintaining 100% SEC compliance records. The opportunity:
                13.6M accredited investor households holding $73T with only 2.1% allocated
                to alternatives, representing a $2.3T addressable market.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">E-commerce</h3>
              <p className="text-gray-600 leading-relaxed">
                Direct-to-consumer brands with $20M+ revenue face platform dependency as
                Meta/Google concentration creates ROAS vulnerability. Market leaders
                diversifying to TikTok, streaming platforms, and organic search achieve
                367% average growth with 240% ROAS improvement. The strategy: reducing
                platform concentration from 78% to 34% of acquisition spend while maintaining
                growth through cross-platform optimization and proprietary attribution modeling.
              </p>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-gray-200" />

          {/* Row 3 */}
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Media & Entertainment</h3>
              <p className="text-gray-600 leading-relaxed">
                Streaming services and premium content creators leverage advertising
                inventory on Netflix, Disney+, and Prime Video for audience acquisition
                at scale. Exclusive platform access enables reach into high-income households
                (top 20% by income) that competitors cannot target through traditional
                channels. The advantage: closed ecosystem inventory unavailable to 99%
                of agencies and brands.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Real Estate</h3>
              <p className="text-gray-600 leading-relaxed">
                PropTech platforms, commercial real estate firms, and brokerages navigate
                lead quality challenges, geographic targeting complexity, and market
                saturation dynamics. Success requires hyper-local SEO strategies combined
                with cross-platform acquisition and CRM systems tracking long sales cycles
                across multiple stakeholder touchpoints. The implementation: behavioral
                scoring adapted to real estate buying patterns producing qualified leads
                sales teams accept.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        {/* <div className="mt-16">
          <a
            href="#industry-intelligence"
            className="inline-flex items-center gap-2 bg-black text-white text-sm font-medium px-6 py-3"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="#0dc2cc"
              strokeWidth={4}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8.25 4.5l7.5 7.5-7.5 7.5"
              />
            </svg>
            <span>Explore industry intelligence</span>
          </a>
        </div> */}
      </div>
    </section>
  );
}
