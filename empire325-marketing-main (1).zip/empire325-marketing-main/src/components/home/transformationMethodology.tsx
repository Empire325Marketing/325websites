export default function TransformationMethodology() {
  return (
    <section className="bg-black py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header - Centered */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Transformation Methodology
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Systematic Approach to Infrastructure Building
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Organizations achieving measurable transformation follow a consistent
            four-phase evolution. This methodology produces results across verticals
            by addressing infrastructure gaps systematically rather than deploying
            tactical solutions to strategic problems.
          </p>
        </div>

        {/* Timeline - Mobile: left-aligned, Desktop: centered zigzag */}
        <div className="relative max-w-4xl mx-auto">
          {/* Vertical line - left on mobile, center on desktop */}
          <div className="absolute left-6 md:left-1/2 md:-translate-x-1/2 w-px h-full bg-gray-800" />

          {/* Phase 1 */}
          <div className="relative flex items-start mb-12 md:mb-20">
            {/* Mobile & Desktop: Number badge */}
            <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-12 h-12 bg-black border-2 border-[#0dc2cc] flex items-center justify-center z-10">
              <span className="text-[#0dc2cc] font-bold">01</span>
            </div>
            {/* Desktop only: Left content */}
            <div className="hidden md:block w-1/2 pr-12 text-right">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">3-5 days</p>
              <h3 className="text-2xl font-bold text-white mb-3">Infrastructure Audit</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Comprehensive 47-point analysis across digital ecosystem revealing
                optimization opportunities, performance bottlenecks, competitive
                positioning gaps, and measurement framework weaknesses.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Technical audit + competitive benchmark</p>
            </div>
            {/* Mobile only: Right content */}
            <div className="md:hidden pl-20">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">3-5 days</p>
              <h3 className="text-xl font-bold text-white mb-3">Infrastructure Audit</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Comprehensive 47-point analysis across digital ecosystem revealing
                optimization opportunities, performance bottlenecks, competitive
                positioning gaps, and measurement framework weaknesses.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Technical audit + competitive benchmark</p>
            </div>
            <div className="hidden md:block w-1/2 pl-12" />
          </div>

          {/* Phase 2 */}
          <div className="relative flex items-start mb-12 md:mb-20">
            <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-12 h-12 bg-black border-2 border-gray-700 flex items-center justify-center z-10">
              <span className="text-white font-bold">02</span>
            </div>
            <div className="hidden md:block w-1/2 pr-12" />
            {/* Content - right on mobile & desktop */}
            <div className="pl-20 md:pl-0 md:w-1/2 md:pl-12">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">5-7 days</p>
              <h3 className="text-xl md:text-2xl font-bold text-white mb-3">Market Position Analysis</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Deep competitive intelligence across 12+ direct competitors generating
                340+ insights from proprietary databases. Analysis identifies 89
                opportunities for competitive advantage.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Competitive intelligence + opportunity map</p>
            </div>
          </div>

          {/* Phase 3 */}
          <div className="relative flex items-start mb-12 md:mb-20">
            <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-12 h-12 bg-black border-2 border-gray-700 flex items-center justify-center z-10">
              <span className="text-white font-bold">03</span>
            </div>
            {/* Desktop only: Left content */}
            <div className="hidden md:block w-1/2 pr-12 text-right">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">2 weeks</p>
              <h3 className="text-2xl font-bold text-white mb-3">Strategic Blueprint</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Custom revenue roadmap with channel prioritization, resource allocation
                strategy, and 24-month projections. Includes AI infrastructure deployment
                and platform diversification plans.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Strategic roadmap + 24-month projections (8.7X avg ROI)</p>
            </div>
            {/* Mobile only: Right content */}
            <div className="md:hidden pl-20">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">2 weeks</p>
              <h3 className="text-xl font-bold text-white mb-3">Strategic Blueprint</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Custom revenue roadmap with channel prioritization, resource allocation
                strategy, and 24-month projections. Includes AI infrastructure deployment
                and platform diversification plans.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Strategic roadmap + 24-month projections (8.7X avg ROI)</p>
            </div>
            <div className="hidden md:block w-1/2 pl-12" />
          </div>

          {/* Phase 4 */}
          <div className="relative flex items-start">
            <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-12 h-12 bg-[#0dc2cc] flex items-center justify-center z-10">
              <span className="text-black font-bold">04</span>
            </div>
            <div className="hidden md:block w-1/2 pr-12" />
            {/* Content - right on mobile & desktop */}
            <div className="pl-20 md:pl-0 md:w-1/2 md:pl-12">
              <p className="text-[#0dc2cc] text-sm font-bold mb-2">Ongoing partnership</p>
              <h3 className="text-xl md:text-2xl font-bold text-white mb-3">Continuous Execution</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Ongoing implementation with monthly executive strategy sessions,
                24/7 support infrastructure, C-suite advisory access, and continuous
                competitive intelligence integration.
              </p>
              <p className="text-gray-600 text-xs mt-3">Output: Executed transformation + continuous optimization</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
