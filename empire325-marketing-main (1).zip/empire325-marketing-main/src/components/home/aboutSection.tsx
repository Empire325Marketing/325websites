import Button from "@/components/ui/Button";

export default function AboutSection() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column - Main Content */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              About Empire325
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-8"
              style={{ fontWeight: 1000 }}
            >
              Intelligence and Execution Infrastructure
            </h2>
            <p className="text-base text-gray-600 leading-relaxed mb-6">
              Empire325 was founded in 2019 to help enterprise marketing leaders
              navigate competitive complexity through superior intelligence and
              systematic execution capabilities. In 2022, we partnered with Algo
              Vision to enhance our AI infrastructure capabilities, enabling the
              content velocity and predictive analytics frameworks that now serve
              as competitive advantages for organizations we work with.
            </p>
            <p className="text-base text-gray-600 leading-relaxed mb-10">
              Since inception, we&apos;ve tracked marketing transformation across
              130+ enterprises in 23 countries. Our approach combines proprietary
              research methodologies with operational implementation expertise
              across six industry verticals: technology, healthcare, asset
              management, e-commerce, media &amp; entertainment, and real estate.
            </p>

            {/* Track Record Stats */}
            <div className="grid grid-cols-2 gap-8 mb-10">
              <div>
                <div className="text-4xl font-black text-black">130+</div>
                <p className="text-gray-500 text-sm">enterprise clients</p>
              </div>
              <div>
                <div className="text-4xl font-black text-[#0dc2cc]">$47M+</div>
                <p className="text-gray-500 text-sm">attributed revenue</p>
              </div>
              <div>
                <div className="text-4xl font-black text-black">98%</div>
                <p className="text-gray-500 text-sm">client retention</p>
              </div>
              <div>
                <div className="text-4xl font-black text-[#0dc2cc]">23</div>
                <p className="text-gray-500 text-sm">countries served</p>
              </div>
            </div>

            {/* CTA */}
            <Button href="/company/contact">Work with our team</Button>
          </div>

          {/* Right Column - Lists */}
          <div className="space-y-12">
            {/* Research Focus */}
            <div>
              <h3 className="text-lg font-bold text-black mb-4">
                Our research focus
              </h3>
              <div className="space-y-2 text-gray-600">
                <p>AI marketing infrastructure deployment</p>
                <p>Cross-platform acquisition strategy</p>
                <p>Attribution framework reconstruction</p>
                <p>Alternative investment marketing (SEC 506(c) compliance)</p>
                <p>Organic search in regulated industries</p>
                <p>Enterprise lead quality benchmarking</p>
              </div>
            </div>

            {/* Platform Access */}
            <div>
              <h3 className="text-lg font-bold text-black mb-4">
                Platform access and partnerships
              </h3>
              <div className="space-y-2 text-gray-600">
                <p>Google Premier Partner</p>
                <p>Meta Business Partner</p>
                <p>Microsoft Elite Partner</p>
                <p>Exclusive streaming inventory: Netflix, Disney+, Prime Video, Hulu, Apple TV+</p>
                <p className="text-sm text-[#0dc2cc] font-medium">One of 50 agencies globally with streaming access</p>
              </div>
            </div>

            {/* Closing Statement */}
            <div className="border-t border-gray-200 pt-8">
              <p className="text-gray-600 leading-relaxed mb-4">
                The marketing landscape is fragmenting rapidly. AI is creating
                execution gaps. Platform dependency is concentrating risk.
                Attribution models are collapsing.
              </p>
              <p className="text-black font-bold">
                Organizations need intelligence about what&apos;s actually
                working—and systematic implementation capability to deploy it
                effectively. That&apos;s what we provide.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
