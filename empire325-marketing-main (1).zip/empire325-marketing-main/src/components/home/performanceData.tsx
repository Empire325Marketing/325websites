export default function PerformanceData() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-20">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Performance Data
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            What The Numbers Reveal
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            We track marketing transformation across 130+ enterprises in technology,
            healthcare, asset management, e-commerce, media, and real estate.
          </p>
        </div>

        {/* Big Numbers Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200">
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-[#0dc2cc] mb-2">87%</div>
            <p className="text-gray-600 text-sm">invested in AI tools</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-black mb-2">23%</div>
            <p className="text-gray-600 text-sm">successfully deployed</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-[#0dc2cc] mb-2">340%</div>
            <p className="text-gray-600 text-sm">higher growth rate</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-black mb-2">10X</div>
            <p className="text-gray-600 text-sm">velocity gap</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-black mb-2">450+</div>
            <p className="text-gray-600 text-sm">content pieces monthly</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-[#0dc2cc] mb-2">67%</div>
            <p className="text-gray-600 text-sm">more keywords controlled</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-black mb-2">73%</div>
            <p className="text-gray-600 text-sm">legacy MQL rejection</p>
          </div>
          <div className="bg-white p-8 lg:p-12">
            <div className="text-5xl lg:text-7xl font-black text-[#0dc2cc] mb-2">240%</div>
            <p className="text-gray-600 text-sm">ROAS improvement</p>
          </div>
        </div>

        {/* Bottom Impact Bar */}
        <div className="mt-16 flex flex-col md:flex-row items-center justify-between gap-8 border-t border-gray-200 pt-12">
          <div className="flex items-baseline gap-3">
            <span className="text-4xl md:text-5xl font-black text-[#0dc2cc]">$47M+</span>
            <span className="text-gray-600">attributed revenue</span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-4xl md:text-5xl font-black text-black">98%</span>
            <span className="text-gray-600">client retention</span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-4xl md:text-5xl font-black text-[#0dc2cc]">130+</span>
            <span className="text-gray-600">enterprises</span>
          </div>
        </div>
      </div>
    </section>
  );
}
