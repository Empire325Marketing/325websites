import Button from "@/components/ui/Button";

export default function MarketingForces() {
  return (
    <section className="bg-white py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Market Forces
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            What&apos;s Reshaping Enterprise Marketing
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Three converging dynamics are fundamentally changing how enterprises
            acquire customers, measure performance, and compete for market share.
            Organizations that understand these shifts are capturing disproportionate
            competitive advantages.
          </p>
        </div>

        {/* Three Columns */}
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          {/* Column 1 */}
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              The Content Velocity Gap
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Traditional marketing operations produce 30-40 strategic content pieces
              monthly. AI-augmented teams are producing 450+ while maintaining editorial
              quality and brand authority. This 10X velocity difference is translating
              directly into organic search dominance: early AI adopters control 67% more
              high-value keywords than competitors operating manual workflows. The gap
              is widening rapidly.
            </p>
          </div>

          {/* Column 2 */}
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Attribution Framework Collapse
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Privacy regulations and platform changes have fragmented enterprise
              measurement systems. 73% of sales teams now reject marketing-qualified
              leads due to attribution model failures. Companies rebuilding measurement
              infrastructure using first-party data collection and behavioral scoring
              are capturing 40% more qualified pipeline than organizations relying on
              legacy attribution frameworks.
            </p>
          </div>

          {/* Column 3 */}
          <div>
            <h3 className="text-xl font-bold text-black mb-4">
              Platform Concentration Risk
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Enterprises allocating $500K+ annually to paid media face 60% revenue
              vulnerability when platform algorithms shift. We&apos;ve analyzed 200+
              marketing technology stacks to identify where Google/Meta dependency
              creates existential risk versus strategic leverage. Organizations
              successfully diversifying acquisition channels are maintaining growth
              trajectories while reducing platform concentration exposure.
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <Button href="/resources/2026-marketing-outlook">Explore our research</Button>
      </div>
    </section>
  );
}
