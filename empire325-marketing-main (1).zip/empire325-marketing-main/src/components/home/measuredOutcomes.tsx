"use client";

import { useState } from "react";

export default function MeasuredOutcomes() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const caseStudies = [
    {
      industry: "B2B SaaS",
      company: "TechCorp Solutions",
      mainStat: "423%",
      mainLabel: "revenue growth",
      timeline: "12 months",
      secondaryStat: "47%",
      secondaryLabel: "CAC reduction",
      challenge:
        "Declining conversion rates and unsustainable customer acquisition costs masked by attribution framework collapse.",
      implementation:
        "Rebuilt multi-touch attribution revealing actual channel performance. Platform diversification reduced Google/Meta dependency from 85% to 42% of acquisition spend. Established organic search dominance across 2,400+ enterprise software keywords through systematic content production and technical SEO optimization.",
      impact:
        "423% revenue growth, 47% lower CAC, organic search contributing 38% of pipeline (previously 9%).",
    },
    {
      industry: "Healthcare Technology",
      company: "MedTech Innovations",
      mainStat: "280%",
      mainLabel: "revenue growth",
      timeline: "18 months",
      secondaryStat: "64%",
      secondaryLabel: "lead quality improvement",
      challenge:
        "73% sales rejection rate due to low-quality lead generation in regulated healthcare vertical with HIPAA compliance restrictions limiting advertising options.",
      implementation:
        "Behavioral scoring rebuilt to identify qualified hospital buyers and physician network decision-makers. Compliance framework enabled advertising in restricted healthcare categories competitors couldn't access. E-E-A-T optimization established organic authority in medical device categories.",
      impact:
        "280% revenue growth, sales rejection rate decreased from 73% to 21%, established dominant organic visibility in regulated categories.",
    },
    {
      industry: "E-commerce",
      company: "RetailFlow Commerce",
      mainStat: "367%",
      mainLabel: "revenue growth",
      timeline: "14 months",
      secondaryStat: "240%",
      secondaryLabel: "ROAS improvement",
      challenge:
        "Over-reliance on Meta advertising (78% of budget) created existential vulnerability when algorithm changes decreased ROAS by 40%. Rising CAC threatened profitability.",
      implementation:
        "Platform diversification across TikTok, Google Shopping, and exclusive streaming inventory (Netflix, Disney+). AI-powered content systems produced 450+ monthly SEO-optimized product descriptions. Cross-platform attribution modeling optimized budget allocation dynamically.",
      impact:
        "367% revenue growth, Meta dependency reduced to 34%, ROAS improved 240%, organic search now drives 42% of revenue.",
    },
    {
      industry: "Real Estate Fund",
      company: "Evergreen Capital Partners",
      mainStat: "$67M",
      mainLabel: "raised (134% of target)",
      timeline: "14 months",
      secondaryStat: "$19K",
      secondaryLabel: "per $1M raised",
      challenge:
        "Launching first institutional fund with no LP database. Traditional placement agents charging 3-5% of capital raised ($1.5M-$2.5M for $50M target). Required SEC 506(c) compliant marketing strategy.",
      implementation:
        "Accredited investor intelligence identified 847,000 qualified households across target MSAs. Compliance framework enabled general solicitation maintaining SEC 506(c) requirements. Multi-channel strategy: LinkedIn advertising ($287/qualified lead), streaming ads in high-net-worth zip codes, educational webinars (22% LP conversion rate).",
      impact:
        "$67M raised (134% of target), $19,209 cost per $1M raised (63% lower than placement agents), 100% SEC compliance, built LP database of 1,200+ verified accredited investors.",
    },
  ];

  const changeSlide = (newIndex: number) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setActiveIndex(newIndex);
      setIsTransitioning(false);
    }, 200);
  };

  const nextSlide = () => {
    changeSlide((activeIndex + 1) % caseStudies.length);
  };

  const prevSlide = () => {
    changeSlide((activeIndex - 1 + caseStudies.length) % caseStudies.length);
  };

  const current = caseStudies[activeIndex];

  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Measured Outcomes
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Transformation Results Across Industries
            </h2>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-4">
            <button
              onClick={prevSlide}
              className="w-12 h-12 border border-gray-300 flex items-center justify-center hover:border-[#0dc2cc] transition-colors"
            >
              <svg className="w-5 h-5 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <span className="text-black font-medium">
              {String(activeIndex + 1).padStart(2, "0")} / {String(caseStudies.length).padStart(2, "0")}
            </span>
            <button
              onClick={nextSlide}
              className="w-12 h-12 border border-gray-300 flex items-center justify-center hover:border-[#0dc2cc] transition-colors"
            >
              <svg className="w-5 h-5 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Carousel Content */}
        <div className={`grid lg:grid-cols-12 gap-12 transition-opacity duration-200 ${isTransitioning ? "opacity-0" : "opacity-100"}`}>
          {/* Left - Stats */}
          <div className="lg:col-span-4">
            <p className="text-sm text-gray-500 mb-2">{current.industry}</p>
            <h3 className="text-3xl font-bold text-black mb-8">{current.company}</h3>

            <div className="mb-8">
              <span className="text-7xl font-black text-[#0dc2cc]">{current.mainStat}</span>
              <p className="text-gray-600 mt-2">{current.mainLabel}</p>
            </div>

            <div className="flex gap-10">
              <div>
                <span className="text-3xl font-bold text-black">{current.timeline}</span>
                <p className="text-sm text-gray-500">timeline</p>
              </div>
              <div>
                <span className="text-3xl font-bold text-black">{current.secondaryStat}</span>
                <p className="text-sm text-gray-500">{current.secondaryLabel}</p>
              </div>
            </div>
          </div>

          {/* Right - Details */}
          <div className="lg:col-span-8 space-y-8">
            <div>
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wide mb-3">Challenge</p>
              <p className="text-gray-600 leading-relaxed text-lg">{current.challenge}</p>
            </div>

            <div>
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wide mb-3">Implementation</p>
              <p className="text-gray-600 leading-relaxed">{current.implementation}</p>
            </div>

            <div>
              <p className="text-xs font-bold text-[#0dc2cc] uppercase tracking-wide mb-3">Impact</p>
              <p className="text-black font-medium leading-relaxed">{current.impact}</p>
            </div>
          </div>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-12">
          {caseStudies.map((_, index) => (
            <button
              key={index}
              onClick={() => changeSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === activeIndex ? "bg-[#0dc2cc] w-6" : "bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
