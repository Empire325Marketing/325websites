export default function ImplementationFrameworks() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Implementation Frameworks
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            How Organizations Are Building Capability
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Market leaders aren&apos;t just adopting new technologies—they&apos;re
            systematically rebuilding marketing operations around four foundational
            capabilities.
          </p>
        </div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left Column */}
          <div className="space-y-12">
            {/* Framework 1 */}
            <div>
              <h3 className="text-xl font-bold text-black mb-3">
                AI-Augmented Content Infrastructure
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                Enterprise brands competing for C-suite attention require 450+ monthly
                content pieces to maintain mindshare—volume impossible through traditional
                creation methods. Successful implementations combine AI-powered generation
                with human editorial oversight. The result: 10X content production with
                maintained quality standards.
              </p>
              <p className="text-sm text-gray-500">
                Proprietary content engines | Editorial governance | SEO architecture | Publishing infrastructure
              </p>
            </div>

            {/* Framework 2 */}
            <div>
              <h3 className="text-xl font-bold text-black mb-3">
                Digital Performance Optimization
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                Enterprise websites require sub-second load times, sophisticated attribution
                integration, and conversion-focused architecture. Organizations treating
                digital infrastructure as strategic assets achieve measurable improvements.
                The difference: 47 critical points separating leaders from competitors.
              </p>
              <p className="text-sm text-gray-500">
                Performance optimization | Conversion engineering | Attribution integration | Technical SEO
              </p>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-12">
            {/* Framework 3 */}
            <div>
              <h3 className="text-xl font-bold text-black mb-3">
                Cross-Platform Acquisition Strategy
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                Platform concentration creates existential vulnerability. Sophisticated
                organizations deploy acquisition capital across search, social, and streaming
                inventory. The most advanced implementations include exclusive platform
                access—Netflix, Disney+, Prime Video inventory available to only 50 agencies globally.
              </p>
              <p className="text-sm text-gray-500">
                Search & display | Social advertising | Streaming platforms | Cross-platform attribution
              </p>
            </div>

            {/* Framework 4 */}
            <div>
              <h3 className="text-xl font-bold text-black mb-3">
                Revenue Operations Alignment
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                Traditional marketing-sales handoffs produce 73% lead rejection rates.
                Organizations rebuilding this interface around behavioral scoring,
                first-party data infrastructure, and revenue operations frameworks
                achieve 40% higher pipeline conversion.
              </p>
              <p className="text-sm text-gray-500">
                Behavioral lead scoring | First-party data | CRM integration | Multi-touch attribution
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
