export default function IntelligenceSection() {
  const intelligenceAreas = [
    {
      title: "AI Marketing Infrastructure",
      description:
        "87% of marketing leaders have invested in AI tools. Only 23% have successfully deployed them into production workflows. We're documenting which AI implementations deliver measurable ROI and why most marketing organizations lack the execution infrastructure to capitalize on technology investments.",
      cta: "View AI implementation research",
      href: "#ai-research",
    },
    {
      title: "Alternative Investment Marketing",
      description:
        "The March 2025 SEC 506(c) amendments simplified accredited investor verification and expanded general solicitation permissions for private funds. Fund sponsors now face a strategic choice: maintain traditional placement agent relationships or build direct LP acquisition channels.",
      stats: "13.6M accredited investor households | $73T investable assets | $2.3T addressable market",
      cta: "Read alternative investment intelligence",
      href: "#alt-investment",
    },
    {
      title: "Platform Independence Analysis",
      description:
        "Companies allocating significant capital to paid media face concentration risk as algorithmic changes erode returns on advertising spend. Our platform dependency index tracks 200+ enterprise marketing stacks to identify where Google/Meta reliance creates vulnerability versus strategic leverage.",
      cta: "Explore platform dependency research",
      href: "#platform-research",
    },
    {
      title: "Enterprise Lead Quality",
      description:
        "We analyzed 15,000 B2B leads across technology, healthcare, and financial services to understand why sales teams reject 73% of marketing-qualified leads. Organizations rebuilding lead scoring using behavioral intelligence are achieving 64% improvement in sales acceptance rates.",
      cta: "View lead quality intelligence",
      href: "#lead-quality",
    },
    {
      title: "Streaming Platform Advertising",
      description:
        "Premium inventory on Netflix, Disney+, Prime Video, and Apple TV+ represents the most significant shift in enterprise advertising since programmatic display emerged. Only 50 agencies globally have access to this closed ecosystem.",
      cta: "Read streaming platform analysis",
      href: "#streaming-analysis",
    },
    {
      title: "Organic Search in Regulated Industries",
      description:
        "Healthcare, financial services, and legal sectors face content restrictions that create search opportunities competitors cannot exploit. We track keyword positioning across 15,000+ regulatory-sensitive terms.",
      cta: "Explore organic search research",
      href: "#organic-search",
    },
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Intelligence Focus Areas
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Marketing Intelligence We&apos;re Tracking
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Our research teams analyze competitive positioning, channel performance,
            and marketing technology implementation across six industry verticals.
            This intelligence informs how enterprises navigate the AI transformation,
            platform dependency challenges, and measurement framework reconstruction
            that&apos;s reshaping competitive hierarchies.
          </p>
        </div>

        {/* Intelligence List - Horizontal Cards */}
        <div className="space-y-0">
          {intelligenceAreas.map((area, index) => (
            <div
              key={index}
              className="group border-t border-gray-800 py-8 flex flex-col md:flex-row md:items-start gap-6 md:gap-12"
            >
              {/* Number */}
              <div className="text-[#0dc2cc] text-sm font-bold w-8 shrink-0">
                0{index + 1}
              </div>

              {/* Title */}
              <div className="md:w-1/4 shrink-0">
                <h3 className="text-xl font-bold text-white">
                  {area.title}
                </h3>
              </div>

              {/* Description */}
              <div className="flex-1">
                <p className="text-gray-400 leading-relaxed mb-3">
                  {area.description}
                </p>
                {area.stats && (
                  <p className="text-sm font-medium text-[#0dc2cc] mb-3">
                    {area.stats}
                  </p>
                )}
              </div>

              {/* CTA */}
              <div className="md:w-48 shrink-0">
                <a
                  href={area.href}
                  className="inline-flex items-center gap-2 text-white text-sm font-medium group-hover:text-[#0dc2cc] transition-colors"
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="#0dc2cc"
                    strokeWidth={3}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M8.25 4.5l7.5 7.5-7.5 7.5"
                    />
                  </svg>
                  <span>{area.cta}</span>
                </a>
              </div>
            </div>
          ))}
          {/* Bottom border */}
          <div className="border-t border-gray-800" />
        </div>
      </div>
    </section>
  );
}
