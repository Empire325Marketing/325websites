export default function ChallengeSection() {
  const problems = [
    {
      problem: "Data Disconnection",
      impact: "AI platforms exist separately from CRM, CDP, marketing automation",
      cost: "Real-time operation impossible",
    },
    {
      problem: "Workflow Isolation",
      impact: "Separate logins, different interfaces, manual processes",
      cost: "Adoption remains minimal",
    },
    {
      problem: "Quality Degradation",
      impact: "Models trained on generic data produce generic insights",
      cost: "Accuracy degrades monthly",
    },
    {
      problem: "Measurement Gaps",
      impact: "AI outputs cannot connect to revenue outcomes",
      cost: "ROI unclear to leadership",
    },
    {
      problem: "Talent Scarcity",
      impact: "No internal expertise to bridge technology and operations",
      cost: "Vendors provide platforms, not integration",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Bento Grid Layout */}
        <div className="grid lg:grid-cols-12 gap-px bg-gray-800">
          {/* Left Column - Header & Description */}
          <div className="lg:col-span-5 bg-black p-6 md:p-10">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              The Challenge
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl text-white leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              The Integration Gap
            </h2>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              87% of enterprises invested in AI tools. Only 23% successfully
              integrated them into production operations.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              This execution gap—not technology access—determines competitive
              outcomes in 2026. The technology exists everywhere. The capability
              to deploy it exists almost nowhere.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed">
              We do not implement disconnected AI tools. We architect AI-powered
              operations where data quality, algorithmic capability, and
              workflow integration compound advantages competitors cannot
              replicate through technology purchases alone.
            </p>
          </div>

          {/* Right Column - Stats Grid */}
          <div className="lg:col-span-7 grid grid-cols-2 gap-px bg-gray-800">
            {/* 87% Stat */}
            <div className="bg-black p-6 md:p-10 flex flex-col justify-between min-h-[150px] md:min-h-[200px]">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider">
                Invested in AI
              </p>
              <div>
                <p className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>
                  87<span className="text-2xl md:text-4xl">%</span>
                </p>
              </div>
            </div>

            {/* 23% Stat */}
            <div className="bg-black p-6 md:p-10 flex flex-col justify-between min-h-[150px] md:min-h-[200px]">
              <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">
                Successfully Integrated
              </p>
              <div>
                <p className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-white" style={{ fontWeight: 1000 }}>
                  23<span className="text-2xl md:text-4xl text-gray-600">%</span>
                </p>
              </div>
            </div>

            {/* $127B */}
            <div className="bg-black p-6 md:p-10">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
                Total Investment 2025
              </p>
              <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>
                $127B
              </p>
              <p className="text-gray-500 text-xs md:text-sm">
                invested in marketing technology
              </p>
            </div>

            {/* $89B */}
            <div className="bg-black p-6 md:p-10">
              <p className="text-gray-600 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
                Wasted (70%)
              </p>
              <p className="text-3xl sm:text-4xl md:text-5xl text-white mb-2" style={{ fontWeight: 1000 }}>
                $89B
              </p>
              <p className="text-gray-500 text-xs md:text-sm">
                minimal return due to integration failure
              </p>
            </div>
          </div>
        </div>

        {/* Why Integration Fails */}
        <div className="mt-12 md:mt-16">
          <div className="flex items-center gap-4 md:gap-6 mb-6 md:mb-8">
            <h3 className="text-lg md:text-xl font-bold text-white">Why Integration Fails</h3>
            <div className="flex-1 h-px bg-gray-800" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-px bg-gray-800">
            {problems.map((item, index) => (
              <div key={index} className={`bg-black p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
                <div className="text-[#0dc2cc] text-xs font-bold mb-3 md:mb-4">
                  {String(index + 1).padStart(2, "0")}
                </div>
                <p className="text-white font-bold mb-2 md:mb-3 text-sm md:text-base">{item.problem}</p>
                <p className="text-gray-500 text-xs md:text-sm mb-3 md:mb-4">{item.impact}</p>
                <div className="pt-3 md:pt-4 border-t border-gray-800">
                  <p className="text-gray-600 text-xs uppercase tracking-wider">Cost</p>
                  <p className="text-gray-400 text-xs md:text-sm">{item.cost}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
