export default function MeasurementSection() {
  const metrics = [
    {
      category: "Revenue Impact",
      items: ["Revenue growth rate", "Pipeline generation", "Deal close rates"],
      target: "340%",
      label: "higher growth",
    },
    {
      category: "Efficiency Gains",
      items: ["Customer acquisition cost", "Marketing spend efficiency", "CAC payback period"],
      target: "40%",
      label: "lower CAC",
    },
    {
      category: "Productivity",
      items: ["Content production velocity", "Campaign optimization speed", "Time to market"],
      target: "10-15X",
      label: "improvement",
    },
    {
      category: "Market Position",
      items: ["Keyword position gains", "Market share growth", "Competitive win rates"],
      target: "67%",
      label: "more positions",
    },
  ];

  const cadence = [
    { period: "Weekly", activities: "Performance tracking, anomaly identification, optimization recommendations" },
    { period: "Monthly", activities: "Trend analysis, model accuracy assessment, strategic adjustments" },
    { period: "Quarterly", activities: "Business impact review, ROI analysis, infrastructure expansion planning" },
    { period: "Annual", activities: "Competitive position assessment, multi-year roadmap, strategic recommendations" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header - Split Layout */}
        <div className="grid lg:grid-cols-12 gap-px bg-gray-200 mb-12 md:mb-16">
          <div className="lg:col-span-8 bg-white p-6 md:p-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Measurement Framework
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Business Impact Metrics
            </h2>
          </div>
          <div className="lg:col-span-4 bg-white p-6 md:p-8 flex items-end">
            <p className="text-gray-500 text-sm md:text-base">
              We measure AI infrastructure success through business impact metrics
              that connect technology deployment to revenue outcomes.
            </p>
          </div>
        </div>

        {/* Metrics - Large Bento Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-12 gap-px bg-gray-200 mb-12 md:mb-16">
          {/* First Metric - Large */}
          <div className="lg:col-span-6 bg-white p-6 md:p-10">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-4 md:mb-6">
              {metrics[0].category}
            </p>
            <div className="flex items-baseline gap-2 mb-4 md:mb-6">
              <span className="text-5xl sm:text-6xl md:text-7xl text-black" style={{ fontWeight: 1000 }}>
                {metrics[0].target}
              </span>
              <span className="text-lg md:text-xl text-gray-400">{metrics[0].label}</span>
            </div>
            <ul className="space-y-2">
              {metrics[0].items.map((item, idx) => (
                <li key={idx} className="text-gray-600 flex gap-2 text-sm md:text-base">
                  <span className="text-[#0dc2cc]">→</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Second Metric */}
          <div className="lg:col-span-6 bg-white p-6 md:p-10">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-4 md:mb-6">
              {metrics[1].category}
            </p>
            <div className="flex items-baseline gap-2 mb-4 md:mb-6">
              <span className="text-5xl sm:text-6xl md:text-7xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>
                {metrics[1].target}
              </span>
              <span className="text-lg md:text-xl text-gray-400">{metrics[1].label}</span>
            </div>
            <ul className="space-y-2">
              {metrics[1].items.map((item, idx) => (
                <li key={idx} className="text-gray-600 flex gap-2 text-sm md:text-base">
                  <span className="text-[#0dc2cc]">→</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Third Metric */}
          <div className="lg:col-span-6 bg-white p-6 md:p-10">
            <p className="text-gray-400 text-xs md:text-sm font-bold uppercase tracking-wider mb-4 md:mb-6">
              {metrics[2].category}
            </p>
            <div className="flex items-baseline gap-2 mb-4 md:mb-6">
              <span className="text-5xl sm:text-6xl md:text-7xl text-black" style={{ fontWeight: 1000 }}>
                {metrics[2].target}
              </span>
              <span className="text-lg md:text-xl text-gray-400">{metrics[2].label}</span>
            </div>
            <ul className="space-y-2">
              {metrics[2].items.map((item, idx) => (
                <li key={idx} className="text-gray-600 flex gap-2 text-sm md:text-base">
                  <span className="text-gray-300">→</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Fourth Metric */}
          <div className="lg:col-span-6 bg-white p-6 md:p-10">
            <p className="text-gray-400 text-xs md:text-sm font-bold uppercase tracking-wider mb-4 md:mb-6">
              {metrics[3].category}
            </p>
            <div className="flex items-baseline gap-2 mb-4 md:mb-6">
              <span className="text-5xl sm:text-6xl md:text-7xl text-black" style={{ fontWeight: 1000 }}>
                {metrics[3].target}
              </span>
              <span className="text-lg md:text-xl text-gray-400">{metrics[3].label}</span>
            </div>
            <ul className="space-y-2">
              {metrics[3].items.map((item, idx) => (
                <li key={idx} className="text-gray-600 flex gap-2 text-sm md:text-base">
                  <span className="text-gray-300">→</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Reporting Cadence - Horizontal Timeline */}
        <div>
          <div className="flex items-center gap-4 md:gap-6 mb-6 md:mb-8">
            <h3 className="text-lg md:text-xl font-bold text-black">Reporting Cadence</h3>
            <div className="flex-1 h-px bg-gray-200" />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200">
            {cadence.map((item, index) => (
              <div key={index} className="bg-white p-4 md:p-6 relative">
                {/* Top accent line */}
                <div
                  className="absolute top-0 left-0 right-0 h-1"
                  style={{
                    background: index === 0 ? "#0dc2cc" : index === 1 ? "#0dc2cc80" : index === 2 ? "#0dc2cc40" : "#0dc2cc20",
                  }}
                />
                <p className="text-black font-bold text-base md:text-lg mb-2">{item.period}</p>
                <p className="text-gray-500 text-xs md:text-sm">{item.activities}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
