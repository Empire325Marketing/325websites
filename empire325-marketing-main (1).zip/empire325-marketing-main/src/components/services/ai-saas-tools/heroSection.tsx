import Button from "@/components/ui/Button";

export default function HeroSection() {
  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Top Section */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          {/* Main Content - Takes 8 columns */}
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              AI SaaS Tools
            </p>

            <h1
              className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] text-black leading-[1.1] mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Systematic Marketing Intelligence Infrastructure
            </h1>

            <div className="grid md:grid-cols-2 gap-4 md:gap-6 mb-6 md:mb-8">
              <p className="text-base md:text-lg text-gray-600 leading-relaxed">
                Enterprise marketing organizations face a fundamental execution
                challenge entering 2026. While 87% invested in AI tools and
                platforms, only 23% successfully integrated these capabilities
                into production operations.
              </p>
              <p className="text-sm md:text-base text-gray-500 leading-relaxed">
                This 64-percentage-point gap between technology ownership and
                operational deployment determines competitive outcomes. Empire325
                architects integrated AI infrastructure transforming marketing
                from manual execution into systematic intelligence engines.
              </p>
            </div>

            <Button href="/company/contact">Get AI Assessment</Button>
          </div>

          {/* Side Stat - Takes 4 columns */}
          <div className="lg:col-span-4 flex items-end">
            <div className="w-full p-6 md:p-8 bg-black text-white">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
                The Gap
              </p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-5xl md:text-6xl" style={{ fontWeight: 1000 }}>64</span>
                <span className="text-xl md:text-2xl text-gray-500">pts</span>
              </div>
              <p className="text-gray-400 text-xs md:text-sm">
                between technology ownership and operational deployment
              </p>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-px bg-gray-200">
          <div className="bg-white p-6 md:p-8">
            <div className="flex items-baseline gap-3">
              <p className="text-3xl sm:text-4xl md:text-5xl text-black" style={{ fontWeight: 1000 }}>340%</p>
            </div>
            <div className="mt-3 md:mt-4 h-px bg-gray-200" />
            <p className="text-gray-600 mt-3 md:mt-4 text-sm md:text-base">Higher revenue growth rates</p>
          </div>

          <div className="bg-white p-6 md:p-8">
            <div className="flex items-baseline gap-3">
              <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>40%</p>
            </div>
            <div className="mt-3 md:mt-4 h-px bg-gray-200" />
            <p className="text-gray-600 mt-3 md:mt-4 text-sm md:text-base">Lower customer acquisition costs</p>
          </div>

          <div className="bg-white p-6 md:p-8">
            <div className="flex items-baseline gap-3">
              <p className="text-3xl sm:text-4xl md:text-5xl text-black" style={{ fontWeight: 1000 }}>10-15X</p>
            </div>
            <div className="mt-3 md:mt-4 h-px bg-gray-200" />
            <p className="text-gray-600 mt-3 md:mt-4 text-sm md:text-base">Content production velocity</p>
          </div>
        </div>

        {/* Bottom Note */}
        <div className="mt-6 md:mt-8 flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-6 text-xs md:text-sm text-gray-500">
          <span>Organizations achieving operational AI integration deliver:</span>
          <span className="hidden sm:block h-px flex-1 bg-gray-200" />
          <span className="text-[#0dc2cc]">Compounding advantages</span>
        </div>
      </div>
    </section>
  );
}
