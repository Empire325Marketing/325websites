export default function CapabilitiesSection() {
  const layers = [
    { name: "AI Generation", desc: "LLMs fine-tuned on your brand voice, learning from historical top performers" },
    { name: "Quality Assurance", desc: "Automated brand compliance, SEO optimization, fact-checking, plagiarism detection" },
    { name: "Expert Oversight", desc: "SME strategic alignment, editorial refinement, leadership approval, compliance" },
    { name: "Performance Tracking", desc: "Engagement metrics, conversion data, SEO rankings inform future generation" },
  ];

  const campaignFeatures = [
    { name: "Real-Time Bidding", desc: "24/7 optimization based on conversion propensity" },
    { name: "Budget Allocation", desc: "Budgets flow to highest-ROI opportunities" },
    { name: "Cross-Channel", desc: "Attribution identifies winning combinations" },
    { name: "Anomaly Detection", desc: "Issues identified in minutes, not days" },
  ];

  const campaignMetrics = [
    { metric: "Customer Acquisition Cost", improvement: "40% reduction", timeline: "6-12 months" },
    { metric: "Conversion Rates", improvement: "2-3X improvement", timeline: "3-6 months" },
    { metric: "Budget Reallocation", improvement: "Real-time", timeline: "Immediate" },
    { metric: "Issue Detection", improvement: "Minutes vs. days", timeline: "Immediate" },
    { metric: "Testing Velocity", improvement: "10-15X increase", timeline: "Immediate" },
  ];

  const audienceCapabilities = [
    { name: "Propensity Modeling", desc: "AI analyzes closed deals identifying behavioral patterns predicting conversion. Propensity scores replace demographic targeting." },
    { name: "Dynamic Segmentation", desc: "Audience segments update in real-time as behavior changes. Messaging adapts to current buyer journey position." },
    { name: "Lookalike Modeling", desc: "AI identifies prospects behaviorally similar to best customers using proprietary first-party data." },
    { name: "Churn & Expansion Prediction", desc: "Models predict churn risk and expansion opportunities. Resources target retention and upsell candidates." },
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-20">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-white leading-tight max-w-3xl"
            style={{ fontWeight: 1000 }}
          >
            AI-Powered Marketing Operations
          </h2>
        </div>

        {/* Capability 1 - Intelligent Content Production */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-xs md:text-sm font-bold">01</span>
            <h3 className="text-lg sm:text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Intelligent Content Production
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-12">
            {/* Description */}
            <div>
              <p className="text-gray-400 leading-relaxed mb-6 md:mb-8 text-sm md:text-base">
                Transform from 30-40 pieces/month to 450+ pieces/month with
                four-layer production system.
              </p>
              <p className="text-white font-bold mb-3 md:mb-4 text-sm md:text-base">Four-Layer System</p>
              <div className="space-y-3 md:space-y-4">
                {layers.map((layer, index) => (
                  <div key={index} className="flex gap-3 md:gap-4">
                    <span className="text-[#0dc2cc] text-xs md:text-sm font-bold">{index + 1}</span>
                    <div>
                      <p className="text-white text-xs md:text-sm font-bold">{layer.name}</p>
                      <p className="text-gray-500 text-xs md:text-sm">{layer.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-row md:flex-col justify-start md:justify-center gap-6 md:gap-0">
              <div className="border-l-2 border-gray-800 pl-4 sm:pl-6 md:pl-8 mb-0 md:mb-6 lg:mb-8">
                <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-1 md:mb-2">Manual</p>
                <p className="text-3xl sm:text-4xl md:text-5xl text-white" style={{ fontWeight: 1000 }}>30-40</p>
                <p className="text-gray-600 text-xs sm:text-sm md:text-base">pieces/month</p>
              </div>
              <div className="border-l-2 border-[#0dc2cc] pl-4 sm:pl-6 md:pl-8">
                <p className="text-[#0dc2cc] text-xs md:text-sm uppercase tracking-wider mb-1 md:mb-2">AI-Powered</p>
                <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>450+</p>
                <p className="text-gray-600 text-xs sm:text-sm md:text-base">pieces/month</p>
              </div>
            </div>

            {/* Outcomes */}
            <div className="bg-gray-900/50 p-5 md:p-6 lg:p-8 md:col-span-2 lg:col-span-1">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-4 md:mb-6 lg:mb-8">Outcomes</p>
              <div className="grid grid-cols-3 md:grid-cols-3 lg:grid-cols-1 gap-4 md:gap-6">
                <div>
                  <p className="text-2xl sm:text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>450+</p>
                  <p className="text-gray-500 text-xs md:text-sm">pieces/month at quality</p>
                </div>
                <div>
                  <p className="text-2xl sm:text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>67%</p>
                  <p className="text-gray-500 text-xs md:text-sm">keyword position gains</p>
                </div>
                <div>
                  <p className="text-2xl sm:text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>10-15X</p>
                  <p className="text-gray-500 text-xs md:text-sm">velocity improvement</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Capability 2 - Autonomous Campaign Optimization */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-xs md:text-sm font-bold">02</span>
            <h3 className="text-lg sm:text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Autonomous Campaign Optimization
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 lg:gap-12">
            {/* Left - Description */}
            <div className="lg:col-span-4">
              <p className="text-gray-400 leading-relaxed mb-6 md:mb-8 text-sm md:text-base">
                From weekly manual reviews to continuous autonomous optimization.
                Human campaign management cannot process sufficient data volume.
              </p>
              <div className="grid grid-cols-2 gap-4 md:gap-6">
                {campaignFeatures.map((feature, index) => (
                  <div key={index}>
                    <p className="text-white font-bold text-xs md:text-sm mb-1">{feature.name}</p>
                    <p className="text-gray-600 text-xs md:text-sm">{feature.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right - Table */}
            <div className="lg:col-span-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 md:mb-4 pb-3 md:pb-4 border-b border-gray-800 gap-2">
                <p className="text-white font-bold text-sm md:text-base">Performance Metrics</p>
                <div className="flex gap-4 md:gap-8 text-xs md:text-sm">
                  <span className="text-gray-600">Manual: 1-2 tests/mo</span>
                  <span className="text-[#0dc2cc]">AI: 10-15 tests/mo</span>
                </div>
              </div>
              <div className="overflow-x-auto -mx-4 sm:mx-0 px-4 sm:px-0">
                <div className="min-w-[350px]">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-gray-500 text-xs md:text-sm">
                        <th className="pb-3 md:pb-4 font-normal">Metric</th>
                        <th className="pb-3 md:pb-4 font-normal">Improvement</th>
                        <th className="pb-3 md:pb-4 font-normal text-right">Timeline</th>
                      </tr>
                    </thead>
                    <tbody>
                      {campaignMetrics.map((row, index) => (
                        <tr key={index} className="border-t border-gray-800">
                          <td className="py-3 md:py-4 text-white text-xs md:text-sm pr-2">{row.metric}</td>
                          <td className="py-3 md:py-4 text-[#0dc2cc] font-bold text-xs md:text-sm">{row.improvement}</td>
                          <td className="py-3 md:py-4 text-gray-600 text-right text-xs md:text-sm">{row.timeline}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Capability 3 - Behavioral Audience Intelligence */}
        <div>
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-xs md:text-sm font-bold">03</span>
            <h3 className="text-lg sm:text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Behavioral Audience Intelligence
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 lg:gap-12">
            {/* Left */}
            <div className="lg:col-span-4">
              <p className="text-gray-400 leading-relaxed mb-6 md:mb-8 text-sm md:text-base">
                From demographic assumptions to predictive intent scoring. Legacy
                targeting relies on demographic profiles weakly correlated with
                purchase propensity.
              </p>
              <div className="flex gap-6 md:gap-8">
                <div>
                  <p className="text-2xl sm:text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>60-70%</p>
                  <p className="text-gray-500 text-xs md:text-sm">Targeting accuracy</p>
                </div>
                <div>
                  <p className="text-2xl sm:text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>40%</p>
                  <p className="text-gray-500 text-xs md:text-sm">Reduced waste</p>
                </div>
              </div>
            </div>

            {/* Right - Grid */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
              {audienceCapabilities.map((cap, index) => (
                <div key={index} className="border-l-2 border-gray-800 pl-4 md:pl-6 hover:border-[#0dc2cc] transition-colors">
                  <p className="text-white font-bold mb-2 text-sm md:text-base">{cap.name}</p>
                  <p className="text-gray-500 text-xs md:text-sm">{cap.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Outcomes */}
          <div className="mt-8 md:mt-12 pt-6 md:pt-8 border-t border-gray-800">
            <div className="flex flex-col sm:flex-row flex-wrap items-start sm:items-center gap-2 sm:gap-3 md:gap-4 text-xs md:text-sm">
              <span className="text-gray-600">Outcomes:</span>
              <span className="text-gray-400">Real-time segmentation vs. quarterly</span>
              <span className="text-gray-700 hidden sm:inline">•</span>
              <span className="text-gray-400">Proprietary lookalike audiences</span>
              <span className="text-gray-700 hidden sm:inline">•</span>
              <span className="text-gray-400">Predictive churn prevention</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
