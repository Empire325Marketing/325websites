export default function ApproachSection() {
  const integrations = [
    { system: "Customer Data Platforms", data: "Behavioral signals across all touchpoints" },
    { system: "CRM Systems", data: "Transaction and relationship data" },
    { system: "Marketing Automation", data: "Engagement sequence tracking" },
    { system: "Product Analytics", data: "Usage patterns and feature adoption" },
    { system: "Support Systems", data: "Issue documentation and resolution paths" },
    { system: "Financial Systems", data: "Marketing activity to revenue outcomes" },
  ];

  const algorithms = [
    { type: "Behavioral Propensity Scoring", function: "Predict conversion likelihood based on engagement signals", accuracy: "70-85%" },
    { type: "Content Intelligence", function: "Match individuals to content most likely to advance journey", accuracy: "60-75%" },
    { type: "Campaign Optimization", function: "Forecast conversion probability by channel, audience, creative", accuracy: "Real-time" },
    { type: "Churn Prediction", function: "Identify at-risk customers before revenue loss", accuracy: "65-80%" },
    { type: "Expansion Detection", function: "Identify upsell/cross-sell opportunities within customer base", accuracy: "55-70%" },
  ];

  const workflows = [
    { area: "Content Production", desc: "AI generation with brand compliance, SEO optimization, fact-checking built-in" },
    { area: "Campaign Management", desc: "Automated bid optimization, creative testing, budget reallocation within existing platforms" },
    { area: "Audience Targeting", desc: "Behavioral propensity scoring, dynamic segmentation, lookalike modeling from proprietary data" },
    { area: "Performance Monitoring", desc: "Automated anomaly detection, optimization recommendations, forecast adjustments" },
  ];

  const crossFunctional = [
    {
      flow: "Marketing → Sales",
      items: ["Behavioral propensity scoring identifies high-intent prospects", "Lead quality scores replace chronological ordering", "Engagement history and predicted objections shared"],
      result: "Higher close rates, shorter sales cycles",
    },
    {
      flow: "Sales → Customer Success",
      items: ["Conversion patterns predict successful onboarding", "Churn risk scoring enables proactive intervention", "Expansion opportunity identification"],
      result: "Higher retention, increased lifetime value",
    },
    {
      flow: "Customer Success → Marketing",
      items: ["Usage patterns identify retention vs. expansion targets", "Support signals trigger marketing interventions", "Satisfaction data refines targeting models"],
      result: "Resources concentrated on highest-value opportunities",
    },
    {
      flow: "All Functions → Finance",
      items: ["Unified intelligence connects spend to revenue outcomes", "Pipeline quality enables accurate forecasting", "Closed-loop attribution demonstrates ROI"],
      result: "Marketing evaluated on business impact",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 md:mb-16 gap-6">
          <div className="max-w-2xl">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Our Approach
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Four Foundational Capabilities
            </h2>
          </div>
          <p className="text-gray-500 max-w-sm lg:text-right text-sm md:text-base">
            Empire325 AI infrastructure rests on four foundational capabilities
            separating operational deployment from technology shelfware.
          </p>
        </div>

        {/* Capability I - Full Width */}
        <div className="mb-px">
          <div className="grid lg:grid-cols-12 gap-px bg-gray-200">
            <div className="lg:col-span-4 bg-white p-6 md:p-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>I</span>
                <div className="h-px flex-1 bg-gray-200" />
              </div>
              <h3 className="text-xl md:text-2xl text-black mb-3 md:mb-4" style={{ fontWeight: 1000 }}>
                Intelligence Architecture
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4 md:mb-6 text-sm md:text-base">
                AI systems generate value proportional to data quality,
                availability, and proprietary nature. Generic AI trained on
                public datasets produces insights competitors access equally.
              </p>
              <div className="p-3 md:p-4 bg-[#0dc2cc]/5 border-l-2 border-[#0dc2cc]">
                <p className="text-xs md:text-sm text-gray-600">
                  <span className="font-bold text-black">Result:</span> Real-time
                  unified customer intelligence enabling AI models to identify
                  patterns, predict behavior, and optimize decisions.
                </p>
              </div>
            </div>
            <div className="lg:col-span-8 bg-white p-6 md:p-8">
              <p className="text-xs md:text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 md:mb-6">
                What We Integrate
              </p>
              <div className="grid sm:grid-cols-2 gap-3 md:gap-4">
                {integrations.map((item, index) => (
                  <div key={index} className="flex items-start gap-2 md:gap-3 p-3 md:p-4 bg-gray-50">
                    <span className="text-[#0dc2cc] font-bold text-xs md:text-sm">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <span className="text-black font-bold text-sm md:text-base">{item.system}</span>
                      <p className="text-gray-500 text-xs md:text-sm">{item.data}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Capability II - Algorithms Table */}
        <div className="mb-px">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-px bg-gray-200">
            <div className="lg:col-span-3 bg-white p-6 md:p-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                <span className="text-4xl md:text-5xl text-black" style={{ fontWeight: 1000 }}>II</span>
                <div className="h-px flex-1 bg-gray-200" />
              </div>
              <h3 className="text-xl md:text-2xl text-black mb-3 md:mb-4" style={{ fontWeight: 1000 }}>
                Algorithmic Development
              </h3>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                Off-the-shelf algorithms trained on industry averages produce
                average results. Competitive advantage requires proprietary models
                trained on your specific data.
              </p>
            </div>
            <div className="lg:col-span-9 bg-white">
              {/* Mobile Card View */}
              <div className="block md:hidden p-4">
                <div className="space-y-4">
                  {algorithms.map((item, index) => (
                    <div key={index} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <p className="text-black font-bold text-sm">{item.type}</p>
                        <span className="inline-block px-2 py-1 bg-[#0dc2cc]/10 text-[#0dc2cc] font-bold text-xs whitespace-nowrap">
                          {item.accuracy}
                        </span>
                      </div>
                      <p className="text-gray-600 text-xs">{item.function}</p>
                    </div>
                  ))}
                </div>
              </div>
              {/* Desktop Table View */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left p-4 text-[#0dc2cc] font-bold text-sm uppercase tracking-wider">Model Type</th>
                      <th className="text-left p-4 text-[#0dc2cc] font-bold text-sm uppercase tracking-wider">Function</th>
                      <th className="text-right p-4 text-[#0dc2cc] font-bold text-sm uppercase tracking-wider">Accuracy</th>
                    </tr>
                  </thead>
                  <tbody>
                    {algorithms.map((item, index) => (
                      <tr key={index} className="border-b border-gray-100">
                        <td className="p-4 text-black font-bold text-sm">{item.type}</td>
                        <td className="p-4 text-gray-600 text-sm">{item.function}</td>
                        <td className="p-4 text-right">
                          <span className="inline-block px-3 py-1 bg-[#0dc2cc]/10 text-[#0dc2cc] font-bold text-sm">
                            {item.accuracy}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="p-3 md:p-4 text-gray-500 text-xs md:text-sm border-t border-gray-100">
                Models improve continuously through closed-loop learning from outcomes.
              </p>
            </div>
          </div>
        </div>

        {/* Capability III - Workflows */}
        <div className="mb-px">
          <div className="grid lg:grid-cols-12 gap-px bg-gray-200">
            <div className="lg:col-span-4 bg-white p-6 md:p-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>III</span>
                <div className="h-px flex-1 bg-gray-200" />
              </div>
              <h3 className="text-xl md:text-2xl text-black mb-3 md:mb-4" style={{ fontWeight: 1000 }}>
                Workflow Integration
              </h3>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                AI capabilities generate business impact when integrated into
                daily operations—not separate platforms requiring new workflows.
              </p>
            </div>
            <div className="lg:col-span-8 bg-white p-6 md:p-8">
              <p className="text-xs md:text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 md:mb-6">
                AI-Augmented Systems
              </p>
              <div className="grid sm:grid-cols-2 gap-px bg-gray-200">
                {workflows.map((item, index) => (
                  <div key={index} className="bg-white p-4 md:p-6">
                    <p className="text-black font-bold mb-2 text-sm md:text-base">{item.area}</p>
                    <p className="text-gray-500 text-xs md:text-sm">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Capability IV - Cross-Functional */}
        <div>
          <div className="grid lg:grid-cols-12 gap-px bg-gray-200">
            <div className="lg:col-span-3 bg-white p-6 md:p-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                <span className="text-4xl md:text-5xl text-black" style={{ fontWeight: 1000 }}>IV</span>
                <div className="h-px flex-1 bg-gray-200" />
              </div>
              <h3 className="text-xl md:text-2xl text-black mb-3 md:mb-4" style={{ fontWeight: 1000 }}>
                Cross-Functional Deployment
              </h3>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                AI infrastructure generates maximum return when deployed across
                marketing, sales, and customer success—not siloed within marketing
                alone.
              </p>
            </div>
            <div className="lg:col-span-9 grid sm:grid-cols-2 gap-px bg-gray-200">
              {crossFunctional.map((item, index) => (
                <div key={index} className="bg-white p-4 md:p-6">
                  <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">{item.flow}</p>
                  <ul className="space-y-2 mb-3 md:mb-4">
                    {item.items.map((point, idx) => (
                      <li key={idx} className="text-gray-600 text-xs md:text-sm flex gap-2">
                        <span className="text-[#0dc2cc]">→</span>
                        {point}
                      </li>
                    ))}
                  </ul>
                  <div className="pt-3 md:pt-4 border-t border-gray-100">
                    <p className="text-xs md:text-sm">
                      <span className="font-bold text-black">Result:</span>{" "}
                      <span className="text-gray-500">{item.result}</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
