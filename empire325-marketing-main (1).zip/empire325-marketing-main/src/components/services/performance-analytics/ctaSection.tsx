import Button from "@/components/ui/Button";

export default function CTASection() {
  const timeline = [
    {
      phase: "Assessment & Discovery",
      duration: "Weeks 1-3",
      desc: "Comprehensive audit of existing analytics infrastructure including all platforms, reporting processes, attribution models, and data flows. Current-state documentation identifying gaps, inconsistencies, and improvement opportunities. Requirements gathering with stakeholders across marketing, sales, finance. Measurement framework design and implementation roadmap.",
    },
    {
      phase: "Foundation Build",
      duration: "Months 1-3",
      desc: "Data integration infrastructure connecting all platforms to centralized repository, attribution model implementation tracking customer journey touchpoints, initial dashboard deployment for executive and operational audiences, automated reporting replacement of manual processes, data quality validation and governance establishment.",
    },
    {
      phase: "Optimization & Expansion",
      duration: "Months 3-6",
      desc: "Advanced attribution models deployment (algorithmic, position-based), predictive analytics and forecasting capabilities implementation, self-service analytics enablement across organization, dashboard refinement based on user feedback, additional platform integrations and data source connections.",
    },
    {
      phase: "Maturity & Innovation",
      duration: "Months 6-12",
      desc: "Machine learning model deployment for forecasting and optimization, advanced segmentation and cohort analysis capabilities, competitive benchmarking and market intelligence integration, continuous improvement based on organizational needs, strategic consulting and data science partnership.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Getting Started
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Implementation Timeline
            </h2>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed">
              Performance analytics implementation requires systematic integration across marketing technology stack and organizational alignment on measurement standards. Organizations beginning this work achieve measurable improvements in reporting speed and attribution visibility within first 60-90 days as unified infrastructure replaces fragmented manual processes.
            </p>
          </div>
          <div className="lg:col-span-4">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>6-9</p>
                <p className="text-gray-500 text-xs md:text-sm">months to positive ROI</p>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>60-90</p>
                <p className="text-gray-500 text-xs md:text-sm">days to first results</p>
              </div>
            </div>
          </div>
        </div>

        {/* What To Expect */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-white font-bold mb-6 md:mb-8">What To Expect</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-800">
            {timeline.map((item, index) => (
              <div key={index} className="bg-black p-4 md:p-6">
                <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                  <span
                    className="text-2xl md:text-3xl text-[#0dc2cc]"
                    style={{ fontWeight: 1000, opacity: 1 - index * 0.2 }}
                  >
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>
                <p className="text-white font-bold mb-1 text-sm md:text-base">{item.phase}</p>
                <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-2 md:mb-3">{item.duration}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Investment & CTA */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 pt-12 md:pt-16 border-t border-gray-800">
          <div className="lg:col-span-7">
            <h3 className="text-lg md:text-xl font-bold text-white mb-3 md:mb-4">
              Investment Considerations
            </h3>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              Performance analytics investment spans platform integration, dashboard development, and ongoing analytical support. Investment varies based on technology stack complexity, data volumes, and organizational scope. Organizations typically achieve positive ROI within 6-9 months through analyst time savings, faster optimization cycles, and improved budget allocation efficiency eliminating wasted spend.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
              Organizations unable to prove marketing&apos;s revenue contribution face existential risk. Unified performance analytics and attribution infrastructure provide measurement certainty enabling confident executive decision-making and sustained marketing investment.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
              Our team is available to discuss performance analytics assessment and implementation roadmap specific to your organization&apos;s current measurement infrastructure, technology platforms, and business objectives.
            </p>
            <div className="flex flex-col sm:flex-row flex-wrap gap-4">
              <Button href="/company/contact" variant="secondary">
                Schedule Analytics Assessment
              </Button>
              <a
                href="mailto:analytics@empire325marketing.com"
                className="text-gray-500 hover:text-white text-xs md:text-sm flex items-center gap-2 transition-colors"
              >
                analytics@empire325marketing.com
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>6-9mo</p>
                <p className="text-gray-500 text-xs md:text-sm">Positive ROI Timeline</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-[#0dc2cc]" style={{ width: "70%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-white" style={{ fontWeight: 1000 }}>70-85%</p>
                <p className="text-gray-500 text-xs md:text-sm">Time Savings</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-white" style={{ width: "100%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6 col-span-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-1">Competitive Advantage</p>
                    <p className="text-xl md:text-2xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>95%+ Attribution</p>
                    <p className="text-gray-500 text-xs md:text-sm">first touch to revenue tracking</p>
                  </div>
                  <div className="text-4xl md:text-6xl text-gray-800 hidden sm:block">→</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-12 md:mt-16 pt-6 md:pt-8 border-t border-gray-800">
          <p className="text-gray-600 text-xs md:text-sm">
            For comprehensive market analysis, reference the 2026 Enterprise Marketing Outlook from Empire325 Marketing Intelligence Group.
          </p>
        </div>
      </div>
    </section>
  );
}
