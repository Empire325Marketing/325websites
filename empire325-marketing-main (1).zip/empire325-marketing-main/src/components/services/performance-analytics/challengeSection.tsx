export default function ChallengeSection() {
  const measurementGapTable = [
    { failure: "Last-Click Attribution Bias", manifestation: "All credit assigned to final touchpoint before conversion, ignoring awareness and nurturing investment", impact: "Top-of-funnel budget eliminated, pipeline dries up within 6-12 months" },
    { failure: "Fragmented Reporting", manifestation: "Marketing, sales, finance each maintain separate analytics generating conflicting metrics", impact: "Organizational paralysis as executives debate data accuracy rather than strategy" },
    { failure: "Vanity Metrics Focus", manifestation: "Reports emphasize clicks, impressions, engagement—metrics disconnected from revenue", impact: "CFO loses confidence in marketing, budget cuts follow" },
    { failure: "Manual Reporting Burden", manifestation: "Analysts spend 15-20 hours weekly compiling reports from disconnected platforms", impact: "Reports arrive 2-4 weeks after period close, data already stale" },
    { failure: "No Predictive Capability", manifestation: "Analytics limited to historical performance, no forecasting or scenario modeling", impact: "Budget planning based on guesses rather than data-driven projections" },
  ];

  const problems = [
    {
      title: "Platform Fragmentation",
      desc: "Marketing technology stacks span 10-15 platforms—CRM, marketing automation, advertising platforms, analytics tools, website, attribution software. Each generates independent reports using different methodologies and timeframes. No unified measurement infrastructure exists. Reconciliation requires manual effort prone to errors and inconsistency.",
    },
    {
      title: "Attribution Complexity",
      desc: "Customer journeys span multiple touchpoints across channels and timeframes. Awareness touchpoint occurs months before conversion. Mid-funnel nurturing involves content, webinars, sales interactions. Conversion attribution models oversimplify reality—last-click, first-click, linear—producing misleading conclusions about channel contribution.",
    },
    {
      title: "Technical Capability Gaps",
      desc: "Marketing teams lack data engineering resources required for unified measurement infrastructure. Analytics requests queue behind IT priorities. External agencies provide reports but not integrated systems. Sophisticated attribution models require statistical expertise and technology infrastructure most organizations don't possess.",
    },
    {
      title: "Organizational Silos",
      desc: "Marketing, sales, finance, product teams maintain separate analytics serving departmental needs rather than organizational understanding. Marketing measures leads, sales tracks pipeline, finance calculates customer acquisition costs, product analyzes usage. Integration attempts fail due to conflicting priorities and measurement definitions.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            The Challenge
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
            style={{ fontWeight: 1000 }}
          >
            The Attribution and Measurement Crisis
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-4xl">
            Marketing leadership operates with measurement infrastructure preventing confident demonstration of revenue contribution. Organizations invest extensively in marketing activities—paid advertising, content, events, sales enablement—yet lack attribution systems connecting investment to outcomes. CFOs request marketing ROI; CMOs cannot answer with certainty.
          </p>
        </div>

        {/* Measurement Gap Table */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-4 md:mb-6">The Measurement Gap</h3>
          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-300">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Measurement Failure</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Manifestation</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Business Impact</p>
                </div>
              </div>
              {measurementGapTable.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-300">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-xs md:text-sm">{row.failure}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.manifestation}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] text-xs md:text-sm font-bold">{row.impact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Why Measurement Fails */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Why Measurement Fails</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {problems.map((problem, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-black font-bold mb-2 md:mb-3 text-sm md:text-base">{problem.title}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{problem.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Callout */}
        <div className="bg-black p-6 md:p-10">
          <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
            The Cost of Measurement Failure
          </p>
          <p className="text-white text-sm md:text-lg leading-relaxed mb-4 md:mb-6">
            Organizations without unified performance measurement and attribution operate with systematic disadvantages: 15-20 hours weekly per analyst on manual reporting, 2-4 week delays preventing real-time optimization, 30-40% marketing budget allocated suboptimally due to attribution blind spots, executive teams questioning marketing value and reducing investment during economic uncertainty.
          </p>
          <p className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
            Inability to prove marketing contribution creates existential risk to marketing organizations.
          </p>
        </div>
      </div>
    </section>
  );
}
