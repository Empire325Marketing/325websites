export default function MeasurementSection() {
  const measurementFramework = [
    {
      category: "Attribution Accuracy",
      metrics: ["Customer journey touchpoint coverage", "Revenue attribution precision", "Marketing ROI confidence"],
      target: "95%+ journey tracking Closed-loop revenue visibility Confident budget decisions",
    },
    {
      category: "Reporting Speed",
      metrics: ["Time to insight", "Dashboard availability", "Manual effort reduction"],
      target: "Minutes vs. weeks Real-time access 24/7 70-85% time savings",
    },
    {
      category: "Decision Velocity",
      metrics: ["Optimization cycle speed", "Budget reallocation frequency", "Strategic planning efficiency"],
      target: "40-60% faster decisions Weekly vs. monthly Data-driven strategy",
    },
    {
      category: "Forecast Accuracy",
      metrics: ["Pipeline prediction precision", "Revenue forecast variance", "Planning confidence"],
      target: "85-90% accuracy ±10% variance Reliable targets",
    },
    {
      category: "Organizational Impact",
      metrics: ["Executive confidence in marketing", "Single source of truth adoption", "Budget allocation effectiveness"],
      target: "CFO trust established Zero conflicting reports Optimized spend allocation",
    },
  ];

  const reportingCadence = [
    { frequency: "Real-Time", activities: "Dashboards accessible 24/7 with current-day data" },
    { frequency: "Weekly", activities: "Automated performance summaries and anomaly alerts" },
    { frequency: "Monthly", activities: "Business review with strategic insights and optimization recommendations" },
    { frequency: "Quarterly", activities: "Forecast updates, attribution analysis, strategic planning support" },
    { frequency: "Annual", activities: "Performance retrospective, media mix modeling, budget planning framework" },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Measurement Framework
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Business Impact Metrics
            </h2>
          </div>
          <div className="lg:col-span-4 flex items-end">
            <p className="text-sm md:text-base text-gray-600">
              We measure performance analytics success through business impact metrics demonstrating marketing&apos;s provable contribution to revenue outcomes and organizational efficiency gains.
            </p>
          </div>
        </div>

        {/* Metrics Table */}
        <div className="mb-12 md:mb-16 overflow-x-auto">
          <div className="min-w-[600px]">
            <div className="grid grid-cols-3 gap-px bg-gray-300">
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Category</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Primary Metrics</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Target Performance</p>
              </div>
            </div>
            {measurementFramework.map((row, index) => (
              <div key={index} className="grid grid-cols-3 gap-px bg-gray-300">
                <div className="bg-white p-3 md:p-4">
                  <p className="text-black font-bold text-xs md:text-sm">{row.category}</p>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <ul className="space-y-1">
                    {row.metrics.map((metric, idx) => (
                      <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                        <span className="text-[#0dc2cc]">•</span>
                        {metric}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.target}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Metrics Visual */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-300 mb-12 md:mb-16">
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>95%+</p>
            <p className="text-gray-500 text-xs md:text-sm">attribution accuracy</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">journey tracking</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>70-85%</p>
            <p className="text-gray-500 text-xs md:text-sm">time savings</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">manual reporting</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>85-90%</p>
            <p className="text-gray-500 text-xs md:text-sm">forecast accuracy</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">±10% variance</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>40-60%</p>
            <p className="text-gray-500 text-xs md:text-sm">faster decisions</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">optimization cycles</p>
          </div>
        </div>

        {/* Reporting Cadence */}
        <div>
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Reporting Cadence</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            {reportingCadence.map((item, index) => (
              <div key={index} className={`border-t-2 border-gray-300 pt-4 md:pt-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
                <p className="text-[#0dc2cc] font-bold mb-2 text-sm md:text-base">{item.frequency}</p>
                <p className="text-gray-600 text-xs md:text-sm">{item.activities}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
