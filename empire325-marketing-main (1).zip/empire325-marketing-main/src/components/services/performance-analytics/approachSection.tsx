export default function ApproachSection() {
  const attributionModels = [
    {
      model: "First-Touch Attribution",
      methodology: "100% credit to initial awareness touchpoint introducing prospect to brand",
      useCase: "Measuring top-of-funnel campaign effectiveness and new audience generation",
    },
    {
      model: "Last-Touch Attribution",
      methodology: "100% credit to final touchpoint immediately before conversion",
      useCase: "Understanding conversion drivers and bottom-funnel channel performance",
    },
    {
      model: "Linear Attribution",
      methodology: "Equal credit distributed across all touchpoints in customer journey",
      useCase: "Acknowledging full journey contribution without weighting assumptions",
    },
    {
      model: "Time-Decay Attribution",
      methodology: "More credit to recent touchpoints, less to earlier interactions",
      useCase: "Balancing journey awareness with conversion proximity",
    },
    {
      model: "Position-Based (U-Shaped)",
      methodology: "40% credit to first touch, 40% to conversion touch, 20% distributed across middle",
      useCase: "Emphasizing awareness generation and conversion while acknowledging nurturing",
    },
    {
      model: "Algorithmic Attribution",
      methodology: "Machine learning determines credit based on actual conversion contribution patterns",
      useCase: "Most accurate attribution reflecting true channel impact on revenue",
    },
  ];

  const revenueTracking = [
    "CRM integration connecting closed deals back to marketing touchpoints",
    "Closed-loop reporting from first website visit through invoice payment",
    "Campaign-level revenue attribution showing which investments drive actual business outcomes",
    "Customer lifetime value tracking attributing expansion and retention to marketing",
    "Marketing-influenced vs. marketing-sourced pipeline distinction",
  ];

  const dashboardInfra = {
    executive: [
      "Revenue and pipeline performance trends",
      "Customer acquisition cost and ROI metrics",
      "Channel performance and budget allocation",
      "Forecast vs. actual performance tracking",
    ],
    marketing: [
      "Campaign performance across all channels",
      "Lead generation volume, quality, conversion rates",
      "Content engagement and effectiveness metrics",
      "Marketing automation and email performance",
    ],
    sales: [
      "Pipeline source attribution (marketing vs. sales-sourced)",
      "Lead quality scores and conversion rates",
      "Sales cycle length by lead source",
      "Revenue by acquisition channel",
    ],
    financial: [
      "Customer acquisition cost by channel and campaign",
      "Return on ad spend (ROAS) and marketing ROI",
      "Customer lifetime value and payback period",
      "Budget pacing and spend efficiency",
    ],
  };

  const selfServiceAnalytics = [
    "Interactive dashboards enabling drill-down analysis without analyst requests",
    "Custom report builder for ad-hoc questions",
    "Scheduled automated reports delivered via email",
    "Mobile-optimized access for executive on-the-go visibility",
    "Alerting on metrics exceeding thresholds or showing anomalies",
  ];

  const predictiveCapabilities = {
    pipeline: [
      "Machine learning models predicting future pipeline generation",
      "Lead-to-opportunity and opportunity-to-close rate predictions",
      "Revenue forecasts with confidence intervals",
      "85-90% forecast accuracy within 10% variance",
    ],
    scenario: [
      "What-if analysis for budget reallocation decisions",
      "Impact projections for new channel investments",
      "Sensitivity analysis identifying highest-leverage variables",
      "Optimization recommendations for resource allocation",
    ],
    churn: [
      "Customer churn risk scoring for proactive retention",
      "Expansion opportunity identification based on usage patterns",
      "Lifetime value projections informing acquisition spending",
      "Cohort analysis tracking long-term customer value trends",
    ],
    mediaMix: [
      "Statistical analysis quantifying channel contribution to outcomes",
      "Optimal budget allocation recommendations across channels",
      "Diminishing returns curves identifying saturation points",
      "Annual planning models supporting strategic budget decisions",
    ],
  };

  const platformConnectivity = [
    "CRM Systems: Salesforce, HubSpot, Microsoft Dynamics integration",
    "Marketing Automation: HubSpot, Marketo, Pardot, Eloqua data extraction",
    "Advertising Platforms: Google Ads, Meta, LinkedIn, programmatic display",
    "Analytics: Google Analytics, Adobe Analytics, Mixpanel, Amplitude",
    "Website & Product: Usage tracking, form submissions, behavioral data",
    "Finance Systems: Revenue data, customer acquisition cost calculation",
  ];

  const dataQuality = [
    "Automated data validation ensuring accuracy and completeness",
    "Deduplication and entity resolution for unified customer records",
    "Standardized metric definitions eliminating conflicting calculations",
    "Data lineage tracking from source through reporting",
    "Governance controls ensuring consistent organizational standards",
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Our Approach
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
            style={{ fontWeight: 1000 }}
          >
            Unified Performance Analytics Infrastructure
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-4xl">
            Empire325 performance analytics delivers unified measurement infrastructure connecting marketing investment to revenue outcomes through multi-touch attribution, real-time dashboards, and predictive modeling enabling confident budget allocation and strategic planning.
          </p>
        </div>

        {/* I. Multi-Touch Attribution & Revenue Tracking */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>I</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Multi-Touch Attribution & Revenue Tracking</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Comprehensive attribution infrastructure tracking complete customer journey from first touchpoint through closed deal, crediting all contributing marketing activities and enabling accurate ROI measurement.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Attribution Framework</h4>
          <div className="overflow-x-auto mb-8 md:mb-10">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Attribution Model</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Methodology</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Use Case</p>
                </div>
              </div>
              {attributionModels.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.model}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.methodology}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.useCase}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Revenue Tracking Infrastructure</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8 md:mb-10">
            {revenueTracking.map((item, idx) => (
              <div key={idx} className="bg-gray-50 p-4">
                <p className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {item}
                </p>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-xs md:text-sm text-gray-500 uppercase tracking-wider mb-2">Result</p>
            <p className="text-sm md:text-base text-black font-bold">
              95%+ attribution accuracy enabling confident answers to executive questions about marketing&apos;s revenue contribution and optimal budget allocation.
            </p>
          </div>
        </div>

        {/* II. Real-Time Performance Dashboards */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>II</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Real-Time Performance Dashboards</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Executive and operational dashboards providing immediate access to performance metrics, eliminating manual reporting cycles and enabling self-service analytics across organization.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Dashboard Infrastructure</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-200 mb-8 md:mb-10">
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Executive Dashboards</p>
              <ul className="space-y-2">
                {dashboardInfra.executive.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Marketing Operations</p>
              <ul className="space-y-2">
                {dashboardInfra.marketing.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Sales Performance</p>
              <ul className="space-y-2">
                {dashboardInfra.sales.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Financial Metrics</p>
              <ul className="space-y-2">
                {dashboardInfra.financial.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Self-Service Analytics</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8 md:mb-10">
            {selfServiceAnalytics.map((item, idx) => (
              <div key={idx} className="bg-gray-50 p-4">
                <p className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {item}
                </p>
              </div>
            ))}
          </div>

          {/* Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-200">
            <div className="bg-gray-100 p-4 md:p-6">
              <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Manual Reporting</p>
              <ul className="space-y-2">
                <li className="text-gray-600 text-xs md:text-sm">15-20 hours per analyst weekly</li>
                <li className="text-gray-600 text-xs md:text-sm">2-4 week reporting cycles</li>
                <li className="text-gray-600 text-xs md:text-sm">Data stale when delivered</li>
              </ul>
            </div>
            <div className="bg-black p-4 md:p-6">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Real-Time Dashboards</p>
              <ul className="space-y-2">
                <li className="text-white text-xs md:text-sm">Instant access 24/7</li>
                <li className="text-white text-xs md:text-sm">Minutes for insights</li>
                <li className="text-white text-xs md:text-sm">70-85% time reduction</li>
              </ul>
            </div>
          </div>
        </div>

        {/* III. Predictive Analytics & Forecasting */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>III</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Predictive Analytics & Forecasting</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Forward-looking analytics enabling accurate pipeline forecasting, scenario modeling, and strategic planning based on data-driven projections rather than assumptions.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Predictive Capabilities</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Pipeline Forecasting</p>
              <ul className="space-y-2">
                {predictiveCapabilities.pipeline.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Scenario Modeling</p>
              <ul className="space-y-2">
                {predictiveCapabilities.scenario.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Churn & Expansion Prediction</p>
              <ul className="space-y-2">
                {predictiveCapabilities.churn.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Media Mix Modeling</p>
              <ul className="space-y-2">
                {predictiveCapabilities.mediaMix.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-xs md:text-sm text-gray-500 uppercase tracking-wider mb-2">Result</p>
            <p className="text-sm md:text-base text-black font-bold">
              Data-driven strategic planning replacing guesswork with accurate forecasts enabling confident investment decisions and realistic target setting.
            </p>
          </div>
        </div>

        {/* IV. Unified Data Integration */}
        <div>
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>IV</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Unified Data Integration</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Centralized data infrastructure connecting all marketing, sales, and product platforms into unified analytics repository enabling single source of truth across organization.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Integration Architecture</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Platform Connectivity</p>
              <ul className="space-y-2">
                {platformConnectivity.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Data Quality & Governance</p>
              <ul className="space-y-2">
                {dataQuality.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-xs md:text-sm text-gray-500 uppercase tracking-wider mb-2">Result</p>
            <p className="text-sm md:text-base text-black font-bold">
              Single source of truth eliminating conflicting reports and organizational debate about data accuracy enabling confident decision-making.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
