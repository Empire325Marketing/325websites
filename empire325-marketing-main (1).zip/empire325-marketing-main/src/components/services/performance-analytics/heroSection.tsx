import Button from "@/components/ui/Button";

export default function HeroSection() {
  const outcomes = [
    { stat: "70-85%", label: "reduction in reporting cycle time from weeks to hours" },
    { stat: "95%+", label: "attribution accuracy tracking customer journey from first touch to revenue" },
    { stat: "40-60%", label: "faster optimization cycles through real-time performance visibility" },
    { stat: "Single", label: "source of truth eliminating conflicting reports across organization" },
    { stat: "85-90%", label: "forecast accuracy through predictive analytics and modeling" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Main Grid */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          {/* Left Content */}
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Performance & Analytics
            </p>
            <h1
              className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] text-black leading-[1.1] mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Revenue Attribution and Decision Intelligence Connecting Marketing to Business Outcomes
            </h1>
            <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6 md:mb-8">
              Enterprise marketing effectiveness is measured not by activity metrics—clicks, impressions, engagement—but by provable contribution to revenue outcomes. Organizations with unified performance measurement and multi-touch attribution infrastructure connecting marketing investment to closed deals achieve measurably superior budget allocation, executive confidence, and customer acquisition economics.
            </p>
            <p className="text-sm md:text-base text-gray-500 leading-relaxed mb-8 md:mb-10">
              Most enterprises operate with fragmented analytics generating conflicting reports: marketing claims success based on leads, sales reports conversion rates, finance calculates customer acquisition costs—three different answers to fundamental business questions. Budget decisions rest on assumptions rather than measurement certainty.
            </p>
            <Button href="/company/contact" variant="primary">
              Assess Your Analytics Infrastructure
            </Button>
          </div>

          {/* Right - The Gap */}
          <div className="lg:col-span-4 bg-black p-6 md:p-8 flex flex-col justify-between min-h-[200px]">
            <div>
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">The Advantage</p>
              <p className="text-4xl sm:text-5xl md:text-6xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>95%+</p>
              <p className="text-white mt-2 text-sm md:text-base">attribution accuracy</p>
            </div>
            <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-gray-800">
              <p className="text-gray-500 text-xs md:text-sm">
                first touch to revenue tracking
              </p>
            </div>
          </div>
        </div>

        {/* Intro Text */}
        <div className="mb-6 md:mb-10">
          <p className="text-sm md:text-base text-gray-600">
            Organizations with unified performance analytics and revenue attribution deliver measurable advantages:
          </p>
        </div>

        {/* Outcomes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px bg-gray-200">
          {outcomes.map((item, index) => (
            <div key={index} className={`bg-white p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
              <p className="text-2xl md:text-3xl text-black mb-2" style={{ fontWeight: 1000 }}>
                {item.stat}
              </p>
              <p className="text-gray-500 text-xs md:text-sm">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Bottom Statement */}
        <div className="mt-8 md:mt-10 pt-8 md:pt-10 border-t border-gray-200">
          <p className="text-base md:text-lg text-black" style={{ fontWeight: 1000 }}>
            Empire325 performance analytics delivers unified measurement infrastructure connecting marketing activities to revenue outcomes with attribution certainty enabling confident budget allocation and strategic planning.
          </p>
        </div>
      </div>
    </section>
  );
}
