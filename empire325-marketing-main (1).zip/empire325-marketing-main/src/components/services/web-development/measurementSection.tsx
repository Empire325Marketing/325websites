export default function MeasurementSection() {
  const measurementFramework = [
    {
      category: "Conversion Performance",
      metrics: ["Overall conversion rate", "Page-specific conversion rates", "Form completion rates"],
      target: "45-120% improvement first 12 months",
    },
    {
      category: "Technical Performance",
      metrics: ["Core Web Vitals scores", "Page load times", "Bounce rates"],
      target: "90+ Core Web Vitals <3s load times 25-40% bounce reduction",
    },
    {
      category: "Organic Visibility",
      metrics: ["Keyword rankings", "Organic traffic volume", "Featured snippet capture"],
      target: "67% more high-value positions 40-80% traffic growth 24 months sustained",
    },
    {
      category: "Revenue Impact",
      metrics: ["Pipeline generation from website", "Customer acquisition cost", "Lead quality scores"],
      target: "Closed-loop attribution from first touch to revenue outcome",
    },
    {
      category: "Optimization Activity",
      metrics: ["Testing velocity", "Win rate on experiments", "Compound improvement rate"],
      target: "4-8 tests/month 35-45% win rate 15-25% annual compound",
    },
  ];

  const reportingCadence = [
    { frequency: "Weekly", activities: "Testing results, performance monitoring, technical issue identification" },
    { frequency: "Monthly", activities: "Conversion trend analysis, SEO progress, optimization recommendations" },
    { frequency: "Quarterly", activities: "Business impact review, strategic planning, competitive analysis" },
    { frequency: "Annual", activities: "Infrastructure maturity assessment, ROI analysis, multi-year roadmap" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Measurement Framework
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Business Impact Metrics
            </h2>
          </div>
          <div className="lg:col-span-4 flex items-end">
            <p className="text-sm md:text-base text-gray-600">
              We measure website infrastructure success through business impact metrics that connect technical performance and optimization activity to revenue outcomes.
            </p>
          </div>
        </div>

        {/* Metrics Table */}
        <div className="mb-12 md:mb-16 overflow-x-auto">
          <div className="min-w-[600px]">
            <div className="grid grid-cols-3 gap-px bg-gray-200">
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Category</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Primary Metrics</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Target Performance</p>
              </div>
            </div>
            {measurementFramework.map((row, index) => (
              <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-white p-3 md:p-4">
                  <p className="text-black font-bold text-xs md:text-sm">{row.category}</p>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <ul className="space-y-1">
                    {row.metrics.map((metric, idx) => (
                      <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                        <span className="text-[#0dc2cc]">•</span>
                        {metric}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.target}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Metrics Visual */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200 mb-12 md:mb-16">
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>45-120%</p>
            <p className="text-gray-500 text-xs md:text-sm">conversion improvement</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">first 12 months</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>90+</p>
            <p className="text-gray-500 text-xs md:text-sm">Core Web Vitals</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">&lt;3s load times</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>67%</p>
            <p className="text-gray-500 text-xs md:text-sm">keyword position gains</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">high-value terms</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>15-25%</p>
            <p className="text-gray-500 text-xs md:text-sm">annual compound</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">continuous improvement</p>
          </div>
        </div>

        {/* Reporting Cadence */}
        <div>
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Reporting Cadence</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {reportingCadence.map((item, index) => (
              <div key={index} className="border-t-2 border-gray-200 pt-4 md:pt-6">
                <p className="text-[#0dc2cc] font-bold mb-2 text-sm md:text-base">{item.frequency}</p>
                <p className="text-gray-600 text-xs md:text-sm">{item.activities}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
