export default function ChallengeSection() {
  const performanceGap = [
    { metric: "Load Time", standard: "5-8 seconds", optimized: "<3 seconds" },
    { metric: "Core Web Vitals", standard: "40-60 score", optimized: "90+ score" },
    { metric: "Testing Velocity", standard: "0-2 tests/year", optimized: "4-8 tests/month" },
    { metric: "Bounce Rate", standard: "55-70%", optimized: "30-45%" },
    { metric: "Annual Improvement", standard: "Static/declining", optimized: "15-25% compound" },
  ];

  const problems = [
    {
      title: "Design Over Performance",
      desc: "Websites are evaluated on aesthetic appeal rather than conversion performance and technical excellence. Design decisions prioritize visual impact over page speed, causing performance degradation that directly reduces revenue.",
    },
    {
      title: "Launch-and-Abandon Mentality",
      desc: "Websites are treated as projects with completion dates rather than infrastructure requiring continuous optimization. Post-launch testing and improvement cease. Performance degrades as content expands, traffic increases, and competitive benchmarks rise.",
    },
    {
      title: "Opinion-Based Decisions",
      desc: "Changes are made based on stakeholder preferences rather than systematic testing. Highest-paid person's opinion (HiPPO) replaces statistical validation. Conversion optimization opportunities are missed because testing infrastructure doesn't exist.",
    },
    {
      title: "Disconnected from Revenue",
      desc: "Website performance is measured through traffic volume and engagement metrics disconnected from pipeline generation and customer acquisition. Marketing cannot demonstrate ROI. Finance cannot forecast impact from website improvements.",
    },
    {
      title: "Technical Debt Accumulation",
      desc: "Platform updates are postponed. Security patches are delayed. Plugin dependencies multiply. Code quality degrades. Eventually, complete rebuilds become necessary because incremental improvement is technically impossible.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-7">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              The Challenge
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              The Performance Imperative
            </h2>
            <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-4">
              Website performance directly determines conversion rates, search rankings, and user experience. Yet most enterprise websites operate with performance profiles preventing competitive conversion and organic visibility.
            </p>
            <p className="text-sm md:text-base text-gray-600 leading-relaxed">
              Organizations achieving sub-3-second load times with 90+ Core Web Vitals scores convert 45-120% higher than competitors with standard performance. Those running systematic A/B testing compound improvements by 15-25% annually. Organizations without optimization infrastructure watch static performance while competitors compound advantages monthly.
            </p>
          </div>

          <div className="lg:col-span-5">
            <div className="grid grid-cols-2 gap-px bg-gray-300">
              <div className="bg-white p-4 md:p-6">
                <p className="text-3xl sm:text-4xl md:text-5xl text-black" style={{ fontWeight: 1000 }}>45-120%</p>
                <p className="text-gray-500 text-xs md:text-sm mt-2">higher conversion with optimized performance</p>
              </div>
              <div className="bg-white p-4 md:p-6">
                <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>15-25%</p>
                <p className="text-gray-500 text-xs md:text-sm mt-2">annual compound improvement</p>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Gap Table */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-4 md:mb-6">The Performance Gap</h3>
          <div className="bg-white overflow-x-auto">
            <div className="min-w-[500px]">
              <div className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Metric</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Standard Websites</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider">Optimized Infrastructure</p>
                </div>
              </div>
              {performanceGap.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-sm md:text-base">{row.metric}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-sm md:text-base">{row.standard}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] font-bold text-sm md:text-base">{row.optimized}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Why Optimization Fails */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Why Optimization Fails</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {problems.map((problem, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-black font-bold mb-2 md:mb-3 text-sm md:text-base">{problem.title}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{problem.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Callout */}
        <div className="bg-black p-6 md:p-10">
          <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
            The Cost of Static Websites
          </p>
          <p className="text-white text-sm md:text-lg leading-relaxed mb-4 md:mb-6">
            Organizations with static websites watch competitors compound 15-25% annual conversion improvements while their performance remains flat or declines. Over 24 months, this creates 30-50% conversion rate gaps—mathematically equivalent to competitors operating with 30-50% lower customer acquisition costs.
          </p>
          <p className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
            Static websites depreciate. Optimization infrastructure appreciates.
          </p>
        </div>
      </div>
    </section>
  );
}
