import Button from "@/components/ui/Button";

export default function HeroSection() {
  const outcomes = [
    { stat: "45-120%", label: "conversion rate improvements in first 12 months" },
    { stat: "67%", label: "increase in high-value keyword positions through technical SEO" },
    { stat: "40-80%", label: "organic traffic growth sustained over 24 months" },
    { stat: "<3s", label: "load times with 90+ Core Web Vitals scores" },
    { stat: "15-25%", label: "annual compound improvement through continuous testing" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Main Grid */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          {/* Left Content */}
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Web Development & Optimization
            </p>
            <h1
              className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] text-black leading-[1.1] mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Revenue Infrastructure That Compounds Performance Monthly
            </h1>
            <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6 md:mb-8">
              Enterprise websites are not marketing assets—they are revenue infrastructure. Organizations treating websites as design projects face systematic disadvantages against competitors deploying optimization engines that compound improvements continuously.
            </p>
            <p className="text-sm md:text-base text-gray-500 leading-relaxed mb-8 md:mb-10">
              The gap separating high-performing websites from average sites is not creative execution—it is systematic optimization infrastructure enabling measurable competitive advantages.
            </p>
            <Button href="/company/contact" variant="primary">
              Assess Your Website Infrastructure
            </Button>
          </div>

          {/* Right - The Gap */}
          <div className="lg:col-span-4 bg-black p-6 md:p-8 flex flex-col justify-between min-h-[200px]">
            <div>
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">The Gap</p>
              <p className="text-4xl sm:text-5xl md:text-6xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>15-25%</p>
              <p className="text-white mt-2 text-sm md:text-base">annual compound improvement</p>
            </div>
            <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-gray-800">
              <p className="text-gray-500 text-xs md:text-sm">
                Static websites depreciate. Optimization infrastructure appreciates.
              </p>
            </div>
          </div>
        </div>

        {/* Intro Text */}
        <div className="mb-6 md:mb-10">
          <p className="text-sm md:text-base text-gray-600">
            Organizations with systematic optimization infrastructure deliver measurable results:
          </p>
        </div>

        {/* Outcomes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px bg-gray-200">
          {outcomes.map((item, index) => (
            <div key={index} className={`bg-white p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
              <p className="text-2xl md:text-3xl text-black mb-2" style={{ fontWeight: 1000 }}>
                {item.stat}
              </p>
              <p className="text-gray-500 text-xs md:text-sm">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Bottom Statement */}
        <div className="mt-8 md:mt-10 pt-8 md:pt-10 border-t border-gray-200">
          <p className="text-base md:text-lg text-black" style={{ fontWeight: 1000 }}>
            Empire325 builds website infrastructure that operates as conversion optimization systems, not static deliverables.
          </p>
        </div>
      </div>
    </section>
  );
}
