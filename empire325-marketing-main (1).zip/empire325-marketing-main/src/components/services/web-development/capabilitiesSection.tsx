export default function CapabilitiesSection() {
  const platforms = [
    {
      title: "Custom WordPress / Headless CMS",
      items: [
        "Content velocity for marketing teams requiring frequent publishing",
        "Custom post types, taxonomies, and workflows",
        "Enterprise security hardening and performance optimization",
        "Multi-site architecture for global organizations",
      ],
    },
    {
      title: "React / Next.js Applications",
      items: [
        "High-performance web applications with dynamic functionality",
        "Server-side rendering for SEO performance",
        "Progressive web app (PWA) capabilities",
        "Component-based architecture for maintainability",
      ],
    },
    {
      title: "E-Commerce Platforms",
      items: [
        "Shopify Plus, WooCommerce, custom solutions",
        "Conversion-optimized checkout flows",
        "Product catalog management at scale",
        "Payment gateway and shipping integration",
      ],
    },
  ];

  const enterpriseOutcomes = [
    "Sub-3-second load times with 90+ Core Web Vitals scores",
    "100K+ monthly visitors supported without performance degradation",
    "Enterprise-grade security with SSL, DDoS protection, regular updates",
    "Content velocity enabling marketing team publishing without developer dependency",
  ];

  const homepageOptimization = [
    "Headline and value proposition testing",
    "Hero section layout variations",
    "CTA button design and placement",
    "Social proof element testing",
  ];

  const landingPageTesting = [
    "Form length and field requirements",
    "Copy length and messaging approach",
    "Visual vs. text-heavy layouts",
    "Trust signals and credibility elements",
  ];

  const productPageOptimization = [
    "Product description format and length",
    "Image gallery layout and functionality",
    "Add to cart button design and placement",
    "Review display and filtering options",
  ];

  const checkoutFlowTesting = [
    "Single-page vs. multi-step checkout",
    "Guest checkout vs. account creation",
    "Payment method options and order",
    "Security badge placement and messaging",
  ];

  const testingVelocity = [
    "4-8 experiments monthly across critical conversion paths",
    "95% statistical confidence required before declaring winners",
    "Minimum 2-week test duration ensuring full business cycle representation",
    "Holdout validation preventing false positives from random variation",
    "Test isolation ensuring clean measurement without interference",
  ];

  const improvementTimeline = [
    { timeframe: "Months 1-6", improvement: "20-40%", activity: "High-impact wins, low-hanging fruit" },
    { timeframe: "Months 6-12", improvement: "45-80%", activity: "Compound improvements, refinement" },
    { timeframe: "Months 12-24", improvement: "85-120%", activity: "Continuous optimization, innovation" },
  ];

  const technicalInfrastructure = [
    "Comprehensive site audit identifying crawl errors, duplicate content, broken links",
    "XML sitemap optimization and robots.txt configuration",
    "Canonical tag implementation preventing duplicate content issues",
    "301 redirect strategy for URL migrations",
    "HTTPS implementation and security best practices",
  ];

  const schemaMarkup = [
    "Product schema for e-commerce (price, availability, reviews)",
    "Organization schema establishing brand entity",
    "FAQ schema capturing featured snippets",
    "Review schema displaying star ratings in SERPs",
    "Breadcrumb schema improving navigation",
  ];

  const contentOptimization = [
    "Keyword research identifying high-value opportunities",
    "On-page optimization (title tags, meta descriptions, headers)",
    "Internal linking strategy distributing authority",
    "Content gap analysis identifying competitor advantages",
    "Content refresh strategy updating underperforming pages",
  ];

  const performanceMonitoring = [
    "Keyword ranking tracking across target terms",
    "Organic traffic monitoring and trend analysis",
    "Search Console monitoring for crawl errors and issues",
    "Competitor tracking identifying opportunity gaps",
    "Monthly optimization recommendations based on performance data",
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-20">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-white leading-tight max-w-3xl"
            style={{ fontWeight: 1000 }}
          >
            Enterprise Web Infrastructure
          </h2>
        </div>

        {/* Capability 1: Enterprise Website Development */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">01</span>
            <h3 className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Enterprise Website Development
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            High-performance website architecture supporting enterprise requirements: scalability, security, content velocity, and conversion optimization.
          </p>

          <p className="text-white font-bold mb-4 md:mb-6 text-sm md:text-base">Platform Expertise:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8 md:mb-10">
            {platforms.map((platform, index) => (
              <div key={index} className="border-l-2 border-gray-800 pl-4 md:pl-6 hover:border-[#0dc2cc] transition-colors">
                <p className="text-white font-bold mb-3 md:mb-4 text-sm md:text-base">{platform.title}</p>
                <ul className="space-y-2">
                  {platform.items.map((item, idx) => (
                    <li key={idx} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                      <span className="text-[#0dc2cc]">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="bg-gray-900/50 p-4 md:p-8">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
              Enterprise Website Outcomes
            </p>
            <ul className="grid sm:grid-cols-2 gap-2 md:gap-3">
              {enterpriseOutcomes.map((item, index) => (
                <li key={index} className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Capability 2: Conversion Rate Optimization */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">02</span>
            <h3 className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Conversion Rate Optimization
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Systematic testing framework compounding performance through disciplined experimentation across critical conversion paths.
          </p>

          <p className="text-white font-bold mb-4 md:mb-6 text-sm md:text-base">Testing Methodology:</p>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Homepage Optimization</p>
              <ul className="space-y-2">
                {homepageOptimization.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Landing Page Testing</p>
              <ul className="space-y-2">
                {landingPageTesting.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Product Page Optimization</p>
              <ul className="space-y-2">
                {productPageOptimization.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Checkout Flow Testing</p>
              <ul className="space-y-2">
                {checkoutFlowTesting.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-8 md:mb-10">
            <p className="text-white font-bold mb-3 md:mb-4 text-sm md:text-base">Testing Velocity & Statistical Rigor:</p>
            <ul className="space-y-2">
              {testingVelocity.map((item, index) => (
                <li key={index} className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Improvement Timeline Table */}
          <div className="overflow-x-auto">
            <div className="min-w-[400px]">
              <div className="grid grid-cols-3 gap-px bg-gray-800">
                <div className="bg-gray-900 p-3 md:p-4">
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">Timeframe</p>
                </div>
                <div className="bg-gray-900 p-3 md:p-4">
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">Improvement Range</p>
                </div>
                <div className="bg-gray-900 p-3 md:p-4">
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">Testing Activity</p>
                </div>
                {improvementTimeline.map((row, index) => (
                  <div key={index} className="col-span-3 grid grid-cols-3 gap-px bg-gray-800">
                    <div className="bg-black p-3 md:p-4">
                      <p className="text-white font-bold text-xs md:text-sm">{row.timeframe}</p>
                    </div>
                    <div className="bg-black p-3 md:p-4">
                      <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.improvement}</p>
                    </div>
                    <div className="bg-black p-3 md:p-4">
                      <p className="text-gray-500 text-xs md:text-sm">{row.activity}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Capability 3: Technical SEO & Organic Growth */}
        <div>
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">03</span>
            <h3 className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
              Technical SEO & Organic Growth
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-800" />
          </div>

          <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Systematic technical SEO infrastructure building sustainable organic visibility through excellence in crawlability, indexation, and on-page optimization.
          </p>

          <p className="text-white font-bold mb-4 md:mb-6 text-sm md:text-base">SEO Foundation:</p>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Technical Infrastructure:</p>
              <ul className="space-y-2">
                {technicalInfrastructure.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Schema Markup & Rich Results:</p>
              <ul className="space-y-2">
                {schemaMarkup.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Content Optimization:</p>
              <ul className="space-y-2">
                {contentOptimization.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Performance Monitoring:</p>
              <ul className="space-y-2">
                {performanceMonitoring.map((item, index) => (
                  <li key={index} className="text-gray-500 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-gray-700">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-900/50 p-4 md:p-8">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
              SEO Performance Outcomes
            </p>
            <ul className="space-y-2">
              <li className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                <span className="text-[#0dc2cc]">•</span>
                67% increase in high-value keyword positions within 12 months
              </li>
              <li className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                <span className="text-[#0dc2cc]">•</span>
                40-80% organic traffic growth sustained over 24 months
              </li>
              <li className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                <span className="text-[#0dc2cc]">•</span>
                Featured snippet capture for priority keywords through schema optimization
              </li>
              <li className="text-gray-400 text-xs md:text-sm flex items-start gap-2">
                <span className="text-[#0dc2cc]">•</span>
                Organic channel becomes 40-60% of qualified lead generation
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
