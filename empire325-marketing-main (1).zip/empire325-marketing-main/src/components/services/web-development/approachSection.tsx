export default function ApproachSection() {
  const coreWebVitals = [
    { metric: "LCP (Largest Contentful Paint)", target: "<2.5s" },
    { metric: "FID (First Input Delay)", target: "<100ms" },
    { metric: "CLS (Cumulative Layout Shift)", target: "<0.1" },
  ];

  const infrastructure = [
    "CDN for global performance",
    "Image optimization & lazy loading",
    "Minification & compression",
  ];

  const mobileFirst = [
    "Responsive architecture optimized for mobile",
    "Touch-optimized interface elements",
    "60-70% traffic from mobile devices",
  ];

  const scalability = [
    "Support 100K+ monthly visitors",
    "No performance degradation with growth",
    "Auto-scaling infrastructure",
  ];

  const behavioralAnalytics = [
    "Session recording identifying user friction points",
    "Heatmapping showing engagement patterns",
    "User testing validating assumptions",
    "Form analytics identifying abandonment points",
  ];

  const abTesting = [
    "Statistical significance requirements (95% confidence)",
    "Proper sample sizing calculations",
    "Holdout validation preventing false positives",
    "Test isolation ensuring clean measurement",
  ];

  const multivariate = [
    "Complex optimization testing multiple variables",
    "Interaction effects identification",
    "Compound impact measurement",
  ];

  const seoTable = [
    { component: "Schema Markup", implementation: "Structured data for rich results (reviews, products, FAQs, events)", impact: "Increased SERP real estate & click-through rates" },
    { component: "Technical Audit", implementation: "Crawl analysis, duplicate content, broken links, redirect chains", impact: "Indexation efficiency, crawl budget optimization" },
    { component: "Site Architecture", implementation: "Logical hierarchy, internal linking, XML sitemaps", impact: "Crawlability, user navigation, authority flow" },
    { component: "Content Optimization", implementation: "Keyword integration, readability, structural best practices", impact: "Ranking improvements, featured snippet capture" },
    { component: "Performance Monitoring", implementation: "Continuous tracking, monthly optimization recommendations", impact: "Sustained growth, competitive position maintenance" },
  ];

  const integrationCapabilities = [
    {
      title: "Marketing Automation Integration",
      items: [
        "Form submissions routing to nurture sequences",
        "Behavioral triggers initiating email campaigns",
        "Lead scoring based on website engagement",
      ],
    },
    {
      title: "CRM Integration",
      items: [
        "Closed-loop revenue attribution from first touch to closed deal",
        "Pipeline tracking connecting website visitors to revenue outcomes",
        "Account-based marketing visitor identification",
      ],
    },
    {
      title: "Analytics Integration",
      items: [
        "Custom event tracking beyond pageviews",
        "Video engagement, scroll depth, feature interactions",
        "Content consumption patterns informing AI models",
      ],
    },
    {
      title: "AI & Personalization",
      items: [
        "Dynamic content based on visitor behavior and predicted intent",
        "Predictive lead scoring driving prioritization",
        "Chatbot deployment for qualification and conversion",
      ],
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Our Approach
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6 max-w-4xl"
            style={{ fontWeight: 1000 }}
          >
            Empire325 website infrastructure rests on four foundational capabilities that separate optimization systems from static deliverables
          </h2>
        </div>

        {/* Capability I - Performance-First Architecture */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">I</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Performance-First Architecture
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Website performance determines conversion rates, search rankings, and user experience. Every architectural decision prioritizes speed, reliability, and scalability over aesthetic complexity.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Technical Specifications:</p>

          <div className="grid md:grid-cols-2 gap-8 md:gap-12 mb-8 md:mb-10">
            {/* Left - Core Web Vitals & Infrastructure */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Core Web Vitals Optimization</p>
                <div className="space-y-2 md:space-y-3">
                  {coreWebVitals.map((item, index) => (
                    <div key={index} className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-600 text-xs md:text-sm">{item.metric}</span>
                      <span className="text-black font-bold text-xs md:text-sm">{item.target}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Infrastructure</p>
                <ul className="space-y-2">
                  {infrastructure.map((item, index) => (
                    <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                      <span className="text-[#0dc2cc]">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right - Mobile-First & Scalability */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Mobile-First Design</p>
                <ul className="space-y-2">
                  {mobileFirst.map((item, index) => (
                    <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                      <span className="text-[#0dc2cc]">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Scalability</p>
                <ul className="space-y-2">
                  {scalability.map((item, index) => (
                    <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                      <span className="text-[#0dc2cc]">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-2">Result</p>
            <p className="text-black leading-relaxed text-sm md:text-base">
              Sub-3-second load times achieving 90+ Core Web Vitals scores as standard, not aspiration. 40-80% organic traffic growth and 25-40% bounce rate reduction through performance improvements alone.
            </p>
          </div>
        </div>

        {/* Capability II - Systematic Testing Framework */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">II</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Systematic Testing Framework
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            High-performing websites improve through continuous experimentation, not opinions. We establish testing infrastructure deploying 4-8 experiments monthly across critical conversion paths.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Testing Infrastructure:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-10">
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Behavioral Analytics:</p>
              <ul className="space-y-2">
                {behavioralAnalytics.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">A/B Testing Discipline:</p>
              <ul className="space-y-2">
                {abTesting.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="sm:col-span-2 lg:col-span-1">
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Multivariate Testing:</p>
              <ul className="space-y-2">
                {multivariate.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Comparison */}
          <div className="grid sm:grid-cols-2 gap-px bg-gray-200 mb-8 md:mb-10">
            <div className="bg-white p-4 md:p-6">
              <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Opinion-Based Decisions</p>
              <p className="text-gray-600 text-xs md:text-sm">0-2 tests per year</p>
              <p className="text-gray-600 text-xs md:text-sm">No statistical validation</p>
              <p className="text-gray-600 text-xs md:text-sm">HiPPO-driven changes</p>
            </div>
            <div className="bg-gray-50 p-4 md:p-6">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Systematic Testing</p>
              <p className="text-black text-xs md:text-sm font-bold">4-8 tests per month</p>
              <p className="text-black text-xs md:text-sm font-bold">95% statistical confidence</p>
              <p className="text-black text-xs md:text-sm font-bold">Data-driven optimization</p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-2">Result</p>
            <p className="text-black leading-relaxed text-sm md:text-base">
              45-120% conversion rate improvements first 12 months through systematic testing. 15-25% annual compound improvement as optimization infrastructure matures.
            </p>
          </div>
        </div>

        {/* Capability III - Technical SEO Excellence */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">III</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Technical SEO Excellence
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Organic search drives 40-60% of high-value traffic for most enterprises. We architect technical SEO foundations, content optimization frameworks, and ongoing improvement systems building sustainable search advantage.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">SEO Infrastructure:</p>

          {/* SEO Table */}
          <div className="mb-8 md:mb-10 overflow-x-auto">
            <div className="min-w-[600px]">
              <div className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Component</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Implementation</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Impact</p>
                </div>
              </div>
              {seoTable.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-xs md:text-sm">{row.component}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.implementation}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] text-xs md:text-sm">{row.impact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-2">Result</p>
            <p className="text-black leading-relaxed text-sm md:text-base">
              67% increase in high-value keyword positions. 40-80% organic traffic growth sustained over 24 months through technical excellence and systematic optimization.
            </p>
          </div>
        </div>

        {/* Capability IV - Integration Architecture */}
        <div>
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">IV</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Integration Architecture
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Websites generate maximum value when integrated into broader marketing infrastructure—connected to CRM, marketing automation, analytics, and AI systems enabling revenue-based optimization.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Integration Capabilities:</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            {integrationCapabilities.map((cap, index) => (
              <div key={index} className="border-l-2 border-gray-200 pl-4 md:pl-6">
                <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">{cap.title}</p>
                <ul className="space-y-2">
                  {cap.items.map((item, idx) => (
                    <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                      <span className="text-[#0dc2cc]">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-2">Result</p>
            <p className="text-black leading-relaxed text-sm md:text-base">
              Websites operate within broader marketing systems enabling optimization based on revenue outcomes, not traffic metrics. Marketing ROI visibility from first touch to closed deal.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
