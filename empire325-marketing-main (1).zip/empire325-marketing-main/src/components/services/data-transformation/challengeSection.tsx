export default function ChallengeSection() {
  const fragmentationTable = [
    { type: "CRM Systems", silos: "Salesforce, HubSpot, Microsoft Dynamics—each maintaining separate customer records", impact: "No unified customer view, conflicting pipeline forecasts" },
    { type: "Marketing Platforms", silos: "Google Analytics, Adobe, Marketo—disconnected campaign performance", impact: "Cannot prove marketing's revenue contribution" },
    { type: "ERP Systems", silos: "SAP, Oracle, NetSuite—financial data isolated from operations", impact: "Profitability analysis requires weeks of manual work" },
    { type: "Product Analytics", silos: "Mixpanel, Amplitude, Segment—usage data disconnected from revenue", impact: "Cannot connect product engagement to customer value" },
    { type: "Legacy Systems", silos: "On-premises databases, custom applications—decades of critical data", impact: "Historical insights inaccessible for analysis" },
  ];

  const problems = [
    {
      title: "Point-to-Point Integration Complexity",
      desc: "Organizations attempt direct connections between systems (CRM → Marketing Automation, ERP → Analytics). Each integration requires custom development, maintenance, and troubleshooting. With N systems, N(N-1)/2 integrations are theoretically required. Technical debt accumulates. Breaking changes in one system cascade throughout infrastructure.",
    },
    {
      title: "Manual Data Movement",
      desc: "Analysts download CSV exports, manipulate in spreadsheets, upload to other systems. Data staleness prevents real-time decision-making. Human error introduces quality issues. Process knowledge resides with individuals rather than documented infrastructure. When key personnel depart, institutional knowledge disappears.",
    },
    {
      title: "Governance Gaps",
      desc: "No authoritative definitions exist for key metrics. Different teams calculate identical metrics differently. Reporting produces conflicting numbers. Executives receive multiple versions of truth. Decision-making stalls as stakeholders debate data accuracy rather than strategic direction.",
    },
    {
      title: "Security and Compliance Risk",
      desc: "Sensitive data copies proliferate across systems and individual workstations. Audit trails are incomplete or nonexistent. Access controls are inconsistent. Compliance requirements (GDPR, SOC2, HIPAA) cannot be reliably demonstrated. Board-level risk exposure from data governance failures.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            The Challenge
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
            style={{ fontWeight: 1000 }}
          >
            The Data Infrastructure Crisis
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-4xl">
            Enterprise data exists in fragmented systems generating conflicting insights, preventing unified decision-making. Organizations invest extensively in data generation—CRM systems, marketing automation, ERP platforms, analytics tools—yet lack infrastructure enabling reliable access to accurate information where business decisions occur.
          </p>
        </div>

        {/* Fragmentation Table */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-4 md:mb-6">The Fragmentation Problem</h3>
          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-300">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">System Type</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Data Silos</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Business Impact</p>
                </div>
              </div>
              {fragmentationTable.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-300">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-xs md:text-sm">{row.type}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.silos}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] text-xs md:text-sm font-bold">{row.impact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Why Integration Fails */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Why Integration Fails</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {problems.map((problem, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-black font-bold mb-2 md:mb-3 text-sm md:text-base">{problem.title}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{problem.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Callout */}
        <div className="bg-black p-6 md:p-10">
          <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
            The Cost of Data Fragmentation
          </p>
          <p className="text-white text-sm md:text-lg leading-relaxed mb-4 md:mb-6">
            Enterprises with fragmented data infrastructure operate at systematic disadvantages: 15-20 hours weekly per analyst on manual reporting, 2-4 week reporting cycles preventing timely optimization, 30-40% of executive time spent reconciling conflicting reports rather than strategic planning, competitive paralysis as data-driven competitors execute faster decisions.
          </p>
          <p className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
            Organizations cannot optimize what they cannot measure reliably and quickly.
          </p>
        </div>
      </div>
    </section>
  );
}
