export default function MeasurementSection() {
  const measurementFramework = [
    {
      category: "Decision Velocity",
      metrics: ["Time from question to answer", "Reporting cycle time", "Ad-hoc analysis turnaround"],
      target: "70-85% reduction in reporting cycles",
    },
    {
      category: "Data Quality",
      metrics: ["Data accuracy scores", "Completeness metrics", "Consistency across systems"],
      target: "60-75% improvement through governance and lineage",
    },
    {
      category: "Operational Efficiency",
      metrics: ["Analyst time on manual tasks", "Data preparation hours", "Report reconciliation time"],
      target: "85-95% reduction in manual data preparation",
    },
    {
      category: "Infrastructure Reliability",
      metrics: ["Pipeline uptime", "Data freshness SLAs", "Error rates and recovery time"],
      target: "99.5%+ availability with automated recovery",
    },
    {
      category: "Business Impact",
      metrics: ["Revenue attribution accuracy", "Cost reduction from automation", "Decision quality improvements"],
      target: "Measurable ROI within 6-12 months",
    },
  ];

  const reportingCadence = [
    { frequency: "Weekly", activities: "Pipeline health monitoring, data quality metrics, issue resolution tracking" },
    { frequency: "Monthly", activities: "Usage analytics, performance optimization, governance compliance review" },
    { frequency: "Quarterly", activities: "Business impact assessment, roadmap review, strategic planning alignment" },
    { frequency: "Annual", activities: "Infrastructure maturity assessment, ROI analysis, multi-year roadmap development" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Measurement Framework
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Business Impact Metrics
            </h2>
          </div>
          <div className="lg:col-span-4 flex items-end">
            <p className="text-sm md:text-base text-gray-600">
              We measure data infrastructure success through business impact metrics that connect technical performance to organizational decision-making capability.
            </p>
          </div>
        </div>

        {/* Metrics Table */}
        <div className="mb-12 md:mb-16 overflow-x-auto">
          <div className="min-w-[600px]">
            <div className="grid grid-cols-3 gap-px bg-gray-200">
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Category</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Primary Metrics</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Target Performance</p>
              </div>
            </div>
            {measurementFramework.map((row, index) => (
              <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-white p-3 md:p-4">
                  <p className="text-black font-bold text-xs md:text-sm">{row.category}</p>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <ul className="space-y-1">
                    {row.metrics.map((metric, idx) => (
                      <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                        <span className="text-[#0dc2cc]">•</span>
                        {metric}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.target}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Metrics Visual */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200 mb-12 md:mb-16">
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>70-85%</p>
            <p className="text-gray-500 text-xs md:text-sm">faster reporting cycles</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">weeks to hours</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>60-75%</p>
            <p className="text-gray-500 text-xs md:text-sm">data quality improvement</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">governance & lineage</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>85-95%</p>
            <p className="text-gray-500 text-xs md:text-sm">cost reduction</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">manual data preparation</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>Single</p>
            <p className="text-gray-500 text-xs md:text-sm">source of truth</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">eliminating conflicts</p>
          </div>
        </div>

        {/* Reporting Cadence */}
        <div>
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Reporting Cadence</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {reportingCadence.map((item, index) => (
              <div key={index} className="border-t-2 border-gray-200 pt-4 md:pt-6">
                <p className="text-[#0dc2cc] font-bold mb-2 text-sm md:text-base">{item.frequency}</p>
                <p className="text-gray-600 text-xs md:text-sm">{item.activities}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
