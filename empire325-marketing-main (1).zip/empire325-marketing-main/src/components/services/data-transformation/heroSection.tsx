import Button from "@/components/ui/Button";

export default function HeroSection() {
  const outcomes = [
    { stat: "70-85%", label: "reduction in reporting cycle time from weeks to hours" },
    { stat: "60-75%", label: "improvement in data quality through governance and lineage" },
    { stat: "40-60%", label: "faster decision cycles through real-time data availability" },
    { stat: "85-95%", label: "cost reduction in manual data preparation activities" },
    { stat: "Single", label: "source of truth eliminating conflicting reports and organizational confusion" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Main Grid */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          {/* Left Content */}
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Data Transformation
            </p>
            <h1
              className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] text-black leading-[1.1] mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Enterprise Data Infrastructure Enabling Decision Intelligence at Scale
            </h1>
            <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6 md:mb-8">
              Enterprise data infrastructure determines organizational capability to make informed decisions, optimize operations, and deploy advanced analytics at scale. Organizations with unified data architecture operating as single source of truth achieve measurably superior business outcomes compared to competitors managing fragmented systems generating siloed insights.
            </p>
            <p className="text-sm md:text-base text-gray-500 leading-relaxed mb-8 md:mb-10">
              The competitive separation occurs not through data volume—organizations possess equivalent information—but through data infrastructure enabling reliable, timely access to accurate insights where decisions are made.
            </p>
            <Button href="/company/contact" variant="primary">
              Assess Your Data Infrastructure
            </Button>
          </div>

          {/* Right - The Gap */}
          <div className="lg:col-span-4 bg-black p-6 md:p-8 flex flex-col justify-between min-h-[200px]">
            <div>
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">The Advantage</p>
              <p className="text-4xl sm:text-5xl md:text-6xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>70-85%</p>
              <p className="text-white mt-2 text-sm md:text-base">faster reporting cycles</p>
            </div>
            <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-gray-800">
              <p className="text-gray-500 text-xs md:text-sm">
                Single source of truth eliminating conflicting reports.
              </p>
            </div>
          </div>
        </div>

        {/* Intro Text */}
        <div className="mb-6 md:mb-10">
          <p className="text-sm md:text-base text-gray-600">
            Organizations with production-grade data infrastructure deliver measurable advantages:
          </p>
        </div>

        {/* Outcomes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px bg-gray-200">
          {outcomes.map((item, index) => (
            <div key={index} className={`bg-white p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
              <p className="text-2xl md:text-3xl text-black mb-2" style={{ fontWeight: 1000 }}>
                {item.stat}
              </p>
              <p className="text-gray-500 text-xs md:text-sm">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Bottom Statement */}
        <div className="mt-8 md:mt-10 pt-8 md:pt-10 border-t border-gray-200">
          <p className="text-base md:text-lg text-black" style={{ fontWeight: 1000 }}>
            Empire325 builds enterprise data infrastructure operating reliably in production—not proof-of-concept demonstrations requiring ongoing engineering support.
          </p>
        </div>
      </div>
    </section>
  );
}
