export default function ApproachSection() {
  const enterpriseDataArch = [
    "Data fabric architecture enabling unified access",
    "Data mesh implementation for domain ownership",
    "Cloud-native platform design",
    "Future-state architecture roadmaps",
  ];

  const cloudDataPlatform = [
    "Snowflake, Databricks, BigQuery platform selection",
    "Multi-cloud and hybrid architecture",
    "Cost optimization strategies",
    "Performance tuning and scaling",
  ];

  const dataWarehouse = [
    "Modern data warehouse implementation",
    "Data lake architecture for unstructured data",
    "Lakehouse combining warehouse and lake benefits",
    "Data modeling for analytics and AI",
  ];

  const platformModernization = [
    "On-premises to cloud data migration",
    "Legacy system modernization",
    "Zero-downtime migration strategies",
    "Data validation and reconciliation",
  ];

  const dataIngestion = [
    "Automated extraction from CRM, ERP, marketing, and operational systems",
    "API integration for cloud platforms (Salesforce, HubSpot, Google)",
    "Database replication for legacy systems",
    "File-based ingestion from on-premises applications",
  ];

  const etlElt = [
    "Modern ELT patterns leveraging cloud data warehouse compute",
    "Data transformation using dbt, SQL, Python",
    "Business logic implementation in transformation layer",
    "Version control and testing for data transformations",
  ];

  const realTimeBatch = [
    "Streaming data pipelines for real-time analytics",
    "Batch processing for historical data loads",
    "Change data capture (CDC) for incremental updates",
    "Event-driven architecture for data propagation",
  ];

  const masterData = [
    "Customer master data across CRM, marketing, support systems",
    "Product master data linking SKUs, variants, hierarchies",
    "Entity resolution and deduplication",
    "Golden record creation for single source of truth",
  ];

  const integrationOutcomes = [
    "Single source of truth eliminating conflicting reports across organization",
    "Real-time data availability enabling immediate decision-making vs. weekly/monthly delays",
    "85-95% reduction in manual data preparation and movement",
    "Production-grade reliability with monitoring, alerting, and automated recovery",
  ];

  const governanceTable = [
    { capability: "Data Governance", implementation: "Policy-driven governance framework, data ownership models, data stewardship programs", value: "Board-level confidence in data reliability and compliance" },
    { capability: "Data Quality Management", implementation: "Automated quality checks, anomaly detection, data profiling, remediation workflows", value: "60-75% improvement in data accuracy and completeness" },
    { capability: "Metadata Management", implementation: "Business glossary, technical metadata, operational metadata, data catalogs", value: "Self-service data discovery reducing analyst time to find data" },
    { capability: "Data Lineage", implementation: "End-to-end lineage from source to report, impact analysis, dependency mapping", value: "Rapid root cause analysis, change impact assessment" },
    { capability: "Master Data Controls", implementation: "Reference data management, data standardization, entity resolution", value: "Consistent definitions across organization eliminating confusion" },
  ];

  const biArchitecture = [
    "Tableau, Power BI, Looker platform implementation",
    "Semantic layer for consistent metric definitions",
    "Interactive dashboards for operational and executive audiences",
    "Mobile-optimized for executive access",
  ];

  const executiveReporting = [
    "Board-level reporting with strategic KPIs",
    "Operational dashboards for daily decision-making",
    "Automated report distribution and scheduling",
    "Alerting on critical metrics and anomalies",
  ];

  const selfServiceAnalytics = [
    "Ad-hoc analysis capabilities for business users",
    "Governed data access with security and privacy controls",
    "Training and enablement programs",
    "Data literacy development across organization",
  ];

  const kpiMetrics = [
    "Business metric definitions and calculations",
    "Performance management frameworks",
    "Metric ownership and accountability",
    "OKR and scorecard implementation",
  ];

  const predictiveAnalytics = [
    "Revenue forecasting with confidence intervals",
    "Customer churn prediction and prevention",
    "Demand forecasting for inventory optimization",
    "Scenario modeling and what-if analysis",
  ];

  const mlPipelines = [
    "Feature engineering from raw data sources",
    "Model training and hyperparameter optimization",
    "Model deployment to production environments",
    "A/B testing frameworks for model performance",
  ];

  const aiReadiness = [
    "Data quality assessment for AI workloads",
    "Feature store implementation",
    "Training data management and versioning",
    "Model explainability and interpretability",
  ];

  const mlOps = [
    "Automated model retraining pipelines",
    "Performance monitoring and drift detection",
    "Model versioning and rollback capabilities",
    "Production incident management",
  ];

  const dataSecurityArch = [
    "Encryption at rest and in transit",
    "Network security and isolation",
    "Threat detection and response",
    "Vulnerability management",
  ];

  const dataAccessControls = [
    "Role-based access control (RBAC)",
    "Attribute-based access control (ABAC)",
    "Row and column level security",
    "Multi-factor authentication",
  ];

  const privacyCompliance = [
    "GDPR compliance implementation",
    "SOC2 audit readiness",
    "HIPAA controls for healthcare data",
    "PCI-DSS for payment data",
  ];

  const dataProtection = [
    "Data masking for sensitive information",
    "Tokenization for PII protection",
    "Data retention and deletion policies",
    "Audit trail and compliance reporting",
  ];

  const dataOpsImplementation = [
    "CI/CD pipelines for data infrastructure code",
    "Automated testing for data quality and transformations",
    "Version control for data assets and pipelines",
    "Environment management (dev, staging, production)",
  ];

  const pipelineMonitoring = [
    "Real-time pipeline health monitoring",
    "Automated alerting on failures and anomalies",
    "Data freshness SLAs and monitoring",
    "Automated retry and recovery mechanisms",
  ];

  const costOptimization = [
    "Cloud data platform cost monitoring and optimization",
    "Compute resource right-sizing and auto-scaling",
    "Query performance optimization reducing costs",
    "Storage optimization and lifecycle management",
  ];

  const incidentManagement = [
    "On-call rotation and escalation procedures",
    "Root cause analysis and remediation",
    "Post-incident reviews and process improvement",
    "Disaster recovery and business continuity planning",
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Our Approach
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6 max-w-4xl"
            style={{ fontWeight: 1000 }}
          >
            Empire325 data transformation delivers production-grade infrastructure operating reliably at enterprise scale—not proof-of-concept demonstrations
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-3xl">
            Our approach spans complete data lifecycle from ingestion through governance to analytics enablement.
          </p>
        </div>

        {/* Capability I - Data Architecture & Platform Engineering */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">I</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Data Architecture & Platform Engineering
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Modern data architecture enables scalable, reliable infrastructure supporting analytics, AI, and operational decision-making at enterprise scale.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Foundation Services:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Enterprise Data Architecture</p>
              <ul className="space-y-2">
                {enterpriseDataArch.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Cloud Data Platform Design</p>
              <ul className="space-y-2">
                {cloudDataPlatform.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Data Warehouse / Lake / Lakehouse</p>
              <ul className="space-y-2">
                {dataWarehouse.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Platform Modernization</p>
              <ul className="space-y-2">
                {platformModernization.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Capability II - Data Engineering & Integration */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">II</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Data Engineering & Integration
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Reliable data pipelines connecting fragmented systems into unified infrastructure, operating with production-grade reliability and monitoring.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Integration Services:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Data Ingestion Pipelines:</p>
              <ul className="space-y-2">
                {dataIngestion.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">ETL / ELT Development:</p>
              <ul className="space-y-2">
                {etlElt.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Real-Time & Batch Processing:</p>
              <ul className="space-y-2">
                {realTimeBatch.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Master Data Management:</p>
              <ul className="space-y-2">
                {masterData.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
              Integration Outcomes
            </p>
            <ul className="space-y-2">
              {integrationOutcomes.map((item, index) => (
                <li key={index} className="text-gray-700 text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Capability III - Data Management & Governance */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">III</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Data Management & Governance
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Enterprise data governance ensures data quality, compliance, and trustworthiness required for board-level confidence in data-driven decisions.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Governance Framework:</p>

          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Capability</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Implementation</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Business Value</p>
                </div>
              </div>
              {governanceTable.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-xs md:text-sm">{row.capability}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.implementation}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] text-xs md:text-sm">{row.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Capability IV - Business Intelligence & Analytics */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">IV</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Business Intelligence & Analytics
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Self-service analytics infrastructure enabling decision-makers to access insights without engineering dependencies, while maintaining governance and data quality.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Analytics Enablement:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">BI Architecture & Dashboarding:</p>
              <ul className="space-y-2">
                {biArchitecture.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Executive & Operational Reporting:</p>
              <ul className="space-y-2">
                {executiveReporting.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Self-Service Analytics:</p>
              <ul className="space-y-2">
                {selfServiceAnalytics.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">KPI & Metrics Framework:</p>
              <ul className="space-y-2">
                {kpiMetrics.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Comparison */}
          <div className="grid sm:grid-cols-2 gap-px bg-gray-200">
            <div className="bg-white p-4 md:p-6">
              <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Manual Reporting</p>
              <p className="text-gray-600 text-xs md:text-sm">15-20 hours weekly per analyst</p>
              <p className="text-gray-600 text-xs md:text-sm">2-4 week reporting cycles</p>
              <p className="text-gray-600 text-xs md:text-sm">Data already stale when delivered</p>
            </div>
            <div className="bg-gray-50 p-4 md:p-6">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">Self-Service Analytics</p>
              <p className="text-black text-xs md:text-sm font-bold">Minutes to access insights</p>
              <p className="text-black text-xs md:text-sm font-bold">Real-time data availability</p>
              <p className="text-black text-xs md:text-sm font-bold">70-85% reporting time reduction</p>
            </div>
          </div>
        </div>

        {/* Capability V - Advanced Analytics & AI Enablement */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">V</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Advanced Analytics & AI Enablement
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Production-grade AI infrastructure enabling predictive analytics and machine learning deployed reliably at scale—not proof-of-concept demonstrations.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">AI Infrastructure:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Predictive Analytics & Forecasting:</p>
              <ul className="space-y-2">
                {predictiveAnalytics.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Machine Learning Pipelines:</p>
              <ul className="space-y-2">
                {mlPipelines.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">AI Readiness & Data Preparation:</p>
              <ul className="space-y-2">
                {aiReadiness.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">MLOps & Model Monitoring:</p>
              <ul className="space-y-2">
                {mlOps.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-black leading-relaxed text-sm md:text-base italic">
              Enterprises do not want AI demonstrations—they require AI surviving production deployment with reliability, monitoring, and business impact measurement.
            </p>
          </div>
        </div>

        {/* Capability VI - Data Security, Privacy & Compliance */}
        <div className="mb-16 md:mb-20">
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">VI</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Data Security, Privacy & Compliance
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Board-level data governance ensuring security, privacy, and regulatory compliance requirements across data infrastructure.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Security & Compliance Framework:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Data Security Architecture</p>
              <ul className="space-y-2">
                {dataSecurityArch.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Data Access Controls</p>
              <ul className="space-y-2">
                {dataAccessControls.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Privacy & Compliance</p>
              <ul className="space-y-2">
                {privacyCompliance.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-3 md:mb-4">Data Protection</p>
              <ul className="space-y-2">
                {dataProtection.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Capability VII - Data Operations (DataOps & MLOps) */}
        <div>
          <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">VII</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>
              Data Operations (DataOps & MLOps)
            </h3>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-8 md:mb-10 max-w-3xl">
            Operational excellence separating production-ready infrastructure from consultant recommendations—enabling reliable, monitored, and cost-optimized data platforms.
          </p>

          <p className="text-black font-bold mb-4 md:mb-6 text-sm md:text-base">Operational Framework:</p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 md:mb-10">
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">DataOps Implementation:</p>
              <ul className="space-y-2">
                {dataOpsImplementation.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Pipeline Monitoring & Reliability:</p>
              <ul className="space-y-2">
                {pipelineMonitoring.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Cost Optimization:</p>
              <ul className="space-y-2">
                {costOptimization.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-black font-bold mb-3 md:mb-4 text-sm md:text-base">Incident & Failure Management:</p>
              <ul className="space-y-2">
                {incidentManagement.map((item, index) => (
                  <li key={index} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-black p-4 md:p-6">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
              What Separates Us From Consultants
            </p>
            <p className="text-gray-400 leading-relaxed text-sm md:text-base mb-4">
              Consultants deliver recommendations. Empire325 delivers operational infrastructure. We build, deploy, monitor, optimize, and support data platforms operating reliably in production—not PowerPoint presentations requiring internal engineering teams to execute.
            </p>
            <p className="text-white text-lg md:text-xl" style={{ fontWeight: 1000 }}>
              Our engagements conclude with working systems, not architecture diagrams.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
