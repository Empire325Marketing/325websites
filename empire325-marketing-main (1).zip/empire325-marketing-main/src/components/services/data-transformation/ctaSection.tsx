import Button from "@/components/ui/Button";

export default function CTASection() {
  const timeline = [
    {
      phase: "Assessment & Strategy",
      duration: "Weeks 1-4",
      desc: "Comprehensive audit of existing data infrastructure including source systems, current integrations, data quality assessment, and stakeholder requirements. Prioritized roadmap development based on business impact and technical dependencies.",
    },
    {
      phase: "Foundation Build",
      duration: "Months 1-3",
      desc: "Core infrastructure deployment including data warehouse/lakehouse architecture, initial source integrations, governance framework establishment, and foundational data models for priority use cases.",
    },
    {
      phase: "Integration & Governance",
      duration: "Months 3-6",
      desc: "Systematic source system integration, data quality monitoring implementation, semantic layer deployment, and self-service analytics enablement for initial user groups.",
    },
    {
      phase: "Scale & Optimize",
      duration: "Months 6-12",
      desc: "Expanded source coverage, advanced analytics enablement, AI/ML infrastructure preparation, performance optimization, and organization-wide adoption support.",
    },
    {
      phase: "AI Enablement & Maturity",
      duration: "Months 12-18",
      desc: "Advanced AI/ML deployment, predictive analytics implementation, real-time decision support systems, and continuous improvement infrastructure ensuring sustained competitive advantage.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Getting Started
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Transformation Timeline
            </h2>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed">
              Data infrastructure transformation requires systematic investment over 12-18 months depending on current state complexity and organizational scope. Organizations beginning this work achieve measurable decision velocity improvements within first 90 days, with capabilities compounding as infrastructure matures.
            </p>
          </div>
          <div className="lg:col-span-4">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>12-18</p>
                <p className="text-gray-500 text-xs md:text-sm">months to transform</p>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>90</p>
                <p className="text-gray-500 text-xs md:text-sm">days to first results</p>
              </div>
            </div>
          </div>
        </div>

        {/* What To Expect */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-white font-bold mb-6 md:mb-8">What To Expect</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px bg-gray-800">
            {timeline.map((item, index) => (
              <div key={index} className={`bg-black p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
                <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                  <span
                    className="text-2xl md:text-3xl text-[#0dc2cc]"
                    style={{ fontWeight: 1000, opacity: 1 - index * 0.15 }}
                  >
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>
                <p className="text-white font-bold mb-1 text-sm md:text-base">{item.phase}</p>
                <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-2 md:mb-3">{item.duration}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Investment & CTA */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 pt-12 md:pt-16 border-t border-gray-800">
          <div className="lg:col-span-7">
            <h3 className="text-lg md:text-xl font-bold text-white mb-3 md:mb-4">
              Investment Considerations
            </h3>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              Data infrastructure investment spans initial architecture, integration development, governance implementation, and ongoing optimization. Investment varies based on source system complexity, data volume, and organizational scope. Organizations typically achieve positive ROI within 6-12 months through operational efficiency gains and improved decision quality.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              Fragmented data infrastructure accumulates technical debt as systems multiply and integration complexity compounds. Unified infrastructure appreciates through network effects as additional sources increase analytical value exponentially.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
              Our team is available to discuss data infrastructure assessment and transformation roadmap specific to your organization&apos;s current state and strategic objectives.
            </p>
            <div className="flex flex-col sm:flex-row flex-wrap gap-4">
              <Button href="/company/contact" variant="secondary">
                Schedule Data Infrastructure Assessment
              </Button>
              <a
                href="mailto:data@empire325marketing.com"
                className="text-gray-500 hover:text-white text-xs md:text-sm flex items-center gap-2 transition-colors"
              >
                data@empire325marketing.com
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>6-12mo</p>
                <p className="text-gray-500 text-xs md:text-sm">Positive ROI Timeline</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-[#0dc2cc]" style={{ width: "75%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-white" style={{ fontWeight: 1000 }}>40-60%</p>
                <p className="text-gray-500 text-xs md:text-sm">Faster Decisions</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-white" style={{ width: "100%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6 col-span-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-1">Competitive Advantage</p>
                    <p className="text-xl md:text-2xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>Single Source of Truth</p>
                    <p className="text-gray-500 text-xs md:text-sm">eliminating conflicting reports and organizational confusion</p>
                  </div>
                  <div className="text-4xl md:text-6xl text-gray-800 hidden sm:block">→</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-12 md:mt-16 pt-6 md:pt-8 border-t border-gray-800">
          <p className="text-gray-600 text-xs md:text-sm">
            For comprehensive market analysis, reference the 2026 Enterprise Data Infrastructure Outlook from Empire325 Marketing Intelligence Group.
          </p>
        </div>
      </div>
    </section>
  );
}
