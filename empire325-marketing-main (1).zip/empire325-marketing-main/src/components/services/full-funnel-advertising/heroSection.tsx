import Button from "@/components/ui/Button";

export default function HeroSection() {
  const outcomes = [
    { stat: "35-50%", label: "reduction in customer acquisition costs through unified optimization" },
    { stat: "2.5-4X", label: "return on ad spend improvement vs. fragmented management" },
    { stat: "60-75%", label: "increase in qualified lead volume while maintaining CAC targets" },
    { stat: "40-55%", label: "reduction in wasted spend on low-intent audiences" },
    { stat: "25-35%", label: "lower cost per acquisition through agency consolidation" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Main Grid */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          {/* Left Content */}
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Full-Funnel Advertising
            </p>
            <h1
              className="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] text-black leading-[1.1] mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Unified Paid Media Management Driving Reach, Nurturing, and Conversion
            </h1>
            <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6 md:mb-8">
              Enterprise advertising effectiveness is determined not by channel access—organizations possess equivalent platform capabilities—but by unified full-funnel orchestration connecting awareness investment to revenue outcomes. Organizations managing paid media as integrated systems rather than disconnected channel executions achieve measurably superior customer acquisition economics.
            </p>
            <p className="text-sm md:text-base text-gray-500 leading-relaxed mb-8 md:mb-10">
              Most enterprises operate fragmented advertising infrastructure: separate agencies managing search, social, display, and video with conflicting strategies, duplicated audiences, and optimization working against organizational objectives. Budget compounds waste rather than results.
            </p>
            <Button href="/company/contact" variant="primary">
              Assess Your Advertising Infrastructure
            </Button>
          </div>

          {/* Right - The Gap */}
          <div className="lg:col-span-4 bg-black p-6 md:p-8 flex flex-col justify-between min-h-[200px]">
            <div>
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">The Advantage</p>
              <p className="text-4xl sm:text-5xl md:text-6xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>2.5-4X</p>
              <p className="text-white mt-2 text-sm md:text-base">return on ad spend</p>
            </div>
            <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-gray-800">
              <p className="text-gray-500 text-xs md:text-sm">
                vs. fragmented agency management
              </p>
            </div>
          </div>
        </div>

        {/* Intro Text */}
        <div className="mb-6 md:mb-10">
          <p className="text-sm md:text-base text-gray-600">
            Organizations with unified full-funnel advertising management deliver measurable advantages:
          </p>
        </div>

        {/* Outcomes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px bg-gray-200">
          {outcomes.map((item, index) => (
            <div key={index} className={`bg-white p-4 md:p-6 ${index === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
              <p className="text-2xl md:text-3xl text-black mb-2" style={{ fontWeight: 1000 }}>
                {item.stat}
              </p>
              <p className="text-gray-500 text-xs md:text-sm">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Bottom Statement */}
        <div className="mt-8 md:mt-10 pt-8 md:pt-10 border-t border-gray-200">
          <p className="text-base md:text-lg text-black" style={{ fontWeight: 1000 }}>
            Empire325 delivers integrated advertising management across complete customer journey—Reach, Nurturing, Conversion—operating as single unified system, not fragmented channel executions.
          </p>
        </div>
      </div>
    </section>
  );
}
