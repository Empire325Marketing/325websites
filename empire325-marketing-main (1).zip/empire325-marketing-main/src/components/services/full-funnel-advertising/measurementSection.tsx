export default function MeasurementSection() {
  const measurementFramework = [
    {
      category: "Acquisition Efficiency",
      metrics: ["Customer acquisition cost (CAC)", "Cost per qualified lead", "Return on ad spend (ROAS)"],
      target: "35-50% CAC reduction 2.5-4X ROAS improvement",
    },
    {
      category: "Volume & Scale",
      metrics: ["Qualified lead volume growth", "Pipeline contribution", "New customer acquisition"],
      target: "60-75% qualified lead increase Maintaining efficiency",
    },
    {
      category: "Attribution Accuracy",
      metrics: ["Multi-touch attribution coverage", "Revenue attribution to campaigns", "Channel contribution clarity"],
      target: "85-95% touchpoints tracked Closed-loop revenue visibility",
    },
    {
      category: "Budget Optimization",
      metrics: ["Wasted spend reduction", "Budget efficiency improvement", "Agency fee consolidation"],
      target: "40-55% wasted spend eliminated 25-35% lower total costs",
    },
    {
      category: "Creative Performance",
      metrics: ["Click-through rate improvement", "Conversion rate optimization", "Testing velocity and wins"],
      target: "30-50% CTR improvement 8-12 tests monthly Systematic advantage",
    },
  ];

  const reportingCadence = [
    { frequency: "Weekly", activities: "Campaign performance, budget pacing, optimization recommendations" },
    { frequency: "Monthly", activities: "Attribution analysis, creative testing results, channel performance comparison" },
    { frequency: "Quarterly", activities: "Business impact review, strategic planning, competitive analysis" },
    { frequency: "Annual", activities: "Full-year performance assessment, budget planning, platform strategy" },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Measurement Framework
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Business Impact Metrics
            </h2>
          </div>
          <div className="lg:col-span-4 flex items-end">
            <p className="text-sm md:text-base text-gray-600">
              We measure advertising success through business impact metrics connecting media investment to revenue outcomes, not isolated channel vanity metrics.
            </p>
          </div>
        </div>

        {/* Metrics Table */}
        <div className="mb-12 md:mb-16 overflow-x-auto">
          <div className="min-w-[600px]">
            <div className="grid grid-cols-3 gap-px bg-gray-300">
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Category</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Primary Metrics</p>
              </div>
              <div className="bg-gray-100 p-3 md:p-4">
                <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Target Performance</p>
              </div>
            </div>
            {measurementFramework.map((row, index) => (
              <div key={index} className="grid grid-cols-3 gap-px bg-gray-300">
                <div className="bg-white p-3 md:p-4">
                  <p className="text-black font-bold text-xs md:text-sm">{row.category}</p>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <ul className="space-y-1">
                    {row.metrics.map((metric, idx) => (
                      <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                        <span className="text-[#0dc2cc]">•</span>
                        {metric}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white p-3 md:p-4">
                  <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.target}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Metrics Visual */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-300 mb-12 md:mb-16">
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>35-50%</p>
            <p className="text-gray-500 text-xs md:text-sm">CAC reduction</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">unified optimization</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>2.5-4X</p>
            <p className="text-gray-500 text-xs md:text-sm">ROAS improvement</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">vs. fragmented management</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-black mb-2" style={{ fontWeight: 1000 }}>60-75%</p>
            <p className="text-gray-500 text-xs md:text-sm">lead volume increase</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">maintaining efficiency</p>
          </div>
          <div className="bg-white p-4 md:p-8">
            <p className="text-3xl sm:text-4xl md:text-5xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>40-55%</p>
            <p className="text-gray-500 text-xs md:text-sm">wasted spend eliminated</p>
            <p className="text-gray-400 text-xs mt-1 md:mt-2">audience optimization</p>
          </div>
        </div>

        {/* Reporting Cadence */}
        <div>
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Reporting Cadence</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {reportingCadence.map((item, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-[#0dc2cc] font-bold mb-2 text-sm md:text-base">{item.frequency}</p>
                <p className="text-gray-600 text-xs md:text-sm">{item.activities}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
