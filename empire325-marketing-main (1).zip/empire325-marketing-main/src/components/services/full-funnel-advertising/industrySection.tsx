export default function IndustrySection() {
  const regulatoryFramework = [
    "Rule 506(c) permits general solicitation to accredited investors",
    "March 2025 simplified accredited investor verification requirements",
    "All marketing materials subject to anti-fraud provisions",
    "Compliance-approved messaging and disclosure requirements",
  ];

  const hnwiTargeting = [
    "LinkedIn campaigns targeting C-suite, investment professionals, wealth segments",
    "Premium streaming advertising reaching affluent demographics",
    "Financial publication placements (Wall Street Journal, Bloomberg, Financial Times)",
    "Behavioral targeting indicating investment interest and sophistication",
  ];

  const investorFunnel = [
    "Educational content campaigns building awareness and trust",
    "Webinar promotion for investor education and qualification",
    "Accredited investor verification workflow integration",
    "Nurture campaigns maintaining engagement through investment decision cycles",
    "Conversion optimization for subscription agreement completion",
  ];

  const performanceMetrics = [
    { stat: "$19,209", label: "cost to raise $1M", subtext: "63% lower than traditional placement agents" },
    { stat: "12%", label: "lead-to-investor conversion", subtext: "vs. 2-3% industry average" },
    { stat: "45-60%", label: "reduction in investor acquisition timeframe", subtext: "" },
    { stat: "Scalable", label: "capital raising", subtext: "beyond traditional network limitations" },
  ];

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Industry Application
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Asset Management & Capital Raising
            </h2>
            <p className="text-sm md:text-base text-gray-600 leading-relaxed">
              SEC Rule 506(c) compliance enabling general solicitation for accredited investor marketing, opening sophisticated advertising strategies previously prohibited under 506(b) regulations.
            </p>
          </div>
        </div>

        {/* SEC 506(c) Compliant Advertising */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">SEC 506(c) Compliant Advertising</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Regulatory Framework</p>
              <ul className="space-y-2">
                {regulatoryFramework.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">High-Net-Worth Individual (HNWI) Targeting</p>
              <ul className="space-y-2">
                {hnwiTargeting.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Investor Qualification Funnel</p>
              <ul className="space-y-2">
                {investorFunnel.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div>
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Performance Metrics</h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200">
            {performanceMetrics.map((metric, index) => (
              <div key={index} className="bg-white p-4 md:p-6">
                <p className="text-2xl sm:text-3xl md:text-4xl text-[#0dc2cc] mb-2" style={{ fontWeight: 1000 }}>
                  {metric.stat}
                </p>
                <p className="text-black font-bold text-xs md:text-sm mb-1">{metric.label}</p>
                {metric.subtext && (
                  <p className="text-gray-500 text-xs">{metric.subtext}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
