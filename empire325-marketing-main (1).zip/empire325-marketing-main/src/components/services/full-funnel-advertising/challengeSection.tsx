export default function ChallengeSection() {
  const agencyTable = [
    { type: "Search Agency", focus: "Google Ads clicks and Quality Score, disconnected from conversion quality", impact: "High-volume low-quality leads sales teams reject" },
    { type: "Social Agency", focus: "Meta and LinkedIn engagement metrics, brand awareness focus", impact: "Awareness spend with unclear conversion contribution" },
    { type: "Display Agency", focus: "Impressions and viewability, programmatic efficiency", impact: "Banner blindness, low conversion rates, fraud risk" },
    { type: "Video Agency", focus: "YouTube views and completion rates, creative production", impact: "High CPMs with uncertain conversion impact" },
    { type: "Creative Agency", focus: "Brand consistency and creative awards, aesthetic appeal", impact: "Beautiful ads that don't convert, slow iteration" },
  ];

  const problems = [
    {
      title: "Conflicting Optimization Objectives",
      desc: "Each agency optimizes isolated channel metrics—clicks, impressions, engagement—disconnected from business outcomes. Search agency maximizes volume regardless of lead quality. Social agency pursues engagement metrics uncorrelated with pipeline. Display agency optimizes viewability without conversion impact measurement. Agencies work against each other pursuing conflicting objectives.",
    },
    {
      title: "Audience Duplication and Waste",
      desc: "Without unified audience management, identical prospects receive redundant messaging across channels. Search agency bids on branded terms competing with social agency's retargeting. Display campaigns reach converted customers already in CRM. Organizations pay multiple acquisition costs for single customers. 40-55% of advertising budget reaches audiences already engaged through other channels.",
    },
    {
      title: "Attribution Confusion",
      desc: "Each agency claims credit for conversions using different attribution models and measurement timeframes. Search uses last-click attribution. Social uses view-through windows. Display uses assisted conversions. Attribution totals exceed 100% of actual conversions. Budget allocation decisions based on conflicting data producing further inefficiency.",
    },
    {
      title: "Coordination Overhead",
      desc: "Marketing leadership spends 15-20 hours weekly coordinating agencies, reconciling reports, and resolving conflicts. Strategic planning requires separate meetings with each agency. Creative development involves multiple approval cycles. Campaign launches require coordinating timing across agencies. Organizational energy dissipates on coordination rather than optimization.",
    },
    {
      title: "Fragmented Learning",
      desc: "Insights remain siloed within individual agencies. Search agency discovers high-performing audience segments never shared with social team. Social creative testing results don't inform display campaigns. Video messaging insights don't optimize search ad copy. Learning compounds within silos rather than across complete advertising system.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            The Challenge
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
            style={{ fontWeight: 1000 }}
          >
            The Fragmented Agency Problem
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-4xl">
            Enterprise advertising operates through fragmented agency relationships generating conflicting strategies and compounding inefficiency. Organizations engage separate specialists for search, social, display, video, and streaming—each optimizing isolated channel metrics disconnected from business outcomes, creating systematic waste and strategic incoherence.
          </p>
        </div>

        {/* Multi-Agency Dysfunction Table */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-4 md:mb-6">The Multi-Agency Dysfunction</h3>
          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-300">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Agency Type</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Optimization Focus</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Business Impact</p>
                </div>
              </div>
              {agencyTable.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-300">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-black font-bold text-xs md:text-sm">{row.type}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.focus}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] text-xs md:text-sm font-bold">{row.impact}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Why Multi-Agency Management Fails */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-black font-bold mb-6 md:mb-8">Why Multi-Agency Management Fails</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {problems.slice(0, 3).map((problem, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-black font-bold mb-2 md:mb-3 text-sm md:text-base">{problem.title}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{problem.desc}</p>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
            {problems.slice(3).map((problem, index) => (
              <div key={index} className="border-t-2 border-gray-300 pt-4 md:pt-6">
                <p className="text-black font-bold mb-2 md:mb-3 text-sm md:text-base">{problem.title}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{problem.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Callout */}
        <div className="bg-black p-6 md:p-10">
          <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
            The Cost of Fragmented Advertising
          </p>
          <p className="text-white text-sm md:text-lg leading-relaxed mb-4 md:mb-6">
            Organizations managing advertising through multiple specialized agencies pay 25-35% premium in combined agency fees, media management costs, and coordination overhead. More critically, fragmented optimization generates 40-55% wasted spend reaching wrong audiences, duplicating conversions, and pursuing conflicting objectives. Competitors with unified advertising management operate with systematically lower customer acquisition costs.
          </p>
          <p className="text-xl md:text-2xl text-white" style={{ fontWeight: 1000 }}>
            Fragmentation creates competitive disadvantage compounding monthly.
          </p>
        </div>
      </div>
    </section>
  );
}
