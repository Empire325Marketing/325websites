import Button from "@/components/ui/Button";

export default function CTASection() {
  const timeline = [
    {
      phase: "Assessment & Audit",
      duration: "Weeks 1-3",
      desc: "Comprehensive review of existing advertising infrastructure including all active platforms, agency relationships, attribution models, and performance data. Current-state documentation identifying waste, duplication, and optimization opportunities. Unified strategy development and implementation roadmap.",
    },
    {
      phase: "Platform Migration & Consolidation",
      duration: "Months 1-2",
      desc: "Unified platform management implementation, tracking and attribution infrastructure deployment, audience consolidation eliminating duplication, initial campaign launches with unified strategy, creative development and testing framework establishment.",
    },
    {
      phase: "Optimization & Scaling",
      duration: "Months 2-6",
      desc: "Full-funnel optimization based on unified attribution data, systematic creative testing identifying winning approaches, budget reallocation flowing spend to highest-ROI channels, audience expansion through lookalike modeling and behavioral targeting, continuous performance improvement.",
    },
    {
      phase: "Sustained Performance",
      duration: "Months 6-12",
      desc: "Compound performance improvements through systematic optimization, advanced capabilities deployment (streaming, programmatic, advanced attribution), competitive monitoring and response, strategic planning for continued growth, sustained CAC advantages vs. competitors.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-black px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-8">
            <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
              Getting Started
            </p>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-5 md:mb-6"
              style={{ fontWeight: 1000 }}
            >
              Transformation Timeline
            </h2>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed">
              Full-funnel advertising transformation requires systematic transition from fragmented agency management to unified optimization infrastructure. Organizations beginning this work achieve measurable improvements in customer acquisition costs and qualified lead volume within first 90 days as unified attribution and optimization replace conflicting strategies.
            </p>
          </div>
          <div className="lg:col-span-4">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>3-6</p>
                <p className="text-gray-500 text-xs md:text-sm">months to positive ROI</p>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-3xl md:text-4xl text-white" style={{ fontWeight: 1000 }}>90</p>
                <p className="text-gray-500 text-xs md:text-sm">days to first results</p>
              </div>
            </div>
          </div>
        </div>

        {/* What To Expect */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl text-white font-bold mb-6 md:mb-8">What To Expect</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-800">
            {timeline.map((item, index) => (
              <div key={index} className="bg-black p-4 md:p-6">
                <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                  <span
                    className="text-2xl md:text-3xl text-[#0dc2cc]"
                    style={{ fontWeight: 1000, opacity: 1 - index * 0.2 }}
                  >
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>
                <p className="text-white font-bold mb-1 text-sm md:text-base">{item.phase}</p>
                <p className="text-[#0dc2cc] text-xs md:text-sm font-bold mb-2 md:mb-3">{item.duration}</p>
                <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Investment & CTA */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 pt-12 md:pt-16 border-t border-gray-800">
          <div className="lg:col-span-7">
            <h3 className="text-lg md:text-xl font-bold text-white mb-3 md:mb-4">
              Investment Considerations
            </h3>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-4 md:mb-6">
              Unified advertising management typically reduces total costs 25-35% through agency consolidation and waste elimination while improving performance. Organizations achieve positive ROI within 3-6 months as customer acquisition costs decline and qualified lead volume increases. Long-term advantage compounds as unified optimization and attribution enable continuous improvement competitors managing fragmented agencies cannot achieve.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
              Fragmented agency relationships create systematic disadvantages. Unified full-funnel management enables competitive advantages competitors cannot replicate through technology alone.
            </p>
            <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
              Our team is available to discuss advertising infrastructure assessment and unified full-funnel management specific to your organization&apos;s current agency relationships, platform usage, and business objectives.
            </p>
            <div className="flex flex-col sm:flex-row flex-wrap gap-4">
              <Button href="/company/contact" variant="secondary">
                Schedule Advertising Assessment
              </Button>
              <a
                href="mailto:advertising@empire325marketing.com"
                className="text-gray-500 hover:text-white text-xs md:text-sm flex items-center gap-2 transition-colors"
              >
                advertising@empire325marketing.com
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="grid grid-cols-2 gap-px bg-gray-800">
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>3-6mo</p>
                <p className="text-gray-500 text-xs md:text-sm">Positive ROI Timeline</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-[#0dc2cc]" style={{ width: "65%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6">
                <p className="text-2xl md:text-3xl text-white" style={{ fontWeight: 1000 }}>25-35%</p>
                <p className="text-gray-500 text-xs md:text-sm">Cost Reduction</p>
                <div className="mt-3 md:mt-4 h-1 bg-gray-800">
                  <div className="h-full bg-white" style={{ width: "100%" }} />
                </div>
              </div>
              <div className="bg-black p-4 md:p-6 col-span-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-1">Competitive Advantage</p>
                    <p className="text-xl md:text-2xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>2.5-4X ROAS</p>
                    <p className="text-gray-500 text-xs md:text-sm">vs. fragmented agency management</p>
                  </div>
                  <div className="text-4xl md:text-6xl text-gray-800 hidden sm:block">→</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-12 md:mt-16 pt-6 md:pt-8 border-t border-gray-800">
          <p className="text-gray-600 text-xs md:text-sm">
            For comprehensive market analysis, reference the 2026 Enterprise Marketing Outlook from Empire325 Marketing Intelligence Group.
          </p>
        </div>
      </div>
    </section>
  );
}
