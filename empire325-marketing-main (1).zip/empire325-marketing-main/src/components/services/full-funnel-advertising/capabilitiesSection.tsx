export default function CapabilitiesSection() {
  const searchCapabilities = {
    campaignStructure: [
      "Branded vs. non-branded separation",
      "Competitor targeting and defensive bidding",
      "Audience layering and bid adjustments",
      "Geographic and device-specific optimization",
    ],
    performanceMax: [
      "Google Performance Max campaign optimization",
      "Shopping feed optimization and merchant center",
      "Product segmentation and bid strategies",
      "Inventory prioritization for profitability",
    ],
    aiAutomation: [
      "Smart bidding strategies (Target CPA, Target ROAS)",
      "Responsive search ads with AI-optimized combinations",
      "Automated bid adjustments by conversion likelihood",
      "Continuous optimization leveraging machine learning",
    ],
    keywordManagement: [
      "Continuous keyword research and expansion",
      "Search query mining for negatives and opportunities",
      "Match type strategy balancing reach and efficiency",
      "Quality Score optimization reducing CPCs",
    ],
  };

  const searchOutcomes = [
    "25-40% reduction in cost per acquisition through AI-powered bidding",
    "50-70% increase in conversion volume while improving efficiency",
    "Quality Score improvements reducing CPCs by 15-25%",
    "Branded search protection preventing competitor conquest",
  ];

  const socialCapabilities = {
    linkedin: [
      "Sponsored Content, InMail, Text Ads, Dynamic Ads",
      "Professional targeting: job titles, seniority, company, industry",
      "ABM campaigns targeting specific companies and decision-makers",
      "Lead generation forms with native conversion",
      "Thought leadership content amplification",
    ],
    meta: [
      "Feed, Stories, Reels, Marketplace placements",
      "Advanced audience targeting: interests, behaviors, demographics",
      "Custom audiences from CRM data and website visitors",
      "Lookalike audiences for prospecting at scale",
      "Advantage+ campaigns leveraging Meta's AI",
    ],
    emerging: [
      "TikTok Ads for younger demographics and consumer brands",
      "Twitter/X Ads for real-time engagement and B2B thought leadership",
      "Pinterest Ads for visual discovery and consumer product categories",
    ],
  };

  const socialOutcomes = [
    "45-65% lower cost per lead vs. broad audience targeting",
    "3-5X engagement improvement through creative testing",
    "ABM campaign performance reaching 60-80% of target accounts",
    "Lookalike audience scaling maintaining efficiency at volume",
  ];

  const displayCapabilities = {
    programmatic: [
      "Google Display Network for reach and efficiency",
      "DSP management (The Trade Desk, DV360) for advanced targeting",
      "Contextual targeting by content category and keywords",
      "Behavioral targeting based on browsing history and interests",
      "Dynamic retargeting with product-specific messaging",
    ],
    video: [
      "YouTube advertising (skippable TrueView, non-skippable, bumper ads)",
      "Connected TV (CTV) and OTT advertising for streaming audiences",
      "Premium streaming inventory (Netflix, Disney+, Prime Video, Hulu, Apple TV+)",
      "In-stream video on publisher sites and social platforms",
      "Video completion optimization and view-through conversion tracking",
    ],
    advanced: [
      "First-party data integration for audience precision",
      "Frequency capping preventing ad fatigue",
      "Sequential messaging advancing prospects through narrative",
      "Brand safety controls and invalid traffic prevention",
      "Cross-device tracking and conversion attribution",
    ],
  };

  const displayOutcomes = [
    "50-70% improvement in viewability through premium inventory",
    "30-45% higher conversion rates from video viewers vs. display",
    "Brand lift measurement documenting awareness and consideration impact",
    "Premium streaming reach engaging affluent audiences unavailable on traditional channels",
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Core Capabilities
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
            style={{ fontWeight: 1000 }}
          >
            Platform-Specific Expertise
          </h2>
        </div>

        {/* 1. Strategic Paid Search Management */}
        <div className="mb-16 md:mb-24">
          <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-8 md:mb-10">
            <div className="lg:col-span-8">
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>1</span>
                <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Strategic Paid Search Management</h3>
              </div>
              <p className="text-sm md:text-base text-gray-600">
                Comprehensive paid search optimization across Google and Microsoft platforms capturing high-intent demand and driving qualified conversions.
              </p>
            </div>
          </div>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Search Capabilities</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200 mb-8 md:mb-10">
            <div className="bg-white p-4 md:p-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Campaign Structure & Strategy</p>
              <ul className="space-y-2">
                {searchCapabilities.campaignStructure.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Performance Max & Shopping</p>
              <ul className="space-y-2">
                {searchCapabilities.performanceMax.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">AI-Powered Automation</p>
              <ul className="space-y-2">
                {searchCapabilities.aiAutomation.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Keyword & Query Management</p>
              <ul className="space-y-2">
                {searchCapabilities.keywordManagement.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-black p-4 md:p-6">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Achieved Outcomes</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
              {searchOutcomes.map((outcome, idx) => (
                <p key={idx} className="text-white text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {outcome}
                </p>
              ))}
            </div>
          </div>
        </div>

        {/* 2. B2B & B2C Paid Social Advertising */}
        <div className="mb-16 md:mb-24">
          <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-8 md:mb-10">
            <div className="lg:col-span-8">
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>2</span>
                <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>B2B & B2C Paid Social Advertising</h3>
              </div>
              <p className="text-sm md:text-base text-gray-600">
                Sophisticated social advertising campaigns on LinkedIn, Meta, and emerging platforms driving awareness, engagement, and conversion across full customer journey.
              </p>
            </div>
          </div>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Social Advertising Expertise</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">LinkedIn Advertising (B2B Focus)</p>
              <ul className="space-y-2">
                {socialCapabilities.linkedin.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Meta Advertising (Facebook & Instagram)</p>
              <ul className="space-y-2">
                {socialCapabilities.meta.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Emerging Platforms</p>
              <ul className="space-y-2">
                {socialCapabilities.emerging.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-black p-4 md:p-6">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Achieved Outcomes</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
              {socialOutcomes.map((outcome, idx) => (
                <p key={idx} className="text-white text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {outcome}
                </p>
              ))}
            </div>
          </div>
        </div>

        {/* 3. Programmatic Display & Video Advertising */}
        <div>
          <div className="grid lg:grid-cols-12 gap-6 lg:gap-12 mb-8 md:mb-10">
            <div className="lg:col-span-8">
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-3xl md:text-4xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>3</span>
                <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Programmatic Display & Video Advertising</h3>
              </div>
              <p className="text-sm md:text-base text-gray-600">
                Strategic display and video advertising reaching target audiences across open web, premium publishers, and streaming platforms with sophisticated targeting and measurement.
              </p>
            </div>
          </div>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Display & Video Capabilities</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Programmatic Display</p>
              <ul className="space-y-2">
                {displayCapabilities.programmatic.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Video Advertising</p>
              <ul className="space-y-2">
                {displayCapabilities.video.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-300 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Advanced Targeting & Measurement</p>
              <ul className="space-y-2">
                {displayCapabilities.advanced.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-black p-4 md:p-6">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Achieved Outcomes</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
              {displayOutcomes.map((outcome, idx) => (
                <p key={idx} className="text-white text-xs md:text-sm flex items-start gap-2">
                  <span className="text-[#0dc2cc]">•</span>
                  {outcome}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
