export default function ApproachSection() {
  const funnelStages = [
    {
      stage: "REACH (Top of Funnel)",
      objective: "Build brand awareness and capture attention of target audiences demonstrating problem awareness or category interest",
      channels: [
        "Premium streaming (Netflix, Disney+, Hulu)",
        "YouTube video advertising",
        "LinkedIn sponsored content",
        "Programmatic display",
      ],
    },
    {
      stage: "NURTURING (Middle of Funnel)",
      objective: "Engage prospects evaluating solutions, provide education, establish authority and preference during consideration phase",
      channels: [
        "LinkedIn InMail and messaging",
        "Meta engagement campaigns",
        "YouTube retargeting",
        "Content syndication",
      ],
    },
    {
      stage: "CONVERSION (Bottom of Funnel)",
      objective: "Drive qualified conversions from high-intent prospects ready to purchase, request demos, or engage with sales",
      channels: [
        "Google Search (branded & non-branded)",
        "LinkedIn conversion campaigns",
        "Meta lead generation",
        "Display retargeting",
      ],
    },
  ];

  const paidSearchItems = [
    "Google Ads (Search, Shopping, Performance Max)",
    "Microsoft Advertising (Bing, LinkedIn integration)",
    "Amazon Advertising for e-commerce",
    "AI-powered bid management and automation",
  ];

  const paidSocialItems = [
    "LinkedIn Ads (Sponsored Content, InMail, Display)",
    "Meta (Facebook, Instagram feed, stories, reels)",
    "Twitter/X Ads for B2B and thought leadership",
    "TikTok Ads for consumer and younger demographics",
  ];

  const programmaticItems = [
    "Google Display Network reach and efficiency",
    "Trade Desk and DV360 DSP management",
    "Contextual and behavioral targeting",
    "Dynamic retargeting and sequential messaging",
  ];

  const videoItems = [
    "YouTube advertising (skippable, non-skippable, bumper)",
    "Connected TV / OTT advertising",
    "Premium streaming partnerships",
    "Video retargeting and view-through conversion tracking",
  ];

  const streamingPartners = [
    { name: "Netflix", desc: "Advertising tier launched 2022, premium audience engagement" },
    { name: "Disney+", desc: "Family and franchise-focused audiences, high brand safety" },
    { name: "Prime Video", desc: "Amazon's streaming platform with commerce integration" },
    { name: "Hulu", desc: "Live TV and on-demand, younger demographic skew" },
    { name: "Apple TV+", desc: "Premium content, affluent audience demographics" },
  ];

  const attributionFramework = {
    fullJourney: [
      "First-touch attribution identifying initial awareness source",
      "Multi-touch attribution crediting all touchpoints contributing to conversion",
      "Algorithmic attribution weighting touchpoints by actual influence",
      "Revenue attribution connecting closed deals back to originating campaigns",
    ],
    crossChannel: [
      "Budget allocation based on true conversion contribution, not last-click bias",
      "Channel interaction analysis identifying winning combinations",
      "Incrementality testing measuring true lift vs. organic baseline",
      "Media mix modeling for strategic planning and forecasting",
    ],
    aiPowered: [
      "Automated bidding optimizing for conversions, not clicks",
      "Predictive models forecasting conversion probability by audience",
      "Real-time budget reallocation flowing spend to highest-ROI opportunities",
      "Anomaly detection identifying issues before significant budget waste",
    ],
    audienceUnification: [
      "Centralized audience management preventing duplication across channels",
      "Exclusion lists suppressing converted customers from acquisition campaigns",
      "Sequential messaging advancing prospects through funnel stages",
      "Lookalike modeling from unified customer data, not platform defaults",
    ],
  };

  const creativeCapabilities = {
    multiFormat: [
      "Static display ads (multiple sizes, responsive formats)",
      "Video creative (15s, 30s, 60s for various platforms)",
      "Social media assets (feed posts, stories, reels, carousels)",
      "Search ad copy (headlines, descriptions, extensions)",
      "Landing page design and optimization",
    ],
    testing: [
      "8-12 creative variations tested monthly per channel",
      "Messaging angles, visual approaches, CTAs systematically tested",
      "Statistical significance requirements before scaling winners",
      "Cross-channel learning applied from best-performing creative",
      "Creative fatigue monitoring with automatic refresh rotation",
    ],
    iteration: [
      "Weekly creative performance reviews identifying improvement opportunities",
      "Rapid iteration cycles producing refreshed creative within 48-72 hours",
      "Dynamic creative optimization (DCO) for personalization at scale",
      "Platform-specific optimization leveraging native format strengths",
    ],
  };

  return (
    <section className="py-16 md:py-24 bg-white px-4 sm:px-6 md:px-12 lg:px-16">
      <div className="max-w-[95vw] lg:max-w-[90vw] mx-auto">
        {/* Header */}
        <div className="mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-4 md:mb-5">
            Our Approach
          </p>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-5 md:mb-6"
            style={{ fontWeight: 1000 }}
          >
            Unified Full-Funnel Advertising Management
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-4xl">
            Empire325 full-funnel advertising delivers unified management across complete customer journey—Reach, Nurturing, Conversion—operating as integrated system with consolidated optimization, unified attribution, and single accountability for business outcomes.
          </p>
        </div>

        {/* I. Unified Full-Funnel Strategy */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>I</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Unified Full-Funnel Strategy</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Full-funnel advertising orchestrates awareness, consideration, and conversion investment as integrated system rather than isolated channel tactics.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Three-Stage Customer Journey</h4>
          <div className="overflow-x-auto mb-8 md:mb-10">
            <div className="min-w-[700px]">
              <div className="grid grid-cols-3 gap-px bg-gray-200">
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Stage</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Objective</p>
                </div>
                <div className="bg-gray-100 p-3 md:p-4">
                  <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider">Channels & Tactics</p>
                </div>
              </div>
              {funnelStages.map((row, index) => (
                <div key={index} className="grid grid-cols-3 gap-px bg-gray-200">
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-[#0dc2cc] font-bold text-xs md:text-sm">{row.stage}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <p className="text-gray-600 text-xs md:text-sm">{row.objective}</p>
                  </div>
                  <div className="bg-white p-3 md:p-4">
                    <ul className="space-y-1">
                      {row.channels.map((channel, idx) => (
                        <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                          <span className="text-[#0dc2cc]">•</span>
                          {channel}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-xs md:text-sm text-gray-500 uppercase tracking-wider mb-2">Result</p>
            <p className="text-sm md:text-base text-black font-bold">
              Unified strategy ensuring budget allocation matches business objectives across complete customer journey, not isolated channel optimization pursuing conflicting goals.
            </p>
          </div>
        </div>

        {/* II. Multi-Channel Platform Management */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>II</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Multi-Channel Platform Management</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Centralized management across all major advertising platforms with unified optimization pursuing business outcomes rather than channel-specific metrics.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Platform Expertise</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-200 mb-8 md:mb-10">
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Paid Search</p>
              <ul className="space-y-2">
                {paidSearchItems.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Paid Social</p>
              <ul className="space-y-2">
                {paidSocialItems.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Programmatic Display</p>
              <ul className="space-y-2">
                {programmaticItems.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 md:p-6">
              <p className="text-[#0dc2cc] font-bold mb-3 md:mb-4 text-sm md:text-base">Video & Streaming</p>
              <ul className="space-y-2">
                {videoItems.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Premium Streaming Partnerships */}
          <div className="bg-black p-6 md:p-8">
            <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3 md:mb-4">
              Exclusive Premium Streaming Partnerships
            </p>
            <p className="text-gray-400 text-sm md:text-base mb-6 md:mb-8">
              Empire325 maintains exclusive partnerships providing direct advertising access to premium streaming platforms:
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
              {streamingPartners.map((partner, index) => (
                <div key={index} className="border-t border-gray-800 pt-3 md:pt-4">
                  <p className="text-white font-bold text-sm md:text-base mb-1">{partner.name}</p>
                  <p className="text-gray-500 text-xs">{partner.desc}</p>
                </div>
              ))}
            </div>
            <p className="text-gray-500 text-xs md:text-sm mt-6 md:mt-8 pt-4 md:pt-6 border-t border-gray-800">
              These partnerships enable advertising placements typically unavailable through standard programmatic channels, reaching engaged audiences in premium content environments.
            </p>
          </div>
        </div>

        {/* III. Unified Attribution & Performance Optimization */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>III</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Unified Attribution & Performance Optimization</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            Multi-touch attribution connecting advertising investment across all channels to revenue outcomes, enabling optimization for business results rather than channel-specific vanity metrics.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Attribution Framework</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Full-Journey Tracking</p>
              <ul className="space-y-2">
                {attributionFramework.fullJourney.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Cross-Channel Optimization</p>
              <ul className="space-y-2">
                {attributionFramework.crossChannel.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">AI-Powered Bid Management</p>
              <ul className="space-y-2">
                {attributionFramework.aiPowered.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-black font-bold mb-3 text-sm md:text-base">Audience Unification</p>
              <ul className="space-y-2">
                {attributionFramework.audienceUnification.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Attribution Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-200">
            <div className="bg-gray-100 p-4 md:p-6">
              <p className="text-gray-500 text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Fragmented Attribution</p>
              <ul className="space-y-2">
                <li className="text-gray-600 text-xs md:text-sm">Each agency claims credit</li>
                <li className="text-gray-600 text-xs md:text-sm">Attribution totals &gt;100%</li>
                <li className="text-gray-600 text-xs md:text-sm">Budget decisions based on conflicting data</li>
              </ul>
            </div>
            <div className="bg-black p-4 md:p-6">
              <p className="text-[#0dc2cc] text-xs md:text-sm font-bold uppercase tracking-wider mb-3">Unified Attribution</p>
              <ul className="space-y-2">
                <li className="text-white text-xs md:text-sm">Single source of truth</li>
                <li className="text-white text-xs md:text-sm">Accurate conversion contribution</li>
                <li className="text-white text-xs md:text-sm">Data-driven optimization for true ROI</li>
              </ul>
            </div>
          </div>
        </div>

        {/* IV. Creative Development & Testing */}
        <div>
          <div className="flex items-baseline gap-3 md:gap-4 mb-6 md:mb-8">
            <span className="text-4xl md:text-5xl text-[#0dc2cc]" style={{ fontWeight: 1000 }}>IV</span>
            <h3 className="text-xl md:text-2xl text-black" style={{ fontWeight: 1000 }}>Creative Development & Testing</h3>
          </div>
          <p className="text-sm md:text-base text-gray-600 mb-8 md:mb-10 max-w-3xl">
            High-velocity creative production and systematic testing identifying winning messaging, visuals, and formats across channels and funnel stages.
          </p>

          <h4 className="text-base md:text-lg text-black font-bold mb-4 md:mb-6">Creative Capabilities</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-10">
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Multi-Format Production</p>
              <ul className="space-y-2">
                {creativeCapabilities.multiFormat.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Systematic Testing Framework</p>
              <ul className="space-y-2">
                {creativeCapabilities.testing.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t-2 border-gray-200 pt-4 md:pt-6">
              <p className="text-[#0dc2cc] font-bold mb-3 text-sm md:text-base">Performance-Driven Iteration</p>
              <ul className="space-y-2">
                {creativeCapabilities.iteration.map((item, idx) => (
                  <li key={idx} className="text-gray-600 text-xs md:text-sm flex items-start gap-2">
                    <span className="text-[#0dc2cc]">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-4 md:p-6">
            <p className="text-xs md:text-sm text-gray-500 uppercase tracking-wider mb-2">Result</p>
            <p className="text-sm md:text-base text-black font-bold">
              Creative becomes systematic advantage through velocity and testing discipline, not aesthetic subjective judgment. Organizations out-testing competitors compound performance advantages monthly.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
