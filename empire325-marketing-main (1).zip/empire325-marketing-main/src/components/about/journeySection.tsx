export default function JourneySection() {
  const foundationCapabilities = [
    {
      title: "Full-Funnel Advertising Excellence",
      description: "Rather than managing campaigns in isolation, we built unified advertising infrastructure orchestrating awareness, nurturing, and conversion as integrated system. Multi-touch attribution connected every touchpoint to revenue outcomes. Clients finally answered: which channels drive actual business results? Budget allocation shifted from guesswork to data-driven optimization.",
    },
    {
      title: "Performance Measurement Infrastructure",
      description: "We developed attribution and analytics capabilities traditional agencies couldn't provide—data engineering, statistical modeling, dashboard development. Marketing leaders gained real-time visibility into performance. CFOs received confident answers about marketing ROI. Budget discussions evolved from political negotiations to analytical optimization.",
    },
    {
      title: "Website Optimization Systems",
      description: "Beyond design and development, we implemented systematic testing and optimization infrastructure. Websites became continuously improving conversion engines rather than static deliverables requiring periodic rebuilds. Organizations compounding 15-25% annual performance improvements through disciplined testing achieved systematic advantages competitors managing websites traditionally couldn't replicate.",
    },
  ];

  const scalingExpansions = [
    {
      title: "Data Transformation",
      description: "As analytics requirements became more sophisticated, we built enterprise data infrastructure capabilities—data warehousing, pipeline engineering, governance implementation. Organizations needed unified data foundations before advanced analytics delivered value. We built complete data transformation services enabling attribution and analytics infrastructure.",
    },
    {
      title: "Premium Partnerships",
      description: "We established exclusive partnerships providing capabilities competitors couldn't replicate—premium streaming advertising access (Netflix, Disney+, Prime Video, Hulu, Apple TV+), Google Premier Partner status, Meta Business Partner designation, Microsoft Elite Partner recognition. These relationships enabled superior client outcomes through preferential platform access and advanced beta feature availability.",
    },
    {
      title: "Global Reach",
      description: "Client requirements expanded globally. We built distributed teams spanning time zones, enabling continuous optimization and support. Geography became operational advantage rather than limitation—campaigns operated 24/7 with expert teams monitoring performance and responding to opportunities across markets.",
    },
  ];

  const aiCapabilities = [
    {
      title: "Behavioral Prediction",
      description: "Machine learning models predicting customer behavior—purchase propensity, churn risk, expansion opportunity—with 70-85% accuracy. Marketing campaigns targeted based on predicted intent rather than demographic assumptions. Conversion rates improved 40-60% through behavioral targeting replacing traditional segmentation.",
    },
    {
      title: "Intelligent Content Production",
      description: "AI-augmented content systems producing 10-15X volume without quality degradation. Organizations requiring 450+ monthly content pieces—previously impossible without massive teams—achieved output through AI generation combined with human oversight ensuring brand consistency and strategic alignment.",
    },
    {
      title: "Autonomous Optimization",
      description: "Real-time campaign optimization through algorithmic bid management and budget allocation. Systems monitoring performance continuously, adjusting spending toward highest-ROI opportunities, and identifying issues minutes after occurrence rather than weeks later in manual review cycles. Customer acquisition costs declined 35-50% through AI-powered optimization.",
    },
  ];

  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-20">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            The Journey
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight"
            style={{ fontWeight: 1000 }}
          >
            From Vision to Market Leadership
          </h2>
        </div>

        {/* Phase 1: Building the Foundation */}
        <div className="mb-20">
          <div className="flex items-center gap-6 mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">01</span>
            <h3 className="text-2xl font-bold text-black">Building the Foundation</h3>
            <span className="text-gray-400">2019-2020</span>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <div className="grid lg:grid-cols-2 gap-20 mb-12">
            <div>
              <p className="text-gray-600 leading-relaxed mb-6">
                The first challenge was proving the integrated model worked. Organizations accustomed to specialist agencies expressed skepticism that single teams could deliver excellence across strategy, execution, analytics, and technology. The market default assumed trade-offs—breadth sacrificing depth.
              </p>
              <p className="text-black font-bold">
                We proved otherwise through systematic capability building:
              </p>
            </div>
            <div className="space-y-6">
              {foundationCapabilities.map((cap, index) => (
                <div key={index} className="border-l-2 border-gray-200 pl-6 hover:border-[#0dc2cc] transition-colors">
                  <p className="text-black font-bold mb-2">{cap.title}</p>
                  <p className="text-gray-500 text-sm">{cap.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8">
            <p className="text-gray-600 leading-relaxed">
              Early client success validated the model. Organizations engaging Empire325 reduced customer acquisition costs 25-40% while improving lead quality. Marketing teams spent less time coordinating agencies and more time driving strategy. Executive confidence in marketing improved as measurement uncertainty disappeared. <span className="text-black font-bold">The integrated approach worked. Demand accelerated.</span>
            </p>
          </div>
        </div>

        {/* Phase 2: Scaling Operations */}
        <div className="mb-20">
          <div className="flex items-center gap-6 mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">02</span>
            <h3 className="text-2xl font-bold text-black">Scaling Operations</h3>
            <span className="text-gray-400">2020-2022</span>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <div className="grid lg:grid-cols-2 gap-20 mb-12">
            <div>
              <p className="text-gray-600 leading-relaxed mb-6">
                Success created new challenges: scaling integrated capability while maintaining quality, expanding service breadth without sacrificing depth, and building organizational infrastructure supporting rapid growth.
              </p>
              <p className="text-gray-600 leading-relaxed mb-6">
                Client acquisition and retention metrics validated product-market fit: Organizations experiencing Empire325&apos;s integrated approach rarely returned to fragmented agency relationships. Retention rates exceeded industry standards. Client growth came primarily through referrals from marketing leaders experiencing results they couldn&apos;t achieve previously.
              </p>
              <p className="text-black font-bold">
                We expanded capabilities systematically:
              </p>
            </div>
            <div className="space-y-6">
              {scalingExpansions.map((item, index) => (
                <div key={index} className="border-l-2 border-gray-200 pl-6 hover:border-[#0dc2cc] transition-colors">
                  <p className="text-black font-bold mb-2">{item.title}</p>
                  <p className="text-gray-500 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-8 border-t border-gray-200 pt-8">
            <div>
              <div className="text-4xl font-black text-[#0dc2cc]">130+</div>
              <p className="text-gray-500 text-sm">organizations served</p>
            </div>
            <div>
              <div className="text-4xl font-black text-black">5</div>
              <p className="text-gray-500 text-sm">industries spanning</p>
            </div>
            <div className="col-span-2 lg:col-span-1">
              <p className="text-gray-600 text-sm">
                By 2022, Empire325 served over 130 organizations spanning technology, healthcare, financial services, e-commerce, and professional services. The integrated model proven viable at founding demonstrated scalability without quality compromise.
              </p>
            </div>
          </div>
        </div>

        {/* Phase 3: AI-Powered Marketing Infrastructure */}
        <div>
          <div className="flex items-center gap-6 mb-10">
            <span className="text-[#0dc2cc] text-sm font-bold">03</span>
            <h3 className="text-2xl font-bold text-black">AI-Powered Marketing Infrastructure</h3>
            <span className="text-gray-400">2022-Present</span>
            <div className="hidden md:block flex-1 h-px bg-gray-200" />
          </div>

          <div className="grid lg:grid-cols-2 gap-20 mb-12">
            <div>
              <p className="text-gray-600 leading-relaxed mb-6">
                Marketing effectiveness increasingly required artificial intelligence and machine learning capabilities beyond traditional agency expertise. In 2022, Empire325 partnered with Algo Vision to bring advanced AI/ML engineering directly into marketing execution.
              </p>
              <p className="text-black font-bold">
                This partnership enabled AI-powered marketing infrastructure previously unavailable:
              </p>
            </div>
            <div className="space-y-6">
              {aiCapabilities.map((item, index) => (
                <div key={index} className="border-l-2 border-gray-200 pl-6 hover:border-[#0dc2cc] transition-colors">
                  <p className="text-black font-bold mb-2">{item.title}</p>
                  <p className="text-gray-500 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8">
            <p className="text-gray-600 leading-relaxed">
              AI capabilities transformed marketing from manual optimization—limited by human analysis speed—to algorithmic systems operating continuously at scale. <span className="text-black font-bold">Organizations deploying AI-powered marketing infrastructure achieved competitive advantages manual processes couldn&apos;t replicate.</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
