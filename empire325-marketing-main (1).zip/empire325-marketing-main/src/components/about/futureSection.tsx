import Button from "@/components/ui/Button";

export default function FutureSection() {
  const expansions = [
    "Advanced AI/ML systems enabling predictive analytics, autonomous optimization, and behavioral intelligence at scales previously impossible",
    "Deeper platform integrations connecting marketing, sales, product, and financial systems for comprehensive attribution and unified organizational intelligence",
    "Industry-specific expertise developing specialized capabilities for regulated industries, complex sales cycles, and unique marketing challenges",
    "Global expansion serving multinational organizations requiring integrated marketing infrastructure across regions and markets",
    "Continuous innovation staying ahead of platform changes, algorithm updates, and competitive dynamics enabling sustained client advantages",
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20 mb-16">
          {/* Left Column */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Looking Forward
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Expanding Capabilities Enabling Client Success
            </h2>
            <p className="text-base text-gray-400 leading-relaxed">
              The marketing infrastructure challenges organizations faced in 2019 persist today—fragmentation, attribution uncertainty, technology-marketing divides. Many organizations still operate with systematic disadvantages we set out to solve.
            </p>
          </div>

          {/* Right Column - Expansions */}
          <div>
            <p className="text-white font-bold mb-6">
              Empire325 continues expanding capabilities enabling client success:
            </p>
            <div className="space-y-4">
              {expansions.map((expansion, index) => (
                <div key={index} className="flex gap-4">
                  <span className="text-[#0dc2cc] shrink-0">→</span>
                  <p className="text-gray-400">{expansion}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Statement */}
        <div className="border-t border-gray-800 pt-12">
          <div className="grid lg:grid-cols-2 gap-20">
            <div>
              <p className="text-gray-400 leading-relaxed mb-6">
                The opportunity remains substantial. Most organizations still manage marketing through fragmented relationships generating systematic disadvantages. Marketing leadership deserves infrastructure proving results through comprehensive measurement, not optimism disconnected from outcomes.
              </p>
              <p className="text-white leading-relaxed">
                Empire325 builds that infrastructure. We solved these problems for ourselves. We solve them for clients. And we&apos;ll continue building capabilities enabling organizations to prove marketing&apos;s contribution to business success.
              </p>
            </div>
            <div className="flex flex-col justify-end">
              <div className="border-l-2 border-[#0dc2cc] pl-6 mb-8">
                <p className="text-[#0dc2cc] text-sm font-bold uppercase tracking-wider mb-2">
                  Empire325 Marketing
                </p>
                <p className="text-white text-xl font-bold">
                  Integrated Marketing Infrastructure That Proves Results
                </p>
              </div>
              <Button href="/company/contact">Start a Conversation</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
