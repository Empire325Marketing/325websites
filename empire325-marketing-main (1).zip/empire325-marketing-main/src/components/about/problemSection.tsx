export default function ProblemSection() {
  const problems = [
    {
      title: "Fragmented Agency Landscape",
      description: "Organizations engaged separate specialists for search, social, display, content, analytics—each optimizing isolated metrics disconnected from business outcomes. Marketing leaders spent more time coordinating agencies than driving strategy. Conflicting recommendations, duplicated audiences, and attribution confusion became standard operating procedure.",
    },
    {
      title: "Technology-Marketing Divide",
      description: "Marketing agencies possessed creative and media buying expertise but lacked engineering capability required for data infrastructure, attribution systems, and AI-powered optimization. Technology firms understood platforms and code but not marketing strategy or customer psychology. Organizations needed both—integrated—but the market offered fragmented specialists.",
    },
    {
      title: "Attribution Impossibility",
      description: "CMOs faced impossible questions from CFOs: Which marketing investments drive revenue? What's our true customer acquisition cost? Which channels should receive more budget? Without unified measurement infrastructure connecting marketing activities to closed deals, answers remained guesses dressed as analysis. Budget allocation decisions rested on assumptions rather than data.",
    },
    {
      title: "Vanity Metrics Over Results",
      description: "Marketing reported impressions, clicks, and engagement—metrics disconnected from revenue outcomes. Agencies optimized for metrics improving their own performance reviews rather than client business results. Beautiful creative won awards while conversion rates stagnated. Activity masqueraded as progress.",
    },
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            The Problem We Saw
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Systematic Disadvantages Became Industry Accepted Practice
          </h2>
          <p className="text-base text-gray-400 leading-relaxed mb-6">
            In 2019, marketing leadership across organizations—from growth-stage companies to global enterprises—operated under systematic disadvantages that had become industry accepted practice. Marketing was expensive, outcomes were uncertain, and proving return on investment remained elusive for most organizations.
          </p>
          <p className="text-base text-white leading-relaxed">
            Four fundamental problems prevented marketing organizations from achieving their potential:
          </p>
        </div>

        {/* Problems List - Horizontal Cards */}
        <div className="space-y-0">
          {problems.map((problem, index) => (
            <div
              key={index}
              className="border-t border-gray-800 py-8 flex flex-col md:flex-row md:items-start gap-6 md:gap-12"
            >
              {/* Number */}
              <div className="text-[#0dc2cc] text-sm font-bold w-8 shrink-0">
                0{index + 1}
              </div>

              {/* Title */}
              <div className="md:w-1/4 shrink-0">
                <h3 className="text-xl font-bold text-white">
                  {problem.title}
                </h3>
              </div>

              {/* Description */}
              <div className="flex-1">
                <p className="text-gray-400 leading-relaxed">
                  {problem.description}
                </p>
              </div>
            </div>
          ))}
          {/* Bottom border */}
          <div className="border-t border-gray-800" />
        </div>

        {/* Bottom Statement */}
        <div className="mt-16 grid lg:grid-cols-2 gap-12">
          <p className="text-base text-gray-400 leading-relaxed">
            These weren&apos;t isolated inefficiencies—they were systematic failures preventing organizations from achieving marketing&apos;s actual potential. The cost wasn&apos;t just wasted budget. It was competitive disadvantage compounding monthly as data-driven competitors optimized faster, allocated budgets smarter, and proved results confidently.
          </p>
          <p className="text-base text-white leading-relaxed font-bold">
            The market needed integrated marketing infrastructure combining strategic expertise, technical capability, and unified measurement. That infrastructure didn&apos;t exist.
          </p>
        </div>
      </div>
    </section>
  );
}
