export default function WhatWeAreSection() {
  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              What Empire325 Is
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight"
              style={{ fontWeight: 1000 }}
            >
              Integrated Marketing & Technology Organization
            </h2>
          </div>

          {/* Right Column */}
          <div>
            <p className="text-base text-gray-400 leading-relaxed mb-6">
              Empire325 is an integrated marketing and technology organization delivering full-funnel advertising, performance analytics, data transformation, web optimization, and AI-powered marketing infrastructure.
            </p>
            <p className="text-base text-gray-400 leading-relaxed mb-8">
              We combine strategic marketing expertise with engineering capability, enabling unified execution and comprehensive measurement that traditional agencies cannot provide.
            </p>
            <div className="border-l-2 border-[#0dc2cc] pl-6">
              <p className="text-white leading-relaxed">
                We serve growth-stage companies and global enterprises requiring marketing infrastructure that proves results, not marketing optimism disconnected from business outcomes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
