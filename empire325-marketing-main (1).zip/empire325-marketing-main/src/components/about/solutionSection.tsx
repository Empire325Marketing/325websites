export default function SolutionSection() {
  const visionPoints = [
    "Strategy, execution, and measurement operated as integrated system, not fragmented specialists pursuing conflicting objectives",
    "Marketing expertise combined with engineering capability, enabling data infrastructure and AI-powered optimization alongside creative and media excellence",
    "Attribution connected marketing investment to revenue outcomes, answering CFO questions with measurement certainty rather than marketing optimism",
    "Success measured by business results, not vanity metrics—customer acquisition cost, return on ad spend, pipeline contribution, revenue attribution",
    "Accountability remained singular, eliminating coordination overhead and finger-pointing across multiple agencies when performance missed targets",
  ];

  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column - Main Content */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              The Solution We Built
            </p>
            <h2
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-8"
              style={{ fontWeight: 1000 }}
            >
              Integrated Marketing Infrastructure Delivering Provable Results
            </h2>
            <p className="text-base text-gray-600 leading-relaxed mb-6">
              Empire325 was founded in 2019 with clarity about what organizations needed: integrated marketing infrastructure delivering provable results through unified strategy, technical execution, and comprehensive measurement.
            </p>
            <p className="text-base text-gray-600 leading-relaxed mb-10">
              The vision was direct—build the marketing organization we wished existed when facing these problems ourselves. An organization where:
            </p>

            {/* Vision Points */}
            <div className="space-y-4">
              {visionPoints.map((point, index) => (
                <div key={index} className="flex gap-4">
                  <span className="text-[#0dc2cc] shrink-0">→</span>
                  <p className="text-gray-600">{point}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column */}
          <div className="flex flex-col justify-end">
            <div className="border-t border-gray-200 pt-8">
              <p className="text-gray-600 leading-relaxed mb-6">
                This wasn&apos;t incremental improvement to existing agency models—it required fundamental rethinking of how marketing organizations should operate.
              </p>
              <p className="text-black font-bold text-lg">
                Traditional agencies optimized for their business model. We optimized for client outcomes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
