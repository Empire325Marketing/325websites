export default function BeliefsSection() {
  const beliefs = [
    {
      title: "Integration Over Specialization",
      description: "Marketing effectiveness requires unified strategy, execution, and measurement operating as integrated system. Fragmented specialists optimizing isolated metrics generate conflicting priorities and attribution confusion. Organizations need single teams accountable for business outcomes, not coordinators managing agency conflicts.",
    },
    {
      title: "Results Over Activity",
      description: "Marketing success is measured by business outcomes—customer acquisition cost, return on ad spend, pipeline contribution, revenue attribution—not vanity metrics disconnected from results. Impressive click-through rates mean nothing if conversion economics deteriorate. We optimize for outcomes that matter to CFOs, not metrics improving agency performance reviews.",
    },
    {
      title: "Measurement Over Assumptions",
      description: "Budget allocation requires attribution certainty connecting marketing investment to revenue outcomes. Organizations cannot optimize what they cannot measure reliably. We build comprehensive measurement infrastructure enabling confident answers to executive questions about marketing ROI. Data-driven decisions replace political negotiations.",
    },
    {
      title: "Technology Enables Marketing",
      description: "Modern marketing requires engineering capability traditional agencies lack—data infrastructure, AI/ML systems, attribution platforms, optimization algorithms. Marketing strategy without technical execution remains PowerPoint presentations. Technology without marketing expertise becomes engineering demos disconnected from customer psychology. Excellence requires both, integrated.",
    },
    {
      title: "Execution Over Recommendations",
      description: "Consultants deliver recommendations requiring internal teams to execute. Agencies execute tactics within narrow specialties. Organizations need partners delivering complete solutions—strategy, execution, measurement, optimization—operating reliably in production. We build working systems, not presentation decks requiring other vendors to implement.",
    },
    {
      title: "Long-Term Partnerships Over Transactional Relationships",
      description: "Marketing infrastructure compounds value through continuous optimization. Organizations achieving 15-25% annual improvements require sustained partnerships, not project-based engagements ending at launch. We invest in client success long-term, enabling compound advantages competitors managing transactional agency relationships cannot achieve.",
    },
  ];

  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            What We Believe
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Convictions Formed Through Direct Experience
          </h2>
          <p className="text-base text-gray-600 leading-relaxed">
            Empire325&apos;s approach rests on convictions formed through direct experience with problems fragmented marketing relationships create:
          </p>
        </div>

        {/* Beliefs List - Horizontal Cards */}
        <div className="space-y-0">
          {beliefs.map((belief, index) => (
            <div
              key={index}
              className="border-t border-gray-200 py-8 flex flex-col md:flex-row md:items-start gap-6 md:gap-12"
            >
              <div className="text-[#0dc2cc] text-sm font-bold w-8 shrink-0">
                0{index + 1}
              </div>
              <div className="md:w-1/4 shrink-0">
                <h3 className="text-xl font-bold text-black">{belief.title}</h3>
              </div>
              <div className="flex-1">
                <p className="text-gray-600 leading-relaxed">{belief.description}</p>
              </div>
            </div>
          ))}
          <div className="border-t border-gray-200" />
        </div>
      </div>
    </section>
  );
}
