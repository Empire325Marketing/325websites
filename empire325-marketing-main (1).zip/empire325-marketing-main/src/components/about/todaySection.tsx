import Button from "@/components/ui/Button";

export default function TodaySection() {
  const services = [
    {
      title: "Full-Funnel Advertising",
      description: "Unified paid media management across search, social, display, video, and premium streaming—orchestrating awareness, nurturing, and conversion as integrated system with multi-touch attribution connecting investment to revenue outcomes.",
    },
    {
      title: "Performance & Analytics",
      description: "Comprehensive measurement infrastructure connecting marketing activities to revenue with 95%+ attribution accuracy, real-time dashboards replacing manual reporting cycles, and predictive analytics enabling data-driven budget allocation.",
    },
    {
      title: "Data Transformation",
      description: "Enterprise data infrastructure enabling unified analytics—data engineering, pipeline development, governance implementation, and business intelligence—creating single source of truth eliminating conflicting reports across organizations.",
    },
    {
      title: "Web Development & Optimization",
      description: "Website infrastructure operating as conversion optimization engines through systematic A/B testing, technical SEO excellence, and performance architecture—achieving 45-120% conversion improvements and 40-80% organic traffic growth.",
    },
    {
      title: "AI-Powered Marketing Infrastructure",
      description: "Advanced artificial intelligence and machine learning capabilities enabling behavioral prediction (70-85% accuracy), intelligent content production (10-15X volume), autonomous campaign optimization (35-50% CAC reduction), and real-time performance management operating at scale beyond human analysis capability.",
    },
  ];

  const clientCharacteristics = [
    {
      title: "They demand accountability",
      description: "Marketing budgets require justification through provable ROI, not activity metrics. CFOs ask difficult questions expecting confident answers backed by data.",
    },
    {
      title: "They recognize fragmentation costs",
      description: "Managing multiple specialized agencies generates coordination overhead, conflicting strategies, and attribution confusion preventing optimization.",
    },
    {
      title: "They value integration",
      description: "Marketing effectiveness requires strategy, execution, and measurement operating as unified system—not disconnected specialists pursuing isolated objectives.",
    },
    {
      title: "They need technical capability",
      description: "Modern marketing requires data engineering, AI/ML expertise, and platform integration traditional agencies cannot provide. Organizations need marketing and technology combined.",
    },
    {
      title: "They expect results, not excuses",
      description: "When performance misses targets, they require analysis and correction—not finger-pointing across multiple agencies claiming their piece performed while others failed.",
    },
  ];

  return (
    <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
            Empire325 Today
          </p>
          <h2
            className="text-3xl md:text-4xl lg:text-[42px] text-white leading-tight mb-6"
            style={{ fontWeight: 1000 }}
          >
            Integrated Marketing Infrastructure Delivering Provable Results
          </h2>
          <p className="text-base text-gray-400 leading-relaxed">
            Today, Empire325 serves 130+ organizations requiring integrated marketing infrastructure delivering provable results. Our clients span growth-stage companies scaling customer acquisition and global enterprises optimizing marketing efficiency across complex organizational structures.
          </p>
        </div>

        {/* What We Deliver */}
        <div className="mb-20">
          <h3 className="text-xl font-bold text-white mb-10">What We Deliver</h3>

          <div className="space-y-0">
            {services.map((service, index) => (
              <div
                key={index}
                className="border-t border-gray-800 py-8 flex flex-col md:flex-row md:items-start gap-6 md:gap-12"
              >
                <div className="text-[#0dc2cc] text-sm font-bold w-8 shrink-0">
                  0{index + 1}
                </div>
                <div className="md:w-1/4 shrink-0">
                  <h4 className="text-lg font-bold text-white">{service.title}</h4>
                </div>
                <div className="flex-1">
                  <p className="text-gray-400 leading-relaxed">{service.description}</p>
                </div>
              </div>
            ))}
            <div className="border-t border-gray-800" />
          </div>

          <div className="mt-10 border-l-2 border-[#0dc2cc] pl-6">
            <p className="text-gray-400 leading-relaxed">
              These services operate as integrated infrastructure, not independent offerings. Attribution systems feed optimization algorithms. Data infrastructure enables AI-powered marketing. Web optimization informs advertising strategy. <span className="text-white font-bold">The integration generates advantages fragmented specialist relationships cannot replicate.</span>
            </p>
          </div>
        </div>

        {/* Who We Serve */}
        <div>
          <div className="grid lg:grid-cols-2 gap-20 mb-12">
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Who We Serve</h3>
              <p className="text-gray-400 leading-relaxed mb-6">
                Empire325 works with organizations requiring marketing infrastructure proving results through comprehensive measurement, not marketing optimism disconnected from business outcomes.
              </p>
              <p className="text-white font-bold">
                Our clients share common characteristics:
              </p>
            </div>
            <div className="space-y-6">
              {clientCharacteristics.map((char, index) => (
                <div key={index} className="border-l-2 border-gray-800 pl-6 hover:border-[#0dc2cc] transition-colors">
                  <p className="text-white font-bold mb-2">{char.title}</p>
                  <p className="text-gray-500 text-sm">{char.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-800 pt-10">
            <p className="text-gray-400 leading-relaxed mb-8">
              We serve clients across technology, healthcare, financial services, e-commerce, asset management, and professional services. Some are growth-stage companies scaling customer acquisition. Others are global enterprises optimizing marketing efficiency. <span className="text-white font-bold">All require integrated infrastructure proving marketing&apos;s contribution to business outcomes.</span>
            </p>
            <Button href="/company/contact">Work with our team</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
