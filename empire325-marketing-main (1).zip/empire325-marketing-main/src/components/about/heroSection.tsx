export default function HeroSection() {
  return (
    <section className="bg-white py-24 px-6 md:px-12 lg:px-16">
      <div className="max-w-[90vw] mx-auto">
        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column - Main Content */}
          <div>
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              About Empire325
            </p>
            <h1
              className="text-3xl md:text-4xl lg:text-[42px] text-black leading-tight mb-8"
              style={{ fontWeight: 1000 }}
            >
              Building Integrated Marketing Infrastructure That Proves Results
            </h1>
            <p className="text-xl text-gray-800 leading-relaxed mb-6">
              Marketing organizations face an existential question: Can you prove your contribution to revenue?
            </p>
            <p className="text-base text-gray-600 leading-relaxed mb-6">
              Organizations unable to answer confidently operate at systematic disadvantage—budget decisions rest on assumptions rather than measurement certainty, CFOs question marketing value during economic uncertainty, and competitors with attribution infrastructure optimize faster while others debate data accuracy. The separation between marketing as cost center versus revenue driver is measurement infrastructure connecting activities to outcomes.
            </p>
          </div>

          {/* Right Column */}
          <div className="flex flex-col justify-center">
            <div className="border-l-2 border-[#0dc2cc] pl-8">
              <p className="text-base text-gray-600 leading-relaxed mb-6">
                Empire325 exists because that infrastructure—integrated strategy, technical execution, and comprehensive measurement proving marketing&apos;s contribution to business outcomes—did not exist when organizations needed it most.
              </p>
              <p className="text-black text-lg font-bold">
                This is our story, and the problems we solve.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
