import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Script from "next/script";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import JsonLd, { organizationSchema, websiteSchema } from "@/components/seo/JsonLd";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://empire325marketing.com"),
  title: {
    default: "Empire325 Marketing | Strategic Digital Marketing Solutions",
    template: "%s | Empire325 Marketing",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Empire325",
  },
  formatDetection: {
    telephone: true,
    email: true,
    address: true,
  },
  description:
    "Empire325 Marketing delivers enterprise-grade digital marketing solutions. From AI-powered tools to full-funnel advertising, we help businesses scale with data-driven strategies.",
  keywords: [
    "digital marketing agency",
    "enterprise marketing",
    "AI marketing solutions",
    "full-funnel advertising",
    "performance marketing",
    "web development",
    "data transformation",
    "marketing analytics",
    "B2B marketing",
    "lead generation",
    "Empire325",
  ],
  authors: [{ name: "Empire325 Marketing" }],
  creator: "Empire325 Marketing",
  publisher: "Empire325 Marketing",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://empire325marketing.com",
    siteName: "Empire325 Marketing",
    title: "Empire325 Marketing | Strategic Digital Marketing Solutions",
    description:
      "Empire325 Marketing delivers enterprise-grade digital marketing solutions. From AI-powered tools to full-funnel advertising, we help businesses scale with data-driven strategies.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Empire325 Marketing",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Empire325 Marketing | Strategic Digital Marketing Solutions",
    description:
      "Empire325 Marketing delivers enterprise-grade digital marketing solutions. From AI-powered tools to full-funnel advertising, we help businesses scale with data-driven strategies.",
    images: ["/og-image.png"],
    creator: "@empire325",
  },
  alternates: {
    canonical: "https://empire325marketing.com",
  },
  category: "Marketing",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <meta name="theme-color" content="#0dc2cc" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <Script id="google-tag-manager" strategy="afterInteractive">
          {`
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-W4H57VQX');
          `}
        </Script>
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-JJ9663WSQ6"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-JJ9663WSQ6');
          `}
        </Script>
        <Script id="microsoft-clarity" strategy="afterInteractive">
          {`
            (function(c,l,a,r,i,t,y){
              c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
              t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
              y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
            })(window, document, "clarity", "script", "v1eqxyoq7q");
          `}
        </Script>
        <JsonLd data={organizationSchema} />
        <JsonLd data={websiteSchema} />
      </head>
      <body className={`${inter.variable} antialiased`}>
        <noscript>
          <iframe
            src="https://www.googletagmanager.com/ns.html?id=GTM-W4H57VQX"
            height="0"
            width="0"
            style={{ display: "none", visibility: "hidden" }}
          />
        </noscript>
        <Navbar />
        {children}
        <Footer />
      </body>
    </html>
  );
}
