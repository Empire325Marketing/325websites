import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Page Not Found",
  description: "The page you're looking for doesn't exist or has been moved.",
};

export default function NotFound() {
  return (
    <main className="min-h-[80vh] flex items-center justify-center bg-white px-6">
      <div className="text-center max-w-2xl">
        {/* 404 Number */}
        <h1
          className="text-[120px] md:text-[180px] font-black text-black leading-none"
          style={{ fontWeight: 1000 }}
        >
          4<span className="text-[#0dc2cc]">0</span>4
        </h1>

        {/* Message */}
        <h2
          className="text-2xl md:text-3xl text-black mb-4 -mt-4"
          style={{ fontWeight: 1000 }}
        >
          Page Not Found
        </h2>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
          Let&apos;s get you back on track.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 bg-[#0dc2cc] text-black font-bold py-3 px-8 hover:bg-[#0bb5be] transition-colors"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
              />
            </svg>
            Back to Home
          </Link>
          <Link
            href="/company/contact"
            className="inline-flex items-center justify-center gap-2 border-2 border-black text-black font-bold py-3 px-8 hover:bg-black hover:text-white transition-colors"
          >
            Contact Us
          </Link>
        </div>

        {/* Quick Links */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-4">Popular pages:</p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Link
              href="/services/web-development"
              className="text-[#0dc2cc] hover:underline"
            >
              Web Development
            </Link>
            <Link
              href="/services/full-funnel-advertising"
              className="text-[#0dc2cc] hover:underline"
            >
              Advertising
            </Link>
            <Link
              href="/services/ai-saas-tools"
              className="text-[#0dc2cc] hover:underline"
            >
              AI & SaaS Tools
            </Link>
            <Link
              href="/company/about"
              className="text-[#0dc2cc] hover:underline"
            >
              About Us
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}
