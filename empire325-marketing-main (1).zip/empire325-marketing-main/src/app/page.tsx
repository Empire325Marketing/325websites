import { Metadata } from "next";
import AboutSection from "@/components/home/aboutSection";
import HeroSection from "@/components/home/heroSection";
import ImplementationFrameworks from "@/components/home/implementationFrameworks";
import IndustryDynamics from "@/components/home/industryDynamics";
import IntelligenceSection from "@/components/home/intelligenceSection";
import MarketingForces from "@/components/home/marketingForces";
import MeasuredOutcomes from "@/components/home/measuredOutcomes";
import PerformanceData from "@/components/home/performanceData";
import TransformationMethodology from "@/components/home/transformationMethodology";

export const metadata: Metadata = {
  title: "Empire325 Marketing | Enterprise Digital Marketing & Growth Solutions",
  description:
    "Empire325 Marketing delivers integrated marketing infrastructure combining AI-powered tools, full-funnel advertising, web development, and performance analytics to drive measurable business outcomes.",
  keywords: [
    "enterprise marketing",
    "digital marketing agency",
    "AI marketing",
    "full-funnel advertising",
    "marketing analytics",
    "web development",
    "data transformation",
    "B2B marketing",
    "performance marketing",
    "marketing ROI",
  ],
  openGraph: {
    title: "Empire325 Marketing | Enterprise Digital Marketing & Growth Solutions",
    description:
      "Empire325 Marketing delivers integrated marketing infrastructure combining AI-powered tools, full-funnel advertising, web development, and performance analytics to drive measurable business outcomes.",
    url: "https://empire325marketing.com",
    type: "website",
  },
  twitter: {
    title: "Empire325 Marketing | Enterprise Digital Marketing & Growth Solutions",
    description:
      "Empire325 Marketing delivers integrated marketing infrastructure combining AI-powered tools, full-funnel advertising, web development, and performance analytics to drive measurable business outcomes.",
  },
  alternates: {
    canonical: "https://empire325marketing.com",
  },
};

export default function Home() {
  return (
    <main>
      <HeroSection />
      <MarketingForces />
      <IntelligenceSection />
      <PerformanceData />
      <ImplementationFrameworks />
      <IndustryDynamics />
      <TransformationMethodology />
      <MeasuredOutcomes />
      <AboutSection />
    </main>
  );
}