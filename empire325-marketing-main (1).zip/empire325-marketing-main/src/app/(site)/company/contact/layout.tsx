import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Us | Get a Free Strategy Consultation",
  description:
    "Contact Empire325 Marketing for a free strategy consultation. Get custom proposals, fast response within 4 hours, and tailored marketing solutions for your business growth.",
  keywords: [
    "contact Empire325",
    "marketing consultation",
    "free strategy session",
    "digital marketing agency contact",
    "marketing proposal",
    "business growth consultation",
    "marketing services inquiry",
  ],
  openGraph: {
    title: "Contact Us | Get a Free Strategy Consultation | Empire325 Marketing",
    description:
      "Contact Empire325 Marketing for a free strategy consultation. Get custom proposals, fast response within 4 hours, and tailored marketing solutions for your business growth.",
    url: "https://empire325marketing.com/company/contact",
    type: "website",
  },
  twitter: {
    title: "Contact Us | Get a Free Strategy Consultation | Empire325 Marketing",
    description:
      "Contact Empire325 Marketing for a free strategy consultation. Get custom proposals, fast response within 4 hours, and tailored marketing solutions for your business growth.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/company/contact",
  },
};

export default function ContactLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
