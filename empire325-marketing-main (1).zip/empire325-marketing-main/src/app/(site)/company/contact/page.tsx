"use client";

import { useState } from "react";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    projectType: [] as string[],
    budget: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle");

  const projectTypes = [
    "Website Development",
    "SEO",
    "AI Solutions",
    "Advertising",
  ];

  const handleProjectTypeChange = (type: string) => {
    setFormData((prev) => ({
      ...prev,
      projectType: prev.projectType.includes(type)
        ? prev.projectType.filter((t) => t !== type)
        : [...prev.projectType, type],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus("idle");

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          access_key: process.env.NEXT_PUBLIC_WEB3FORMS_KEY || "YOUR_ACCESS_KEY_HERE",
          name: formData.name,
          email: formData.email,
          company: formData.company,
          phone: formData.phone,
          project_type: formData.projectType.join(", "),
          budget: formData.budget,
          message: formData.message,
          subject: `New Contact Form Submission from ${formData.name}`,
          from_name: "Empire325 Website",
        }),
      });

      const result = await response.json();

      if (result.success) {
        setSubmitStatus("success");
        setFormData({
          name: "",
          company: "",
          email: "",
          phone: "",
          projectType: [],
          budget: "",
          message: "",
        });
      } else {
        setSubmitStatus("error");
      }
    } catch {
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const steps = [
    {
      number: "01",
      title: "Immediate Confirmation",
      description: "Automated response within minutes",
    },
    {
      number: "02",
      title: "Strategic Review",
      description: "Team analysis of your requirements",
    },
    {
      number: "03",
      title: "Consultation Scheduling",
      description: "Calendar link for strategy session",
    },
    {
      number: "04",
      title: "Custom Proposal",
      description: "Tailored recommendations and timeline",
    },
  ];

  const benefits = [
    {
      title: "Free Strategy Consultation",
      description: "30-minute session to discuss your goals and opportunities",
    },
    {
      title: "Custom Proposal",
      description: "Tailored strategy and investment recommendations",
    },
    {
      title: "Fast Response",
      description: "Initial response within 4 business hours",
    },
  ];

  return (
    <main>
      {/* Hero Section */}
      <section className="bg-black py-20 px-6 md:px-12 lg:px-16">
        <div className="max-w-[90vw] mx-auto">
          <div className="max-w-3xl">
            <p className="text-sm font-extrabold tracking-widest text-[#0dc2cc] uppercase mb-5">
              Contact Us
            </p>
            <h1
              className="text-4xl md:text-5xl lg:text-6xl text-white leading-tight mb-6"
              style={{ fontWeight: 1000 }}
            >
              Let&apos;s Start Building
              <br />
              Your Growth Story
            </h1>
            <p className="text-lg text-gray-400 leading-relaxed">
              Ready to accelerate your digital transformation? Our strategic team is here to help you achieve measurable results.
            </p>
          </div>

          {/* Benefits */}
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            {benefits.map((benefit, index) => (
              <div key={index} className="border-l-2 border-[#0dc2cc] pl-6">
                <p className="text-white font-bold mb-2">{benefit.title}</p>
                <p className="text-gray-400 text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className="bg-white py-20 px-6 md:px-12 lg:px-16">
        <div className="max-w-[90vw] mx-auto">
          <div className="grid lg:grid-cols-2 gap-20">
            {/* Contact Form */}
            <div>
              <h2
                className="text-2xl md:text-3xl text-black mb-8"
                style={{ fontWeight: 1000 }}
              >
                Quick Contact Form
              </h2>

              {submitStatus === "success" ? (
                <div className="bg-[#0dc2cc]/10 border border-[#0dc2cc] rounded-lg p-8 text-center">
                  <div className="w-16 h-16 bg-[#0dc2cc] rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-black mb-2">Message Sent!</h3>
                  <p className="text-gray-600 mb-6">
                    Thank you for reaching out. We&apos;ll get back to you within 4 business hours.
                  </p>
                  <button
                    onClick={() => setSubmitStatus("idle")}
                    className="text-[#0dc2cc] font-bold hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {submitStatus === "error" && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
                      Something went wrong. Please try again or email us directly.
                    </div>
                  )}

                  {/* Name */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Name <span className="text-[#0dc2cc]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors text-black"
                    />
                  </div>

                  {/* Company */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Company
                    </label>
                    <input
                      type="text"
                      placeholder="Your company name"
                      value={formData.company}
                      onChange={(e) =>
                        setFormData({ ...formData, company: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors text-black"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Email <span className="text-[#0dc2cc]">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors text-black"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      placeholder="+1 123 455 7890"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors text-black"
                    />
                  </div>

                  {/* Project Type */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-3">
                      Project Type
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {projectTypes.map((type) => (
                        <label
                          key={type}
                          className={`flex items-center gap-3 px-4 py-3 border rounded-lg cursor-pointer transition-colors ${
                            formData.projectType.includes(type)
                              ? "border-[#0dc2cc] bg-[#0dc2cc]/5"
                              : "border-gray-300 hover:border-gray-400"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.projectType.includes(type)}
                            onChange={() => handleProjectTypeChange(type)}
                            className="w-4 h-4 accent-[#0dc2cc]"
                          />
                          <span className="text-sm text-gray-700">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Budget Range */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Budget Range
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. $10,000 - $50,000"
                      value={formData.budget}
                      onChange={(e) =>
                        setFormData({ ...formData, budget: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors text-black"
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-bold text-black mb-2">
                      Message <span className="text-[#0dc2cc]">*</span>
                    </label>
                    <textarea
                      required
                      rows={5}
                      placeholder="Tell us about your project..."
                      value={formData.message}
                      onChange={(e) =>
                        setFormData({ ...formData, message: e.target.value })
                      }
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#0dc2cc] transition-colors resize-none text-black"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-[#0dc2cc] text-black font-bold py-4 px-8 rounded-lg hover:bg-[#0bb5be] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        <span>Sending...</span>
                      </>
                    ) : (
                      "Send Message"
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* What Happens Next */}
            <div>
              <h2
                className="text-2xl md:text-3xl text-black mb-8"
                style={{ fontWeight: 1000 }}
              >
                What Happens Next?
              </h2>
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <div
                    key={index}
                    className="flex gap-6 pb-6 border-b border-gray-200 last:border-0"
                  >
                    <span className="text-[#0dc2cc] font-bold text-lg">
                      {step.number}
                    </span>
                    <div>
                      <p className="text-black font-bold mb-1">{step.title}</p>
                      <p className="text-gray-600 text-sm">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-10 bg-gray-50 p-6 rounded-lg">
                <p className="text-[#0dc2cc] font-bold mb-2">
                  Average response time: 4 hours
                </p>
                <p className="text-gray-600 text-sm">
                  We&apos;re committed to responding quickly to all inquiries during business hours.
                </p>
              </div>

              {/* Contact Information */}
              <div className="mt-10">
                <h3 className="text-xl font-bold text-black mb-6">
                  Contact Information
                </h3>
                <div className="space-y-6">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Phone</p>
                    <a
                      href="tel:+13109853782"
                      className="text-black font-bold hover:text-[#0dc2cc] transition-colors"
                    >
                      +1 (310) 985-3782
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Email</p>
                    <a
                      href="mailto:support@empire325marketing.com"
                      className="text-black font-bold hover:text-[#0dc2cc] transition-colors"
                    >
                      support@empire325marketing.com
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Business Hours</p>
                    <p className="text-black font-bold">
                      Monday - Friday: 9:00 AM - 5:00 PM EST
                    </p>
                    <p className="text-black font-bold">
                      Saturday: 10:00 AM - 2:00 PM EST
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
