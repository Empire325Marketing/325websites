import HeroSection from "@/components/methodology/heroSection";
import PrinciplesSection from "@/components/methodology/principlesSection";
import ProcessSection from "@/components/methodology/processSection";
import PartnershipSection from "@/components/methodology/partnershipSection";

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Methodology | How We Deliver Integrated Marketing Infrastructure",
  description:
    "Empire325's methodology delivers integrated marketing infrastructure where strategy, execution, and measurement operate simultaneously. Business outcomes determine success.",
  keywords: [
    "marketing methodology",
    "marketing process",
    "integrated marketing",
    "marketing strategy",
    "marketing execution",
    "marketing measurement",
    "business outcomes",
    "data-driven marketing",
  ],
  openGraph: {
    title: "Methodology | How Empire325 Delivers Integrated Marketing Infrastructure",
    description:
      "Empire325's methodology delivers integrated marketing infrastructure where strategy, execution, and measurement operate simultaneously. Business outcomes determine success.",
    url: "https://empire325marketing.com/company/methodology",
    type: "website",
  },
  twitter: {
    title: "Methodology | How Empire325 Delivers Integrated Marketing Infrastructure",
    description:
      "Empire325's methodology delivers integrated marketing infrastructure where strategy, execution, and measurement operate simultaneously. Business outcomes determine success.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/company/methodology",
  },
};

export default function MethodologyPage() {
  return (
    <main>
      <HeroSection />
      <PrinciplesSection />
      <ProcessSection />
      <PartnershipSection />
    </main>
  );
}
