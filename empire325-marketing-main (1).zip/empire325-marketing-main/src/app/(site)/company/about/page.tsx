import HeroSection from "@/components/about/heroSection";
import ProblemSection from "@/components/about/problemSection";
import SolutionSection from "@/components/about/solutionSection";
import WhatWeAreSection from "@/components/about/whatWeAreSection";
import JourneySection from "@/components/about/journeySection";
import TodaySection from "@/components/about/todaySection";
import BeliefsSection from "@/components/about/beliefsSection";
import FutureSection from "@/components/about/futureSection";

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Us | Integrated Marketing Infrastructure That Proves Results",
  description:
    "Empire325 exists because integrated strategy, technical execution, and comprehensive measurement proving marketing's contribution to business outcomes did not exist when organizations needed it most.",
  keywords: [
    "about Empire325",
    "marketing agency",
    "integrated marketing",
    "marketing infrastructure",
    "digital marketing company",
    "marketing strategy",
    "marketing measurement",
    "business outcomes",
  ],
  openGraph: {
    title: "About Empire325 | Integrated Marketing Infrastructure That Proves Results",
    description:
      "Empire325 exists because integrated strategy, technical execution, and comprehensive measurement proving marketing's contribution to business outcomes did not exist when organizations needed it most.",
    url: "https://empire325marketing.com/company/about",
    type: "website",
  },
  twitter: {
    title: "About Empire325 | Integrated Marketing Infrastructure That Proves Results",
    description:
      "Empire325 exists because integrated strategy, technical execution, and comprehensive measurement proving marketing's contribution to business outcomes did not exist when organizations needed it most.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/company/about",
  },
};

export default function AboutPage() {
  return (
    <main>
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <WhatWeAreSection />
      <JourneySection />
      <TodaySection />
      <BeliefsSection />
      <FutureSection />
    </main>
  );
}
