import { Metadata } from "next";
import ApproachSection from '@/components/industries/financial/approachSection'
import CaseStudySection from '@/components/industries/financial/caseStudySection'
import ChallengesSection from '@/components/industries/financial/ChallengesSection'
import ExpertiseSection from '@/components/industries/financial/expertiseSection'
import FAQSection from '@/components/industries/financial/faqSection'
import HeroSection from '@/components/industries/financial/heroSection'
import ServicesShowcase from '@/components/industries/financial/servicesShowcase'
import SpecializationsSection from '@/components/industries/financial/specializationSection'
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Financial Services Marketing",
  "Empire325's financial services marketing drives compliant growth for banks, fintech, wealth management, and insurance. Specialized strategies meeting regulatory requirements.",
  "https://empire325marketing.com/industries/financial-services"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Financial Services", url: "https://empire325marketing.com/industries/financial-services" },
]);

export const metadata: Metadata = {
  title: "Financial Services Marketing | Compliant Growth Strategies",
  description:
    "Empire325's financial services marketing drives compliant growth for banks, fintech, wealth management, and insurance. Specialized strategies meeting regulatory requirements.",
  keywords: [
    "financial services marketing",
    "fintech marketing",
    "bank marketing",
    "wealth management marketing",
    "insurance marketing",
    "financial compliance marketing",
    "financial advisor marketing",
    "investment marketing",
    "financial brand strategy",
    "regulated industry marketing",
  ],
  openGraph: {
    title: "Financial Services Marketing | Compliant Growth Strategies",
    description:
      "Empire325's financial services marketing drives compliant growth for banks, fintech, wealth management, and insurance. Specialized strategies meeting regulatory requirements.",
    url: "https://empire325marketing.com/industries/financial-services",
    type: "website",
  },
  twitter: {
    title: "Financial Services Marketing | Compliant Growth Strategies",
    description:
      "Empire325's financial services marketing drives compliant growth for banks, fintech, wealth management, and insurance. Specialized strategies meeting regulatory requirements.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/financial-services",
  },
};

const FinancialServices = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ApproachSection />
      <ServicesShowcase />
      <SpecializationsSection />
      <ExpertiseSection />
      <ChallengesSection />
      <CaseStudySection />
      <FAQSection />
    </>
  )
}

export default FinancialServices
