import { Metadata } from "next";
import ApproachSection from '@/components/industries/real-estate/approachSection'
import FAQSection from '@/components/industries/real-estate/faqSection'
import HeroSection from '@/components/industries/real-estate/heroSection'
import InnovationsSection from '@/components/industries/real-estate/innovationSection'
import ServicesSection from '@/components/industries/real-estate/servicesSection'
import SpecializationsSection from '@/components/industries/real-estate/specializationSection'
import TechnologySection from '@/components/industries/real-estate/technologySection'
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Real Estate Marketing",
  "Empire325's real estate marketing generates leads for brokerages, developers, and property managers. Digital strategies for residential, commercial, and luxury real estate.",
  "https://empire325marketing.com/industries/real-estate"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Real Estate", url: "https://empire325marketing.com/industries/real-estate" },
]);

export const metadata: Metadata = {
  title: "Real Estate Marketing | Property & Development Growth Strategies",
  description:
    "Empire325's real estate marketing generates leads for brokerages, developers, and property managers. Digital strategies for residential, commercial, and luxury real estate.",
  keywords: [
    "real estate marketing",
    "property marketing",
    "real estate lead generation",
    "luxury real estate marketing",
    "commercial real estate marketing",
    "residential real estate advertising",
    "real estate developer marketing",
    "brokerage marketing",
    "property management marketing",
    "real estate digital marketing",
  ],
  openGraph: {
    title: "Real Estate Marketing | Property & Development Growth Strategies",
    description:
      "Empire325's real estate marketing generates leads for brokerages, developers, and property managers. Digital strategies for residential, commercial, and luxury real estate.",
    url: "https://empire325marketing.com/industries/real-estate",
    type: "website",
  },
  twitter: {
    title: "Real Estate Marketing | Property & Development Growth Strategies",
    description:
      "Empire325's real estate marketing generates leads for brokerages, developers, and property managers. Digital strategies for residential, commercial, and luxury real estate.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/real-estate",
  },
};

const RealEstate = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ApproachSection />
      <ServicesSection />
      <SpecializationsSection />
      <TechnologySection />
      <InnovationsSection />
      <FAQSection />
    </>
  )
}

export default RealEstate