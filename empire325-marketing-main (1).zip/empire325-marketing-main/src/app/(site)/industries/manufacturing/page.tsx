import { Metadata } from "next";
import ApproachSection from '@/components/industries/manufacturing/approachSection'
import CaseStudySection from '@/components/industries/manufacturing/caseStudySection'
import ChallengesSection from '@/components/industries/manufacturing/challangesSection'
import ExpertiseSection from '@/components/industries/manufacturing/expertiseSection'
import FAQSection from '@/components/industries/manufacturing/faqSection'
import HeroSection from '@/components/industries/manufacturing/heroSection'
import InnovationsSection from '@/components/industries/manufacturing/innovationSection'
import ServicesSection from '@/components/industries/manufacturing/servicesSection'
import SpecializationsSection from '@/components/industries/manufacturing/specializationSection'
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Manufacturing Marketing",
  "Empire325's manufacturing marketing drives leads and sales for industrial companies. B2B strategies for OEMs, distributors, and industrial equipment manufacturers.",
  "https://empire325marketing.com/industries/manufacturing"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Manufacturing", url: "https://empire325marketing.com/industries/manufacturing" },
]);

export const metadata: Metadata = {
  title: "Manufacturing Marketing | Industrial B2B Growth Strategies",
  description:
    "Empire325's manufacturing marketing drives leads and sales for industrial companies. B2B strategies for OEMs, distributors, and industrial equipment manufacturers.",
  keywords: [
    "manufacturing marketing",
    "industrial marketing",
    "B2B manufacturing",
    "OEM marketing",
    "industrial B2B",
    "manufacturing lead generation",
    "industrial advertising",
    "manufacturing digital marketing",
    "supply chain marketing",
    "industrial equipment marketing",
  ],
  openGraph: {
    title: "Manufacturing Marketing | Industrial B2B Growth Strategies",
    description:
      "Empire325's manufacturing marketing drives leads and sales for industrial companies. B2B strategies for OEMs, distributors, and industrial equipment manufacturers.",
    url: "https://empire325marketing.com/industries/manufacturing",
    type: "website",
  },
  twitter: {
    title: "Manufacturing Marketing | Industrial B2B Growth Strategies",
    description:
      "Empire325's manufacturing marketing drives leads and sales for industrial companies. B2B strategies for OEMs, distributors, and industrial equipment manufacturers.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/manufacturing",
  },
};

const Manufacturing = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ApproachSection />
      <ServicesSection />
      <SpecializationsSection />
      <ExpertiseSection />
      <ChallengesSection />
      <InnovationsSection />
      <CaseStudySection />
      <FAQSection />
    </>
  )
}

export default Manufacturing