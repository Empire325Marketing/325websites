import { Metadata } from "next";
import HeroSection from "@/components/industries/media-entertainment/heroSection";
import ServicesSection from "@/components/industries/media-entertainment/servicesSection";
import ApproachSection from "@/components/industries/media-entertainment/approachSection";
import CapabilitiesSection from "@/components/industries/media-entertainment/capabilitiesSection";
import FAQSection from "@/components/industries/media-entertainment/faqSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Media & Entertainment Marketing",
  "Empire325's media and entertainment marketing grows audiences and drives engagement. Strategies for streaming, gaming, studios, publishers, and content creators.",
  "https://empire325marketing.com/industries/media-entertainment"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Media & Entertainment", url: "https://empire325marketing.com/industries/media-entertainment" },
]);

export const metadata: Metadata = {
  title: "Media & Entertainment Marketing | Audience Growth & Engagement",
  description:
    "Empire325's media and entertainment marketing grows audiences and drives engagement. Strategies for streaming, gaming, studios, publishers, and content creators.",
  keywords: [
    "media marketing",
    "entertainment marketing",
    "streaming marketing",
    "gaming marketing",
    "content marketing",
    "audience growth",
    "subscriber acquisition",
    "studio marketing",
    "publisher marketing",
    "creator marketing",
  ],
  openGraph: {
    title: "Media & Entertainment Marketing | Audience Growth & Engagement",
    description:
      "Empire325's media and entertainment marketing grows audiences and drives engagement. Strategies for streaming, gaming, studios, publishers, and content creators.",
    url: "https://empire325marketing.com/industries/media-entertainment",
    type: "website",
  },
  twitter: {
    title: "Media & Entertainment Marketing | Audience Growth & Engagement",
    description:
      "Empire325's media and entertainment marketing grows audiences and drives engagement. Strategies for streaming, gaming, studios, publishers, and content creators.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/media-entertainment",
  },
};

const MediaEntertainment = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ServicesSection />
      <ApproachSection />
      <CapabilitiesSection />
      <FAQSection />
    </>
  );
};

export default MediaEntertainment;
