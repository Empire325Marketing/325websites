import { Metadata } from "next";
import ApproachSection from '@/components/industries/saas/approachSection'
import CaseStudy from '@/components/industries/saas/caseStudy'
import FAQ from '@/components/industries/saas/faq'
import HeroSection from '@/components/industries/saas/heroSection'
import ServicesGrid from '@/components/industries/saas/servicesGrid'
import WhyChooseSection from '@/components/industries/saas/whyChooseSection'
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "SaaS Marketing",
  "Empire325's SaaS marketing accelerates user acquisition, improves activation, and reduces churn. Growth strategies for B2B and B2C software companies at every stage.",
  "https://empire325marketing.com/industries/saas"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "SaaS", url: "https://empire325marketing.com/industries/saas" },
]);

export const metadata: Metadata = {
  title: "SaaS Marketing | Accelerate User Acquisition & Reduce Churn",
  description:
    "Empire325's SaaS marketing accelerates user acquisition, improves activation, and reduces churn. Growth strategies for B2B and B2C software companies at every stage.",
  keywords: [
    "SaaS marketing",
    "software marketing",
    "SaaS growth",
    "B2B SaaS marketing",
    "SaaS user acquisition",
    "SaaS lead generation",
    "product-led growth",
    "SaaS content marketing",
    "SaaS demand generation",
    "software company marketing",
  ],
  openGraph: {
    title: "SaaS Marketing | Accelerate User Acquisition & Reduce Churn",
    description:
      "Empire325's SaaS marketing accelerates user acquisition, improves activation, and reduces churn. Growth strategies for B2B and B2C software companies at every stage.",
    url: "https://empire325marketing.com/industries/saas",
    type: "website",
  },
  twitter: {
    title: "SaaS Marketing | Accelerate User Acquisition & Reduce Churn",
    description:
      "Empire325's SaaS marketing accelerates user acquisition, improves activation, and reduces churn. Growth strategies for B2B and B2C software companies at every stage.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/saas",
  },
};

const Saas = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ApproachSection />
      <ServicesGrid />
      <WhyChooseSection />
      <CaseStudy />
      <FAQ />
    </>
  )
}

export default Saas