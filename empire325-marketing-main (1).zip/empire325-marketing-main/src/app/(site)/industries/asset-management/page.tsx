import { Metadata } from "next";
import HeroSection from "@/components/industries/asset-management/heroSection";
import ServicesSection from "@/components/industries/asset-management/servicesSection";
import ApproachSection from "@/components/industries/asset-management/approachSection";
import CapabilitiesSection from "@/components/industries/asset-management/capabilitiesSection";
import FAQSection from "@/components/industries/asset-management/faqSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Asset Management Marketing",
  "Empire325's asset management marketing attracts institutional and retail investors. Compliant strategies for hedge funds, private equity, mutual funds, and wealth managers.",
  "https://empire325marketing.com/industries/asset-management"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Asset Management", url: "https://empire325marketing.com/industries/asset-management" },
]);

export const metadata: Metadata = {
  title: "Asset Management Marketing | Institutional & Retail Investor Growth",
  description:
    "Empire325's asset management marketing attracts institutional and retail investors. Compliant strategies for hedge funds, private equity, mutual funds, and wealth managers.",
  keywords: [
    "asset management marketing",
    "investment marketing",
    "hedge fund marketing",
    "private equity marketing",
    "mutual fund marketing",
    "wealth management marketing",
    "institutional investor marketing",
    "fund marketing",
    "AUM growth",
    "investment firm marketing",
  ],
  openGraph: {
    title: "Asset Management Marketing | Institutional & Retail Investor Growth",
    description:
      "Empire325's asset management marketing attracts institutional and retail investors. Compliant strategies for hedge funds, private equity, mutual funds, and wealth managers.",
    url: "https://empire325marketing.com/industries/asset-management",
    type: "website",
  },
  twitter: {
    title: "Asset Management Marketing | Institutional & Retail Investor Growth",
    description:
      "Empire325's asset management marketing attracts institutional and retail investors. Compliant strategies for hedge funds, private equity, mutual funds, and wealth managers.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/asset-management",
  },
};

const AssetManagement = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <HeroSection />
      <ServicesSection />
      <ApproachSection />
      <CapabilitiesSection />
      <FAQSection />
    </>
  );
};

export default AssetManagement;
