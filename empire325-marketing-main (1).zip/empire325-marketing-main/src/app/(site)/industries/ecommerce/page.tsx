import { Metadata } from "next";
import ApproachSection from '@/components/industries/ecommerce/approachSection'
import FAQSection from '@/components/industries/ecommerce/faqSection'
import EcommerceHero from '@/components/industries/ecommerce/heroSection'
import OfferingsSection from '@/components/industries/ecommerce/offeringSection'
import ServicesSection from '@/components/industries/ecommerce/servicesSection'
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Ecommerce Marketing",
  "Empire325's ecommerce marketing solutions drive sales, increase conversions, and maximize revenue. Full-funnel strategies for DTC brands, marketplaces, and online retailers.",
  "https://empire325marketing.com/industries/ecommerce"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Industries", url: "https://empire325marketing.com/industries" },
  { name: "Ecommerce", url: "https://empire325marketing.com/industries/ecommerce" },
]);

export const metadata: Metadata = {
  title: "Ecommerce Marketing | Drive Sales & Maximize Revenue",
  description:
    "Empire325's ecommerce marketing solutions drive sales, increase conversions, and maximize revenue. Full-funnel strategies for DTC brands, marketplaces, and online retailers.",
  keywords: [
    "ecommerce marketing",
    "ecommerce advertising",
    "online retail marketing",
    "DTC marketing",
    "ecommerce conversion optimization",
    "product listing ads",
    "shopping campaigns",
    "ecommerce SEO",
    "ecommerce analytics",
    "marketplace marketing",
  ],
  openGraph: {
    title: "Ecommerce Marketing | Drive Sales & Maximize Revenue",
    description:
      "Empire325's ecommerce marketing solutions drive sales, increase conversions, and maximize revenue. Full-funnel strategies for DTC brands, marketplaces, and online retailers.",
    url: "https://empire325marketing.com/industries/ecommerce",
    type: "website",
  },
  twitter: {
    title: "Ecommerce Marketing | Drive Sales & Maximize Revenue",
    description:
      "Empire325's ecommerce marketing solutions drive sales, increase conversions, and maximize revenue. Full-funnel strategies for DTC brands, marketplaces, and online retailers.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/industries/ecommerce",
  },
};

const Ecommerce = () => {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <EcommerceHero />
      <ApproachSection />
      <ServicesSection />
      <OfferingsSection />
      <FAQSection />
    </>
  )
}

export default Ecommerce