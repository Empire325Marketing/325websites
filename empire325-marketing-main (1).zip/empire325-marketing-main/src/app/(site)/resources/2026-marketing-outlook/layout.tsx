import { Metadata } from "next";

export const metadata: Metadata = {
  title: "2026 Enterprise Marketing Outlook | Data and AI Foundation Shift",
  description:
    "Empire325's 2026 Enterprise Marketing Outlook report. Research across 130+ enterprises documents the forces driving permanent bifurcation between infrastructure leaders and manual process organizations.",
  keywords: [
    "2026 marketing trends",
    "enterprise marketing outlook",
    "marketing AI trends",
    "data-driven marketing",
    "marketing technology",
    "digital transformation",
    "marketing infrastructure",
    "marketing research report",
    "B2B marketing trends",
    "marketing ROI",
  ],
  openGraph: {
    title: "2026 Enterprise Marketing Outlook | The Data and AI Foundation Shift",
    description:
      "Empire325's 2026 Enterprise Marketing Outlook report. Research across 130+ enterprises documents the forces driving permanent bifurcation between infrastructure leaders and manual process organizations.",
    url: "https://empire325marketing.com/resources/2026-marketing-outlook",
    type: "article",
  },
  twitter: {
    title: "2026 Enterprise Marketing Outlook | The Data and AI Foundation Shift",
    description:
      "Empire325's 2026 Enterprise Marketing Outlook report. Research across 130+ enterprises documents the forces driving permanent bifurcation between infrastructure leaders and manual process organizations.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/resources/2026-marketing-outlook",
  },
};

export default function MarketingOutlookLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
