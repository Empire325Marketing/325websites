"use client";

import { useState } from "react";
import Link from "next/link";

export default function MarketingOutlookPage() {
  const [email, setEmail] = useState("");
  const [reachOut, setReachOut] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          access_key: process.env.NEXT_PUBLIC_WEB3FORMS_KEY || "YOUR_ACCESS_KEY_HERE",
          email: email,
          reach_out: reachOut ? "Yes" : "No",
          subject: "2026 Marketing Outlook - New Signup",
          from_name: "Empire325 Website",
          source: "2026 Marketing Outlook Page",
        }),
      });

      const result = await response.json();

      if (result.success) {
        setSubmitted(true);
        setEmail("");
        setReachOut(false);
      }
    } catch {
      // Handle error silently or show error state if needed
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="bg-white min-h-screen">
      {/* Hero Section - Black Background */}
      <section className="bg-black px-6 md:px-12 lg:px-16 py-16 lg:py-20">
        <div className="max-w-[90vw] mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Left Column - Content */}
            <div>
              {/* Back Link + Badge */}
              <div className="flex items-center gap-4 mb-6">
                <Link
                  href="/"
                  className="inline-flex items-center gap-2 text-[#0dc2cc] hover:underline text-sm font-medium"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Back to Resources
                </Link>
              </div>

              {/* Badge */}
              <span className="inline-block text-xs font-bold tracking-widest text-white uppercase mb-6 border border-white px-3 py-1">
                Industry Report
              </span>

              {/* Headline */}
              <h1
                className="text-3xl md:text-4xl lg:text-[48px] text-white leading-[1.1] mb-4"
                style={{ fontWeight: 1000 }}
              >
                2026 Enterprise Marketing Outlook
              </h1>

              {/* Subtitle */}
              <p className="text-xl text-gray-400 mb-6">
                The Data and AI Foundation Shift
              </p>

              {/* Launch Badge */}
              <div className="inline-flex items-center gap-2 mb-8">
                <span className="w-2 h-2 bg-[#0dc2cc] rounded-full animate-pulse"></span>
                <span className="text-[#0dc2cc] font-medium">
                  Launching Soon — Be the First to Know
                </span>
              </div>
            </div>

            {/* Right Column - Form Card */}
            <div className="lg:translate-y-36 shadow-2xl">
              <div className="bg-white p-8 lg:p-10">
                <h2 className="text-xl font-bold text-black mb-6">
                  Get Notified at Launch
                </h2>

                {submitted ? (
                  <div className="py-6 text-center">
                    <div className="w-14 h-14 bg-[#0dc2cc] rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-black font-bold text-lg mb-1">You&apos;re on the list!</p>
                    <p className="text-gray-500 text-sm">We&apos;ll notify you when the report launches.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">
                        Business Email <span className="text-[#0dc2cc]">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="name@company.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 text-black placeholder-gray-400 focus:outline-none focus:border-[#0dc2cc] focus:bg-white transition-all"
                      />
                    </div>

                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={reachOut}
                        onChange={(e) => setReachOut(e.target.checked)}
                        className="w-5 h-5 mt-0.5 accent-[#0dc2cc]"
                      />
                      <span className="text-sm text-gray-600">
                        I&apos;d like Empire325 Marketing to reach out to me.
                      </span>
                    </label>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-[#0dc2cc] text-black font-bold py-4 px-6 hover:bg-[#0bb5be] transition-colors flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          <span>Submitting...</span>
                        </>
                      ) : (
                        <>
                          <span>Notify Me</span>
                          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                          </svg>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Content Section - White Background */}
      <section className="px-6 md:px-12 lg:px-16 py-16 lg:py-20">
        <div className="max-w-[90vw] mx-auto">
          <div className="max-w-3xl">
            {/* Main Headline */}
            <p className="text-lg font-bold text-black mb-6">
              The infrastructure decision defining competitive outcomes through 2028
            </p>

            {/* Content Paragraphs */}
            <div className="space-y-6 text-gray-700 leading-relaxed mb-12">
              <p>
                87% of enterprises invested in data platforms and AI technologies during 2024-2025. Only 23% achieved operational integration enabling competitive advantages 35-50% lower customer acquisition costs, 2.5-4X return on ad spend improvements, and performance gains compounding 15-25% annually.
              </p>
              <p>
                77% possess technology generating minimal value due to integration failure. This represents $89 billion in capital producing no operational impact.
              </p>
              <p>
                Empire325 research across 130+ enterprises documents the forces driving permanent bifurcation between infrastructure leaders and manual process organizations and the narrow window to build foundation before gaps become insurmountable.
              </p>
            </div>

            {/* Research Info */}
            <div className="border-t border-gray-200 pt-10 mt-4">
              <p className="text-sm font-bold text-[#0dc2cc] uppercase tracking-wider mb-8">
                Empire325 Marketing Intelligence Group
              </p>
              <div className="grid grid-cols-3 gap-8">
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">Research Period</p>
                  <p className="text-black font-semibold">September – December 2025</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">Publishing</p>
                  <p className="text-black font-semibold">January 2026</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">Research Scope</p>
                  <p className="text-black font-semibold">130+ enterprises</p>
                  <p className="text-gray-500 text-sm">across 23 countries</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
