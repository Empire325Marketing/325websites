import { Metadata } from "next";
import HeroSection from "@/components/services/full-funnel-advertising/heroSection";
import ChallengeSection from "@/components/services/full-funnel-advertising/challengeSection";
import ApproachSection from "@/components/services/full-funnel-advertising/approachSection";
import CapabilitiesSection from "@/components/services/full-funnel-advertising/capabilitiesSection";
import IndustrySection from "@/components/services/full-funnel-advertising/industrySection";
import MeasurementSection from "@/components/services/full-funnel-advertising/measurementSection";
import CTASection from "@/components/services/full-funnel-advertising/ctaSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Full-Funnel Advertising",
  "Empire325's full-funnel advertising drives reach, nurturing, and conversion. Unified paid media orchestration connecting awareness investment to revenue outcomes.",
  "https://empire325marketing.com/services/full-funnel-advertising"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Services", url: "https://empire325marketing.com/services" },
  { name: "Full-Funnel Advertising", url: "https://empire325marketing.com/services/full-funnel-advertising" },
]);

export const metadata: Metadata = {
  title: "Full-Funnel Advertising | Unified Paid Media Management",
  description:
    "Empire325's full-funnel advertising drives reach, nurturing, and conversion. Unified paid media orchestration connecting awareness investment to revenue outcomes.",
  keywords: [
    "full-funnel advertising",
    "paid media management",
    "PPC advertising",
    "digital advertising",
    "Google Ads management",
    "Facebook Ads",
    "LinkedIn Ads",
    "programmatic advertising",
    "conversion optimization",
    "ROAS optimization",
  ],
  openGraph: {
    title: "Full-Funnel Advertising | Unified Paid Media Management",
    description:
      "Empire325's full-funnel advertising drives reach, nurturing, and conversion. Unified paid media orchestration connecting awareness investment to revenue outcomes.",
    url: "https://empire325marketing.com/services/full-funnel-advertising",
    type: "website",
  },
  twitter: {
    title: "Full-Funnel Advertising | Unified Paid Media Management",
    description:
      "Empire325's full-funnel advertising drives reach, nurturing, and conversion. Unified paid media orchestration connecting awareness investment to revenue outcomes.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/services/full-funnel-advertising",
  },
};

export default function FullFunnelAdvertisingPage() {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <main>
        <HeroSection />
        <ChallengeSection />
        <ApproachSection />
        <CapabilitiesSection />
        <IndustrySection />
        <MeasurementSection />
        <CTASection />
      </main>
    </>
  );
}
