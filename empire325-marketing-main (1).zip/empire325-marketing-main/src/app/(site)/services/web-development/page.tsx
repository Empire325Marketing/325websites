import { Metadata } from "next";
import HeroSection from "@/components/services/web-development/heroSection";
import ChallengeSection from "@/components/services/web-development/challengeSection";
import ApproachSection from "@/components/services/web-development/approachSection";
import CapabilitiesSection from "@/components/services/web-development/capabilitiesSection";
import MeasurementSection from "@/components/services/web-development/measurementSection";
import CTASection from "@/components/services/web-development/ctaSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Web Development Services",
  "Empire325 builds high-performance websites designed for conversion. Custom web development with SEO optimization, fast load times, and measurable business outcomes.",
  "https://empire325marketing.com/services/web-development"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Services", url: "https://empire325marketing.com/services" },
  { name: "Web Development", url: "https://empire325marketing.com/services/web-development" },
]);

export const metadata: Metadata = {
  title: "Web Development Services | High-Performance Websites That Convert",
  description:
    "Empire325 builds high-performance websites designed for conversion. Custom web development with SEO optimization, fast load times, and measurable business outcomes.",
  keywords: [
    "web development services",
    "custom website development",
    "high-performance websites",
    "conversion optimization",
    "SEO website development",
    "enterprise web development",
    "responsive web design",
    "website performance",
    "Next.js development",
    "React development",
  ],
  openGraph: {
    title: "Web Development Services | High-Performance Websites That Convert",
    description:
      "Empire325 builds high-performance websites designed for conversion. Custom web development with SEO optimization, fast load times, and measurable business outcomes.",
    url: "https://empire325marketing.com/services/web-development",
    type: "website",
  },
  twitter: {
    title: "Web Development Services | High-Performance Websites That Convert",
    description:
      "Empire325 builds high-performance websites designed for conversion. Custom web development with SEO optimization, fast load times, and measurable business outcomes.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/services/web-development",
  },
};

export default function WebDevelopmentPage() {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <main>
        <HeroSection />
        <ChallengeSection />
        <ApproachSection />
        <CapabilitiesSection />
        <MeasurementSection />
        <CTASection />
      </main>
    </>
  );
}
