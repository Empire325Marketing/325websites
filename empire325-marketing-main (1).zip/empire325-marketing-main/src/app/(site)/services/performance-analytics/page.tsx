import { Metadata } from "next";
import HeroSection from "@/components/services/performance-analytics/heroSection";
import ChallengeSection from "@/components/services/performance-analytics/challengeSection";
import ApproachSection from "@/components/services/performance-analytics/approachSection";
import MeasurementSection from "@/components/services/performance-analytics/measurementSection";
import CTASection from "@/components/services/performance-analytics/ctaSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Performance & Analytics",
  "Empire325's performance analytics connect marketing to business outcomes. Multi-touch attribution, real-time dashboards, and predictive modeling for data-driven decisions.",
  "https://empire325marketing.com/services/performance-analytics"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Services", url: "https://empire325marketing.com/services" },
  { name: "Performance & Analytics", url: "https://empire325marketing.com/services/performance-analytics" },
]);

export const metadata: Metadata = {
  title: "Performance & Analytics | Revenue Attribution & Decision Intelligence",
  description:
    "Empire325's performance analytics connect marketing to business outcomes. Multi-touch attribution, real-time dashboards, and predictive modeling for data-driven decisions.",
  keywords: [
    "marketing analytics",
    "performance analytics",
    "revenue attribution",
    "multi-touch attribution",
    "marketing ROI",
    "real-time dashboards",
    "predictive analytics",
    "marketing measurement",
    "decision intelligence",
    "data visualization",
  ],
  openGraph: {
    title: "Performance & Analytics | Revenue Attribution & Decision Intelligence",
    description:
      "Empire325's performance analytics connect marketing to business outcomes. Multi-touch attribution, real-time dashboards, and predictive modeling for data-driven decisions.",
    url: "https://empire325marketing.com/services/performance-analytics",
    type: "website",
  },
  twitter: {
    title: "Performance & Analytics | Revenue Attribution & Decision Intelligence",
    description:
      "Empire325's performance analytics connect marketing to business outcomes. Multi-touch attribution, real-time dashboards, and predictive modeling for data-driven decisions.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/services/performance-analytics",
  },
};

export default function PerformanceAnalyticsPage() {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <main>
        <HeroSection />
        <ChallengeSection />
        <ApproachSection />
        <MeasurementSection />
        <CTASection />
      </main>
    </>
  );
}
