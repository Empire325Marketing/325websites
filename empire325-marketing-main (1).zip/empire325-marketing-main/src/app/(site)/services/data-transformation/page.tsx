import { Metadata } from "next";
import HeroSection from "@/components/services/data-transformation/heroSection";
import ChallengeSection from "@/components/services/data-transformation/challengeSection";
import ApproachSection from "@/components/services/data-transformation/approachSection";
import MeasurementSection from "@/components/services/data-transformation/measurementSection";
import CTASection from "@/components/services/data-transformation/ctaSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "Data Transformation",
  "Empire325's data transformation services build unified data architecture enabling decision intelligence at scale. Single source of truth for enterprise marketing.",
  "https://empire325marketing.com/services/data-transformation"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Services", url: "https://empire325marketing.com/services" },
  { name: "Data Transformation", url: "https://empire325marketing.com/services/data-transformation" },
]);

export const metadata: Metadata = {
  title: "Data Transformation | Enterprise Data Infrastructure & Analytics",
  description:
    "Empire325's data transformation services build unified data architecture enabling decision intelligence at scale. Single source of truth for enterprise marketing.",
  keywords: [
    "data transformation",
    "enterprise data infrastructure",
    "data architecture",
    "marketing data",
    "data analytics",
    "business intelligence",
    "data integration",
    "unified data platform",
    "decision intelligence",
    "data-driven marketing",
  ],
  openGraph: {
    title: "Data Transformation | Enterprise Data Infrastructure & Analytics",
    description:
      "Empire325's data transformation services build unified data architecture enabling decision intelligence at scale. Single source of truth for enterprise marketing.",
    url: "https://empire325marketing.com/services/data-transformation",
    type: "website",
  },
  twitter: {
    title: "Data Transformation | Enterprise Data Infrastructure & Analytics",
    description:
      "Empire325's data transformation services build unified data architecture enabling decision intelligence at scale. Single source of truth for enterprise marketing.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/services/data-transformation",
  },
};

export default function DataTransformationPage() {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <main>
        <HeroSection />
        <ChallengeSection />
        <ApproachSection />
        <MeasurementSection />
        <CTASection />
      </main>
    </>
  );
}
