import { Metadata } from "next";
import HeroSection from "@/components/services/ai-saas-tools/heroSection";
import ChallengeSection from "@/components/services/ai-saas-tools/challengeSection";
import ApproachSection from "@/components/services/ai-saas-tools/approachSection";
import CapabilitiesSection from "@/components/services/ai-saas-tools/capabilitiesSection";
import MeasurementSection from "@/components/services/ai-saas-tools/measurementSection";
import JsonLd, { createServiceSchema, createBreadcrumbSchema } from "@/components/seo/JsonLd";

const serviceSchema = createServiceSchema(
  "AI & SaaS Tools",
  "Empire325's AI and SaaS tools automate marketing workflows, enhance decision-making, and drive efficiency. Custom AI solutions for enterprise marketing teams.",
  "https://empire325marketing.com/services/ai-saas-tools"
);

const breadcrumbSchema = createBreadcrumbSchema([
  { name: "Home", url: "https://empire325marketing.com" },
  { name: "Services", url: "https://empire325marketing.com/services" },
  { name: "AI & SaaS Tools", url: "https://empire325marketing.com/services/ai-saas-tools" },
]);

export const metadata: Metadata = {
  title: "AI & SaaS Tools | Intelligent Marketing Automation Solutions",
  description:
    "Empire325's AI and SaaS tools automate marketing workflows, enhance decision-making, and drive efficiency. Custom AI solutions for enterprise marketing teams.",
  keywords: [
    "AI marketing tools",
    "SaaS marketing solutions",
    "marketing automation",
    "AI-powered marketing",
    "machine learning marketing",
    "intelligent automation",
    "marketing AI",
    "enterprise SaaS",
    "marketing technology",
    "martech solutions",
  ],
  openGraph: {
    title: "AI & SaaS Tools | Intelligent Marketing Automation Solutions",
    description:
      "Empire325's AI and SaaS tools automate marketing workflows, enhance decision-making, and drive efficiency. Custom AI solutions for enterprise marketing teams.",
    url: "https://empire325marketing.com/services/ai-saas-tools",
    type: "website",
  },
  twitter: {
    title: "AI & SaaS Tools | Intelligent Marketing Automation Solutions",
    description:
      "Empire325's AI and SaaS tools automate marketing workflows, enhance decision-making, and drive efficiency. Custom AI solutions for enterprise marketing teams.",
  },
  alternates: {
    canonical: "https://empire325marketing.com/services/ai-saas-tools",
  },
};

export default function AISaaSToolsPage() {
  return (
    <>
      <JsonLd data={serviceSchema} />
      <JsonLd data={breadcrumbSchema} />
      <main>
        <HeroSection />
        <ChallengeSection />
        <ApproachSection />
        <CapabilitiesSection />
        <MeasurementSection />
      </main>
    </>
  );
}
